extends Node
## Persistent user settings (autoload "Settings"), saved to user://settings.cfg.

signal changed

const PATH := "user://settings.cfg"

var sensitivity := 1.0     # multiplier on the player's base mouse sensitivity
var fov := 85.0
var volume := 1.0          # 0..1 master volume
# Phones get lighter defaults (no SSAO, no MSAA); the player can still turn them on.
var ssao := not OS.has_feature("mobile")
var msaa := 0 if OS.has_feature("mobile") else 2   # Viewport.MSAA_* : 0 off, 1 = 2x, 2 = 4x
var show_fps := true
var controls := 0          # 0 = auto (touch on phones/tablets), 1 = PC, 2 = mobile (touch)


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	load_settings()
	apply()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_settings()


## True when the on-screen touch controls should be used instead of keyboard + mouse.
func use_touch() -> bool:
	if controls == 1:
		return false
	if controls == 2:
		return true
	return OS.has_feature("mobile") or OS.has_feature("web_android") or OS.has_feature("web_ios")


## Mouse mode while playing: captured for mouse-look on PC, visible on touch devices.
func gameplay_mouse_mode() -> Input.MouseMode:
	return Input.MOUSE_MODE_VISIBLE if use_touch() else Input.MOUSE_MODE_CAPTURED


## True while gameplay input should be read (not paused, no menu open).
func input_live() -> bool:
	return use_touch() or Input.mouse_mode == Input.MOUSE_MODE_CAPTURED


## Applies the current values and tells listeners (HUD, environment, ...) to refresh.
func apply() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(volume) if volume > 0.001 else -80.0)
	get_tree().root.msaa_3d = clampi(msaa, 0, 2) as Viewport.MSAA
	changed.emit()


func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	controls = clampi(int(cfg.get_value("controls", "scheme", controls)), 0, 2)
	sensitivity = clampf(float(cfg.get_value("controls", "sensitivity", sensitivity)), 0.2, 4.0)
	fov = clampf(float(cfg.get_value("video", "fov", fov)), 60.0, 110.0)
	ssao = bool(cfg.get_value("video", "ssao", ssao))
	msaa = clampi(int(cfg.get_value("video", "msaa", msaa)), 0, 2)
	show_fps = bool(cfg.get_value("video", "show_fps", show_fps))
	volume = clampf(float(cfg.get_value("audio", "volume", volume)), 0.0, 1.0)


func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("controls", "sensitivity", sensitivity)
	cfg.set_value("controls", "scheme", controls)
	cfg.set_value("video", "fov", fov)
	cfg.set_value("video", "ssao", ssao)
	cfg.set_value("video", "msaa", msaa)
	cfg.set_value("video", "show_fps", show_fps)
	cfg.set_value("audio", "volume", volume)
	cfg.save(PATH)
