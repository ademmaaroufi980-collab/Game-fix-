extends CanvasLayer
## Autoload "Loading": full-screen loading screen.
##   - shown for a moment when the game opens (hides the menu being built)
##   - Loading.go(scene_path) shows it while the scene loads, then switches to it
## Used when a mode starts (START in the lobby) and on PLAY AGAIN.

const UIStyle = preload("res://scripts/ui/theme/ui_style.gd")

const BG_PATH := "res://assets/art/loading_bg.jpg"
const STUDIO_NAME := "RAR GAME 891"
const SPLASH_FADE := 0.7    # fade in / fade out of the studio splash
const SPLASH_HOLD := 1.4    # fully visible
const BOOT_TIME := 1.8      # seconds shown when the game opens
const MIN_TIME := 1.4       # a mode load is never shorter than this (so it does not flash)

const MODE_NAMES := {
	"free": "FREE PLAY",
	"timed": "TIMED",
	"rounds": "ROUNDS",
	"br": "BATTLE ROYALE",
}
const TIPS := {
	"": ["Drag on the lobby to turn your soldier.", "Pick a weapon and outfit before you start."],
	"free": ["Enemies hunt you and shoot back, then respawn at random spots.", "Keep moving: standing still is how you get hit."],
	"timed": ["Score as much as you can before the clock runs out.", "Headshots are worth more."],
	"rounds": ["Clear every enemy before the round timer ends.", "Chain kills for a streak bonus."],
	"br": ["Press M to open the map and mark where you want to land.", "Press jump to leave the plane, then jump again to open your parachute."],
}

var root: ColorRect
var bar: BulletBar
var mode_label: Label
var tip_label: Label
var dots_label: Label

var active := false
var path := ""
var elapsed := 0.0
var min_time := 0.0
var shown := 0.0
var switching := false
var fade_tw: Tween
var splash: ColorRect
var splash_tw: Tween


func _ready() -> void:
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build()
	_play_studio_splash()   # first thing the player sees; the loading screen follows


func _build() -> void:
	root = ColorRect.new()
	root.color = Color(0.03, 0.04, 0.07)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(root)

	# Artwork behind everything (skipped if the file is missing), darkened so the text stays readable
	var bg_tex := load(BG_PATH) as Texture2D
	if bg_tex != null:
		var art := TextureRect.new()
		art.texture = bg_tex
		art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		art.mouse_filter = Control.MOUSE_FILTER_IGNORE
		root.add_child(art)
		var dim := ColorRect.new()
		dim.color = Color(0.02, 0.03, 0.06, 0.45)
		dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
		root.add_child(dim)

	# Soft orange glow along the bottom
	var glow := ColorRect.new()
	glow.color = Color(UIStyle.ACCENT.r, UIStyle.ACCENT.g, UIStyle.ACCENT.b, 0.10)
	glow.anchor_top = 0.72
	glow.anchor_right = 1.0
	glow.anchor_bottom = 1.0
	glow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(glow)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(center)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(box)

	var title := UIStyle.label("SQUAD OF BLOOD", 60, UIStyle.ACCENT)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)

	mode_label = UIStyle.label("", 28, UIStyle.TEXT)
	mode_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(mode_label)

	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 18)
	gap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(gap)

	bar = BulletBar.new()
	box.add_child(bar)

	dots_label = UIStyle.label("LOADING", 18, UIStyle.TEXT_DIM)
	dots_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(dots_label)

	tip_label = UIStyle.label("", 18, UIStyle.TEXT_DIM)
	tip_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tip_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip_label.custom_minimum_size = Vector2(520, 0)
	box.add_child(tip_label)


## Studio name shown once when the game opens (any key or click skips it).
func _play_studio_splash() -> void:
	splash = ColorRect.new()
	splash.color = Color.BLACK
	splash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	splash.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(splash)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	splash.add_child(center)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(box)

	var name_label := UIStyle.label(STUDIO_NAME, 72, Color.WHITE)
	name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(name_label)
	var line := ColorRect.new()
	line.color = UIStyle.ACCENT
	line.custom_minimum_size = Vector2(0, 3)
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(line)
	var sub := UIStyle.label("PRESENTS", 20, UIStyle.TEXT_DIM)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(sub)

	box.modulate.a = 0.0
	splash_tw = create_tween()
	splash_tw.tween_property(box, "modulate:a", 1.0, SPLASH_FADE)
	splash_tw.tween_interval(SPLASH_HOLD)
	splash_tw.tween_property(box, "modulate:a", 0.0, SPLASH_FADE)
	splash_tw.finished.connect(_end_splash)


func _end_splash() -> void:
	if splash == null:
		return
	splash.queue_free()
	splash = null
	_begin("", BOOT_TIME)   # opening loading screen


func _input(event: InputEvent) -> void:
	if splash == null or not event.is_pressed():
		return
	if event is InputEventKey or event is InputEventMouseButton or event is InputEventScreenTouch:
		splash_tw.kill()
		_end_splash()
		get_viewport().set_input_as_handled()


## Shows the screen. `scene` empty = just a timed splash (no scene change).
func _begin(scene: String, time: float) -> void:
	var key := Game.selected if scene != "" else ""
	mode_label.text = MODE_NAMES.get(key, "")
	var tips: Array = TIPS.get(key, TIPS[""])
	tip_label.text = str(tips[randi() % tips.size()])
	path = scene
	min_time = time
	elapsed = 0.0
	shown = 0.0
	bar.value = 0.0
	switching = false
	active = true
	if fade_tw:
		fade_tw.kill()
	root.modulate.a = 1.0
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	visible = true
	if scene != "":
		ResourceLoader.load_threaded_request(scene)


## Loads `scene_path` behind the loading screen, then switches to it.
func go(scene_path: String) -> void:
	if active and path != "":
		return   # already loading a scene
	_begin(scene_path, MIN_TIME)


func _process(delta: float) -> void:
	if not active or switching:
		return
	elapsed += delta

	var real := 1.0
	var loaded := true
	if path != "":
		var progress: Array = []
		var status := ResourceLoader.load_threaded_get_status(path, progress)
		if status == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
			real = float(progress[0]) if progress.size() > 0 else 0.0
			loaded = false
		elif status != ResourceLoader.THREAD_LOAD_LOADED:
			# Could not thread-load: fall back to a plain switch
			_switch(null)
			return

	# The bar follows real progress but never runs ahead of the minimum show time
	shown = move_toward(shown, minf(real, elapsed / min_time), delta * 1.5)
	bar.value = shown
	dots_label.text = "LOADING" + ".".repeat(int(elapsed * 2.5) % 4)

	if loaded and elapsed >= min_time and shown >= 0.99:
		if path == "":
			_fade_out()
		else:
			_switch(ResourceLoader.load_threaded_get(path) as PackedScene)


func _switch(packed: PackedScene) -> void:
	switching = true
	bar.value = 1.0
	dots_label.text = "STARTING"
	get_tree().paused = false
	if packed:
		get_tree().change_scene_to_packed(packed)
	else:
		get_tree().change_scene_to_file(path)
	# The new scene builds itself in the next frames; keep covering it, then fade out
	for i in 4:
		await get_tree().process_frame
	_fade_out()


func _fade_out() -> void:
	switching = true
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fade_tw = create_tween()
	fade_tw.tween_property(root, "modulate:a", 0.0, 0.45)
	await fade_tw.finished
	visible = false
	active = false
	switching = false
