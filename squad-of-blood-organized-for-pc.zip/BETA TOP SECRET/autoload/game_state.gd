extends Node
## Autoload "Game": selected mode, persistent best scores, wallet (coins + gems), owned skins and
## player level (user://scores.cfg).
## Coins are the free currency (earned by playing, daily reward). Gems are the premium currency;
## in this build they are only handed out by the TEST purchase buttons in the store (no real money).

signal wallet_changed

const WALLET_START := 9999   # new saves start with this much of each currency; every launch tops up to it

const PATH := "user://scores.cfg"
const TIME_LIMIT := 60.0   # seconds in timed mode
const DEFAULT_SKINS: Array = ["forest", "desert", "urban", "crimson"]
const XP_PER_LEVEL := 500
const DAILY_REWARD := 150
const DAILY_COOLDOWN := 86400.0   # seconds between daily rewards

var timed := false         # set by the main menu before the arena loads
var rounds := false        # round mode (takes priority over timed)
var br := false            # battle royale mode
var best := {"free": 0, "timed": 0, "rounds": 0, "br": 0}
var welcome_shown := false # the 0.1 beta welcome popup is shown once per launch
var selected := "free"     # last mode picked in the lobby (remembered between runs)
var loadout := 0           # weapon index chosen in the lobby; you start the run holding it
var outfit := 0            # equipped skin (index into LobbyStage.OUTFITS)

var coins := WALLET_START  # free currency
var gems := WALLET_START   # premium currency (test purchases only)
var xp := 0                # lifetime xp (every point scored); the level comes from it
var owned: Array = DEFAULT_SKINS.duplicate()
var last_daily := 0.0      # unix time of the last daily reward


func _ready() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(PATH) == OK:
		for key in best:
			best[key] = int(cfg.get_value("best", key, 0))
		var last := str(cfg.get_value("lobby", "mode", selected))
		if best.has(last):
			selected = last
		loadout = clampi(int(cfg.get_value("lobby", "loadout", loadout)), 0, 3)
		outfit = clampi(int(cfg.get_value("lobby", "outfit", outfit)), 0, 31)
		coins = maxi(0, int(cfg.get_value("wallet", "coins", coins)))
		gems = maxi(0, int(cfg.get_value("wallet", "gems", gems)))
		xp = maxi(0, int(cfg.get_value("wallet", "xp", xp)))
		last_daily = float(cfg.get_value("wallet", "last_daily", last_daily))
		coins = maxi(coins, WALLET_START)
		gems = maxi(gems, WALLET_START)
		var saved = cfg.get_value("wallet", "owned", owned)
		if saved is Array:
			owned = saved
	for id in DEFAULT_SKINS:
		if not owned.has(id):
			owned.append(id)


## Sets the game mode used by the arena ("free", "timed" or "rounds") and remembers it.
func set_mode(key: String) -> void:
	if not best.has(key):
		return
	selected = key
	timed = key == "timed"
	rounds = key == "rounds"
	br = key == "br"
	_save()


func _save() -> void:
	var cfg := ConfigFile.new()
	for key in best:
		cfg.set_value("best", key, best[key])
	cfg.set_value("lobby", "mode", selected)
	cfg.set_value("lobby", "loadout", loadout)
	cfg.set_value("lobby", "outfit", outfit)
	cfg.set_value("wallet", "coins", coins)
	cfg.set_value("wallet", "gems", gems)
	cfg.set_value("wallet", "xp", xp)
	cfg.set_value("wallet", "owned", owned)
	cfg.set_value("wallet", "last_daily", last_daily)
	cfg.save(PATH)


func set_loadout(i: int) -> void:
	loadout = i
	_save()


func set_outfit(i: int) -> void:
	outfit = i
	_save()


func mode_key() -> String:
	if br:
		return "br"
	if rounds:
		return "rounds"
	return "timed" if timed else "free"


func best_score() -> int:
	return best[mode_key()]


## Records the score for the current mode. Returns true if it is a new best.
func submit(score: int) -> bool:
	if score <= best[mode_key()]:
		return false
	best[mode_key()] = score
	_save()
	return true


# --------------------------------------------------------------------------- level / xp

func level() -> int:
	return 1 + int(floor(float(xp) / float(XP_PER_LEVEL)))


## 0..1 progress towards the next level.
func level_progress() -> float:
	return float(xp % XP_PER_LEVEL) / float(XP_PER_LEVEL)


# --------------------------------------------------------------------------- wallet

## Pays out a finished run: coins from the score plus xp. Returns the coins earned.
func award_run(score: int) -> int:
	var earned := int(float(score) * 0.2) + 5
	coins += earned
	xp += maxi(0, score)
	_save()
	wallet_changed.emit()
	return earned


func owns(id: String) -> bool:
	return owned.has(id)


func can_afford(cur: String, price: int) -> bool:
	if cur == "coins":
		return coins >= price
	if cur == "gems":
		return gems >= price
	return true


## Buys a skin with coins or gems. Returns false when it is already owned or too expensive.
func buy_skin(id: String, cur: String, price: int) -> bool:
	if owns(id) or not can_afford(cur, price):
		return false
	if cur == "coins":
		coins -= price
	elif cur == "gems":
		gems -= price
	owned.append(id)
	_save()
	wallet_changed.emit()
	return true


## TEST purchase: adds gems without charging anything.
func add_test_gems(amount: int) -> void:
	gems += amount
	_save()
	wallet_changed.emit()


## Trades gems for coins. Returns false when there are not enough gems.
func exchange_gems(gem_cost: int, coin_gain: int) -> bool:
	if gems < gem_cost:
		return false
	gems -= gem_cost
	coins += coin_gain
	_save()
	wallet_changed.emit()
	return true


func daily_ready() -> bool:
	return daily_remaining() <= 0.0


## Seconds until the next daily reward can be claimed (0 = ready).
func daily_remaining() -> float:
	return maxf(0.0, last_daily + DAILY_COOLDOWN - Time.get_unix_time_from_system())


func claim_daily() -> int:
	if not daily_ready():
		return 0
	last_daily = Time.get_unix_time_from_system()
	coins += DAILY_REWARD
	_save()
	wallet_changed.emit()
	return DAILY_REWARD
