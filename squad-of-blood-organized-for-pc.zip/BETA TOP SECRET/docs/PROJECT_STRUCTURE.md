# Project structure

```
autoload/            Game (game_state), Settings, Loading  (registered in project.godot)
scenes/
  main_menu.tscn     lobby (main scene)
  arena.tscn         shared base world; every mode scene inherits it
  modes/
    free_play.tscn   mode "free"
    timed.tscn       mode "timed"
    rounds.tscn      mode "rounds"
    battle_royale.tscn  mode "br"
scripts/
  core/              layers, session_stats, asset_bridge          (shared helpers)
  audio/             audio_synth, player_audio, weapon_audio      (all sound code)
  input/             touch_controls                               (mobile input)
  player/            player, slide_fx
  weapons/           weapon_manager, weapon_data                  (logic + stats)
    visuals/         weapon_fx, weapon_viewmodels                 (muzzle flash, models)
  world/
    environment/     terrain, trees, world_env
    entities/        target (enemies), pickup
  modes/
    mode_scene.gd    root script of every mode scene (sets Game mode)
    battle_royale/
      drop/          br_plane, br_jump                            (plane, jump, parachute)
      map/           br_terrain, br_houses, br_loot
      zone/          br_zone                                      (shrinking safe zone)
    rounds/          round_manager
  ui/
    menus/           main_menu, lobby_stage, settings_menu
    hud/             game_ui, minimap, bullet_bar, scope_overlay
    theme/           ui_style
resources/weapons/   pistol / rifle / shotgun / sniper .tres
shaders/             grid, skydome, terrain
assets/
  models/            .glb models (+ original assests3d.7z)
  art/               loading_bg, player_avatar, cac_icon
  skydome/           Skydome obj / png / mtl
docs/                notes and reports
```

## How modes start
The lobby (`scripts/ui/menus/main_menu.gd`) keeps a `MODE_SCENES` table (mode key -> scene) and calls
`Loading.go(...)` with the selected mode's scene. Each mode scene is an inherited scene of
`scenes/arena.tscn` whose root script (`scripts/modes/mode_scene.gd`) calls `Game.set_mode(mode_key)`
in `_enter_tree`, so a mode scene can also be run directly from the editor (F6).
PLAY AGAIN reloads `current_scene.scene_file_path`, which is now the mode scene.

## Adding a new mode
1. Add the key to `Game.best` (autoload/game_state.gd) and to `MODES` in the lobby.
2. Create `scenes/modes/<name>.tscn` (copy an existing one, change the root name and `mode_key`).
3. Add it to `MODE_SCENES` in `scripts/ui/menus/main_menu.gd`.
