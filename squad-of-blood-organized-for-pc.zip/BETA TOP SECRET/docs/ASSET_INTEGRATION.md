# Squad of Blood — Battle Royale integration

This build keeps the supplied 3D asset archive at `assets/models/assests3d.7z` and adds an automatic asset bridge.

## Battle Royale systems already wired
- Plane route + jump + parachute
- Procedural 500m terrain with mountain ring and collision walls
- 12 houses with collision, doors/windows and indoor loot
- 24 enemy soldiers, including airborne drops
- Player-vs-bot and bot-vs-bot combat
- Weapons: pistol, rifle, shotgun, sniper
- Weapon ammo, reload, ADS, recoil, spread and hit detection
- Loot: weapons, ammo and medkits
- Moving multi-phase safe zone with damage
- Minimap / full map with zone, plane, loot and nearby enemies
- Kill feed, enemy counter and victory / defeat screens
- Touch controls and PC controls

## Asset behavior
The game first looks for real 3D models inside `res://assets/models` and uses them when their filename matches a weapon. If a model is absent, the procedural model remains active, so the game does not break.
