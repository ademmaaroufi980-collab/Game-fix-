# Fix report - Squad of Blood Battle Royale

## Fixed in this version
1. **Export-safe asset loading** (`asset_bridge.gd`): models are found through known paths + `ResourceLoader.exists`, and the folder scan understands `.import` / `.remap` names, so weapons and the samurai no longer fall back to boxes in an exported build. Short stems (< 4 letters, e.g. `awm`) are matched exactly only.
2. **Weapon orientation**: `pistol`, `shootgun1` and `awm` face +Z in their files; they are now turned 180 degrees (per-model table `AssetBridge.FIX`) and scaled/offset so they sit in the view like the old procedural guns. Muzzle flash positions for imported guns come from `AssetBridge.MUZZLE`.
3. **"Ground" preview planes** inside `pistol.glb` and `sammuray.glb` are removed when a model is loaded.
4. **Samurai skin in first person**: drawn only as a shadow; drawn normally in the third-person plane view.
5. **Invisible walls** around the imported map (they were deleted together with the old arena).
6. **Real buildings instead of fake ones**: loot indoors now uses the map's own `LOOT_*` markers; minimap houses, "covers" checks and paratrooper landing use the real building footprints read from the map.
7. **Outdoor spawns**: enemies / loot are only placed on open ground (terrain layer `TERRAIN`, project layer 5): never on roofs, inside buildings, under trees or high on mountains.
8. **Minimap**: the old `BrTerrain` lookup always failed with the imported map; the picture is now rendered from the real map heights. Removed the old "valley" rectangle.
9. **Performance**: trees and rocks (~900) are culled beyond 170 m and no longer cast shadows.
10. `weapon_data.gd` model enum now lists the real model names (`ak47`, `shootgun1`, `awm`).

## Still not tested
Godot is not installed in this environment, so the project was NOT run. Open it in Godot 4.7, let it re-import, and check the Output panel. Things worth a look in play: ADS (aim) height of the three imported guns (`ads_y` in `weapons/*.tres`) and the samurai's facing direction.
