class_name TouchControls
extends Control
## On-screen controls for phones and tablets: a floating move stick, drag-to-look and action
## buttons. Created by GameUI whenever Settings.use_touch() is true.
## Choosing "Mobile" in Settings on a desktop also works: the mouse then acts as one finger,
## so the layout can be tested without a phone.
##
## Layout (landscape):
##   left 40% of the screen   floating stick (push fully up to sprint)
##   rest of the screen       drag to look
##   bottom right             FIRE (hold; dragging while holding also looks), AIM (toggle),
##                            JUMP, RELOAD, DASH, CROUCH (toggle)
##   weapon name (top right)  tap to switch weapon
##   small button top right   pause

const LOOK_GAIN := 1.6       # touch-drag pixels -> mouse-look pixels
const STICK_DEAD := 0.12
const SPRINT_AT := 0.92      # stick length that starts a sprint
const MIN_PRESS := 0.08      # seconds a tap stays pressed so the physics tick sees it
const MOUSE_FINGER := 100    # pseudo finger index for the mouse (desktop testing)
const MOVE_ACTIONS: Array[String] = ["move_left", "move_right", "move_forward", "move_backward", "sprint", "crouch", "prone", "jump", "dash"]

var ui: GameUI
var player: Player
var wm: WeaponManager

var fingers := {}            # finger index -> role ("stick", "look", "weapon", "btn:<name>")
var pressed_btn := {}        # button name -> true while a finger is on it
var stick_finger := -1
var stick_center := Vector2.ZERO
var stick_vec := Vector2.ZERO
var aim_on := false
var crouch_on := false


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)


func _exit_tree() -> void:
	release_all()


# ------------------------------------------------------------------ layout

func _unit() -> float:
	return clampf(minf(size.x, size.y) * 0.12, 48.0, 100.0)


func _buttons() -> Dictionary:
	var s := size
	var u := _unit()
	return {
		"fire": {"pos": Vector2(s.x - 1.9 * u, s.y - 1.9 * u), "r": 1.0 * u, "label": "FIRE"},
		"jump": {"pos": Vector2(s.x - 1.5 * u, s.y - 4.3 * u), "r": 0.65 * u, "label": "JUMP"},
		"aim": {"pos": Vector2(s.x - 4.1 * u, s.y - 1.5 * u), "r": 0.7 * u, "label": "AIM"},
		"reload": {"pos": Vector2(s.x - 4.4 * u, s.y - 3.5 * u), "r": 0.55 * u, "label": "RELOAD"},
		"dash": {"pos": Vector2(s.x - 3.0 * u, s.y - 5.4 * u), "r": 0.55 * u, "label": "DASH"},
		"crouch": {"pos": Vector2(s.x - 6.0 * u, s.y - 1.4 * u), "r": 0.55 * u, "label": "CROUCH"},
		"prone": {"pos": Vector2(s.x - 7.4 * u, s.y - 3.0 * u), "r": 0.55 * u, "label": "PRONE"},
		"pause": {"pos": Vector2(s.x - 0.7 * u, 2.4 * u), "r": 0.4 * u, "label": "II"},
	}


## The ammo/weapon block in the HUD (top right while touch controls are on).
func _weapon_rect() -> Rect2:
	return Rect2(size.x - 320.0, 12.0, 296.0, 110.0)


func _button_at(pos: Vector2) -> String:
	var best := ""
	var best_d := INF
	var btns := _buttons()
	for key in btns:
		var b: Dictionary = btns[key]
		var d: float = (b["pos"] as Vector2).distance_to(pos)
		if d <= float(b["r"]) * 1.15 and d < best_d:
			best = key
			best_d = d
	return best


# ------------------------------------------------------------------ input

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		_touch(event.index, event.position, event.pressed)
	elif event is InputEventScreenDrag:
		_drag(event.index, event.position, event.relative)
	elif _mouse_as_finger():
		if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
			_touch(MOUSE_FINGER, event.position, event.pressed)
		elif event is InputEventMouseMotion and fingers.has(MOUSE_FINGER):
			_drag(MOUSE_FINGER, event.position, event.relative)


## On real phones the engine already sends touch events; on a desktop the mouse stands in.
func _mouse_as_finger() -> bool:
	return not (OS.has_feature("mobile") or OS.has_feature("web_android") or OS.has_feature("web_ios"))


func _touch(idx: int, pos: Vector2, down: bool) -> void:
	if down:
		if not fingers.has(idx):
			_claim(idx, pos)
	else:
		_release_finger(idx)
	queue_redraw()


func _claim(idx: int, pos: Vector2) -> void:
	var btn := _button_at(pos)
	if btn != "":
		fingers[idx] = "btn:" + btn
		pressed_btn[btn] = true
		_press(btn)
		return
	if _weapon_rect().has_point(pos):
		fingers[idx] = "weapon"
		if is_instance_valid(wm):
			wm.next_weapon()
		return
	if pos.x < size.x * 0.4 and stick_finger == -1:
		fingers[idx] = "stick"
		stick_finger = idx
		stick_center = pos
		stick_vec = Vector2.ZERO
		return
	fingers[idx] = "look"


func _drag(idx: int, pos: Vector2, rel: Vector2) -> void:
	var role: String = fingers.get(idx, "")
	if role == "stick":
		_update_stick(pos)
	elif role == "look" or role == "btn:fire":
		if is_instance_valid(player):
			player.look(rel, LOOK_GAIN)
	queue_redraw()


func _release_finger(idx: int) -> void:
	var role: String = fingers.get(idx, "")
	fingers.erase(idx)
	if role == "stick":
		stick_finger = -1
		stick_vec = Vector2.ZERO
		_apply_stick()
	elif role.begins_with("btn:"):
		var btn := role.substr(4)
		pressed_btn.erase(btn)
		_release(btn)


# ------------------------------------------------------------------ stick

func _update_stick(pos: Vector2) -> void:
	var radius := _unit() * 1.3
	var off := pos - stick_center
	if off.length() > radius:
		stick_center += off.normalized() * (off.length() - radius)   # the base follows the thumb
		off = pos - stick_center
	stick_vec = off / radius
	_apply_stick()


func _apply_stick() -> void:
	var v := stick_vec
	if v.length() < STICK_DEAD:
		v = Vector2.ZERO
	_axis("move_left", "move_right", v.x)
	_axis("move_forward", "move_backward", v.y)
	_set_action("sprint", v.y < -0.5 and v.length() > SPRINT_AT)


func _axis(neg: String, pos: String, value: float) -> void:
	if value < 0.0:
		Input.action_press(neg, -value)
		Input.action_release(pos)
	elif value > 0.0:
		Input.action_press(pos, value)
		Input.action_release(neg)
	else:
		Input.action_release(neg)
		Input.action_release(pos)


func _set_action(action: String, on: bool) -> void:
	if on:
		Input.action_press(action)
	else:
		Input.action_release(action)


# ------------------------------------------------------------------ buttons

func _press(btn: String) -> void:
	match btn:
		"fire":
			if is_instance_valid(wm):
				wm.touch_fire = true
		"aim":
			aim_on = not aim_on
			if is_instance_valid(wm):
				wm.touch_aim = aim_on
		"jump", "dash", "prone":
			Input.action_press(btn)
		"reload":
			if is_instance_valid(wm):
				wm.reload()
		"crouch":
			crouch_on = not crouch_on
			_set_action("crouch", crouch_on)
		"pause":
			if is_instance_valid(ui):
				ui.pause()


func _release(btn: String) -> void:
	match btn:
		"fire":
			if is_instance_valid(wm):
				wm.touch_fire = false
		"jump", "dash", "prone":
			_release_later(btn)


func _release_later(action: String) -> void:
	await get_tree().create_timer(MIN_PRESS).timeout
	Input.action_release(action)


## Lets go of everything (pause, results screen, leaving the arena, switching to PC controls).
func release_all() -> void:
	fingers.clear()
	pressed_btn.clear()
	stick_finger = -1
	stick_vec = Vector2.ZERO
	aim_on = false
	crouch_on = false
	if is_instance_valid(wm):
		wm.touch_fire = false
		wm.touch_aim = false
	for a in MOVE_ACTIONS:
		Input.action_release(a)
	queue_redraw()


# ------------------------------------------------------------------ drawing

func _draw() -> void:
	var font := ThemeDB.fallback_font
	var u := _unit()

	# Stick: a faint ring where it will appear, then wherever the thumb went down
	var active := stick_finger != -1
	var base := stick_center if active else Vector2(2.2 * u, size.y - 2.4 * u)
	var radius := u * 1.3
	draw_circle(base, radius, Color(1, 1, 1, 0.07))
	draw_arc(base, radius, 0.0, TAU, 48, Color(1, 1, 1, 0.3), 2.0)
	var knob := base + (stick_vec * radius if active else Vector2.ZERO)
	draw_circle(knob, u * 0.5, Color(1, 1, 1, 0.45 if active else 0.2))

	# Buttons
	var btns := _buttons()
	for key in btns:
		var b: Dictionary = btns[key]
		var pos: Vector2 = b["pos"]
		var r: float = b["r"]
		var on: bool = pressed_btn.has(key) or (key == "aim" and aim_on) or (key == "crouch" and crouch_on)
		var col := Color(1.0, 0.7, 0.3) if on else Color.WHITE
		draw_circle(pos, r, Color(col.r, col.g, col.b, 0.28 if on else 0.12))
		draw_arc(pos, r, 0.0, TAU, 40, Color(col.r, col.g, col.b, 0.55), 2.0)
		var fs := int(maxf(12.0, r * 0.38))
		draw_string(font, pos + Vector2(-r, fs * 0.35), b["label"], HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, fs, Color(1, 1, 1, 0.85))

	# Weapon switch zone
	var wr := _weapon_rect()
	draw_rect(wr, Color(1, 1, 1, 0.05))
	draw_rect(wr, Color(1, 1, 1, 0.2), false, 1.5)
