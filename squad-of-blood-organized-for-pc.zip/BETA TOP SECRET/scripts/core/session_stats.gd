class_name SessionStats
extends RefCounted
## Per-run shooting statistics shown in the pause and results screens.

var shots := 0
var hits := 0
var headshots := 0
var kills := 0
var best_streak := 0


func accuracy() -> float:
	return float(hits) / float(shots) if shots > 0 else 0.0


func summary() -> String:
	return "Accuracy %d%%  ·  Headshots %d  ·  Kills %d  ·  Best streak %d" % [roundi(accuracy() * 100.0), headshots, kills, best_streak]
