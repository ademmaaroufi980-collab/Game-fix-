class_name Layers
extends RefCounted
## Physics layer bitmasks. Names are also set in Project Settings > Layer Names > 3D Physics.

const WORLD := 1     # terrain, crates, platforms
const WALLS := 2     # invisible map border (only the player collides)
const PLAYER := 4
const TARGETS := 8
const TERRAIN := 16   # only the ground of the imported BR map (used to tell ground from roofs / trees)
