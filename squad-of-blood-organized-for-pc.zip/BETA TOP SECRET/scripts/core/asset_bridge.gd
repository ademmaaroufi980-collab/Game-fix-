class_name AssetBridge
extends RefCounted
## 3D asset bridge. Loads the supplied .glb models from res://assets/models and falls back to the
## built-in procedural models when a file is missing.
##
## Export-safe: in an exported game the original .glb files are not on disk any more (only the
## imported copies), so the files are found through the known paths below and through
## ResourceLoader, and the directory scan also understands the ".import" / ".remap" names.

const KNOWN := {
	"pistol": "res://assets/models/pistol.glb",
	"ak47": "res://assets/models/ak47.glb",
	"shootgun1": "res://assets/models/shootgun1.glb",
	"awm": "res://assets/models/awm.glb",
	"sammuray": "res://assets/models/sammuray.glb",
}

## Per-model correction for the first-person view (yaw in degrees, offset, scale).
## pistol / shootgun1 / awm are modelled with the muzzle towards +Z, Godot wants -Z, so they turn 180 degrees.
const FIX := {
	"pistol": {"yaw": 180.0, "pos": Vector3(0.0, -0.03, -0.10), "scale": 1.0},
	"ak47": {"yaw": 0.0, "pos": Vector3(0.0, -0.02, -0.28), "scale": 1.0},
	"shootgun1": {"yaw": 180.0, "pos": Vector3(0.0, -0.01, -0.20), "scale": 0.8},
	"awm": {"yaw": 180.0, "pos": Vector3(0.0, 0.0, -0.10), "scale": 0.7},
}

## Muzzle position (view space) once the model above is placed. Used for the muzzle flash.
const MUZZLE := {
	"pistol": Vector3(0.0, 0.02, -0.23),
	"ak47": Vector3(0.0, 0.03, -0.82),
	"shootgun1": Vector3(0.0, 0.02, -0.83),
	"awm": Vector3(0.0, 0.0, -0.90),
}

static var _scan_done := false
static var _paths: Dictionary = {}


static func prepare() -> void:
	if _scan_done:
		return
	_scan_done = true
	for k in KNOWN:
		if ResourceLoader.exists(KNOWN[k]):
			_paths[k] = KNOWN[k]
	_scan_dir("res://assets/models")


static func _scan_dir(path: String) -> void:
	var dir := DirAccess.open(path)
	if dir == null:
		return
	dir.list_dir_begin()
	while true:
		var fname := dir.get_next()
		if fname == "":
			break
		if fname.begins_with("."):
			continue
		if dir.current_is_dir():
			_scan_dir(path.path_join(fname))
			continue
		# Exported builds list "model.glb.import" / "model.glb.remap" instead of "model.glb"
		if fname.ends_with(".import") or fname.ends_with(".remap"):
			fname = fname.get_basename()
		var ext := fname.get_extension().to_lower()
		if ext not in ["glb", "gltf", "obj", "fbx"]:
			continue
		var stem := fname.get_basename().to_lower()
		if _paths.has(stem):
			continue
		var full := path.path_join(fname)
		if ResourceLoader.exists(full):
			_paths[stem] = full
	dir.list_dir_end()


## Creates the model under `parent` and returns a holder Node3D (callers move / rotate the holder).
## `view` = true applies the first-person correction from FIX.
static func instantiate(parent: Node3D, key: String, view := false) -> Node3D:
	prepare()
	var k := key.to_lower().strip_edges()
	var path := _find_path(k)
	if path == "":
		return null
	var resource: Resource = load(path)
	var model: Node3D = null
	if resource is PackedScene:
		var inst := (resource as PackedScene).instantiate()
		if inst is Node3D:
			model = inst as Node3D
		elif inst != null:
			inst.free()
	elif resource is Mesh:
		var mi := MeshInstance3D.new()
		mi.mesh = resource as Mesh
		model = mi
	if model == null:
		return null
	_strip_ground(model)
	var fix: Dictionary = FIX.get(k, {})
	model.rotation_degrees.y = float(fix.get("yaw", 0.0))
	if view:
		model.position = fix.get("pos", Vector3.ZERO)
		model.scale = Vector3.ONE * float(fix.get("scale", 1.0))
	var holder := Node3D.new()
	holder.name = "Asset_" + k
	holder.add_child(model)
	parent.add_child(holder)
	return holder


## Some models ship with a "Ground" preview plane (pistol: 1.5 m, samurai: 8 m). Remove it.
static func _strip_ground(node: Node) -> void:
	for child in node.get_children():
		if String(child.name).to_lower().begins_with("ground"):
			node.remove_child(child)
			child.free()
		else:
			_strip_ground(child)


static func _find_path(key: String) -> String:
	if _paths.has(key):
		return _paths[key]
	for stem in _paths.keys():
		var s := String(stem)
		if s.length() >= 4 and (s.contains(key) or key.contains(s)):
			return _paths[s]
	return ""
