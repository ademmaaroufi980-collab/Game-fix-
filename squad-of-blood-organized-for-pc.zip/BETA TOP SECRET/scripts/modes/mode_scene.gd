extends Node3D
## Root script of every mode scene (scenes/modes/*.tscn). Each mode scene inherits
## scenes/arena.tscn and only sets which mode it is. Registering the mode in _enter_tree
## means it is already set before any child _ready runs, so a mode scene can also be
## launched directly from the editor (F6) without going through the lobby.

@export_enum("free", "timed", "rounds", "br") var mode_key: String = "free"


func _enter_tree() -> void:
	Game.set_mode(mode_key)
