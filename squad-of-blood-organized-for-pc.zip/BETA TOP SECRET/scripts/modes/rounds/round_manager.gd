class_name RoundManager
extends Node
## Round mode. Each round turns on a random set of targets; clear them before the round timer
## runs out to earn a time bonus. Every round has more targets and less time per target.
## Running out of time ends the run. Created by GameUI when Game.rounds is set.

const START_DELAY := 2.0     # "GET READY" pause before round 1
const INTERMISSION := 3.0    # pause between rounds
const MIN_TIME := 20.0       # no round is ever shorter than this
const BASE_TIME := 15.0      # seconds, plus TIME_PER_TARGET for every target
const TIME_PER_TARGET := 3.0
const TIME_LOSS_PER_ROUND := 2.0
const TIME_BONUS_PER_SEC := 10
const CLEAR_BONUS_PER_ROUND := 50

var ui: GameUI

var round_no := 0
var time_left := 0.0
var alive := 0
var total := 0
var running := false
var over := false
var wait := START_DELAY
var all_targets: Array[Target] = []
var is_set_up := false


func _ready() -> void:
	# GameUI is built before the arena's targets, so wait until they have finished _ready().
	_setup.call_deferred()


func _setup() -> void:
	for n in get_tree().get_nodes_in_group("targets"):
		if n is Target:
			var t := n as Target
			t.managed = true
			t.set_active(false)
			t.died.connect(_on_target_died)
			all_targets.append(t)
	wait = START_DELAY
	ui.set_round_info(0, 0, 0)
	ui.show_banner("GET READY", "", START_DELAY)
	is_set_up = true


func _process(delta: float) -> void:
	if not is_set_up or over:
		return
	if running:
		time_left = maxf(0.0, time_left - delta)
		ui.show_time(time_left)
		if time_left <= 0.0:
			_fail()
	else:
		wait -= delta
		if wait <= 0.0:
			_start_round()


func _start_round() -> void:
	round_no += 1
	total = mini(3 + (round_no - 1) * 2, all_targets.size())
	time_left = maxf(MIN_TIME, BASE_TIME + total * TIME_PER_TARGET - (round_no - 1) * TIME_LOSS_PER_ROUND)

	var pool: Array = all_targets.duplicate()
	pool.shuffle()
	var level := 1.0 + (round_no - 1) * 0.15   # enemies aim and shoot faster every round
	for i in pool.size():
		var t := pool[i] as Target
		t.ai_level = level
		t.set_active(i < total)

	alive = total
	running = true
	if ui.wm:
		ui.wm.refill()   # a fresh round starts with full reserves
	ui.set_round_info(round_no, alive, total)
	ui.show_time(time_left)
	ui.show_banner("ROUND %d" % round_no, "%d targets  ·  %d seconds" % [total, ceili(time_left)], 2.0)


func _on_target_died() -> void:
	if not running:
		return
	alive -= 1
	ui.set_round_info(round_no, alive, total)
	if alive <= 0:
		_clear.call_deferred()   # let the killing shot finish scoring first


func _clear() -> void:
	if not running:
		return
	running = false
	var bonus := roundi(time_left) * TIME_BONUS_PER_SEC + round_no * CLEAR_BONUS_PER_ROUND
	ui.add_score(bonus, "ROUND CLEAR")
	ui.show_banner("ROUND %d CLEARED" % round_no, "Time bonus  +%d" % bonus, INTERMISSION - 0.5)
	wait = INTERMISSION


func _fail() -> void:
	running = false
	over = true
	ui.end_run("GAME OVER", "Reached round %d  ·  Cleared %d" % [round_no, round_no - 1])
