extends Node3D
## Battle Royale plane: flies straight across the valley, banks round a turn at each border and flies back.
## The plane is built from simple meshes (no model file needed) and removes itself in other modes.

const ALTITUDE := 130.0
const SPEED := 28.0            # metres per second along the path
const HALF_STRAIGHT := 110.0   # the plane flies straight along x between -110 and +110 ...
const TURN_RADIUS := 90.0      # ... then banks round a half circle and flies back (reaches x = +-200)
const BANK_MAX := 0.65         # roll in the middle of a turn (radians, about 37 degrees)

var dist := 0.0


func _ready() -> void:
	if not Game.br:
		queue_free()
		return
	_build_plane()
	_update_pose()


func _process(delta: float) -> void:
	dist += SPEED * delta
	_update_pose()


## Point `s` metres along the flight path (a loop: straight, turn, straight back, turn).
## Returns [position (x, z) as Vector2, heading as unit Vector2, bank in radians (+ = right wing down)].
## Also used by the minimap to draw the path.
static func sample(s: float) -> Array:
	var l := 2.0 * HALF_STRAIGHT
	var c := PI * TURN_RADIUS
	s = fposmod(s, 2.0 * l + 2.0 * c)
	if s < l:
		return [Vector2(-HALF_STRAIGHT + s, -TURN_RADIUS), Vector2(1, 0), 0.0]
	s -= l
	if s < c:
		var th := s / TURN_RADIUS
		return [Vector2(HALF_STRAIGHT, 0.0) + TURN_RADIUS * Vector2(sin(th), -cos(th)), Vector2(cos(th), sin(th)), BANK_MAX * sin(th)]
	s -= c
	if s < l:
		return [Vector2(HALF_STRAIGHT - s, TURN_RADIUS), Vector2(-1, 0), 0.0]
	s -= l
	var th2 := s / TURN_RADIUS
	return [Vector2(-HALF_STRAIGHT, 0.0) + TURN_RADIUS * Vector2(-sin(th2), cos(th2)), Vector2(-cos(th2), -sin(th2)), BANK_MAX * sin(th2)]


static func lap_length() -> float:
	return 4.0 * HALF_STRAIGHT + 2.0 * PI * TURN_RADIUS


func _update_pose() -> void:
	var d := sample(dist)
	var p: Vector2 = d[0]
	var h: Vector2 = d[1]
	var pos := Vector3(p.x, ALTITUDE, p.y)
	global_position = pos
	look_at(pos + Vector3(h.x, 0.0, h.y), Vector3.UP)      # nose = -Z
	rotate_object_local(Vector3.FORWARD, float(d[2]))      # bank into the turn


func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.6
	m.metallic = 0.2
	m.disable_fog = true
	return m


func _part(mesh: Mesh, color: Color, pos: Vector3, rot := Vector3.ZERO) -> void:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = _mat(color)
	mi.position = pos
	mi.rotation = rot
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)


func _build_plane() -> void:
	var body := Color(0.78, 0.8, 0.82)
	var dark := Color(0.25, 0.28, 0.32)
	var accent := Color(0.7, 0.12, 0.1)

	# Fuselage (cylinder lying along Z) and nose cone
	var fus := CylinderMesh.new()
	fus.top_radius = 1.4
	fus.bottom_radius = 1.4
	fus.height = 18.0
	fus.radial_segments = 16
	_part(fus, body, Vector3.ZERO, Vector3(PI / 2, 0, 0))

	var nose := CylinderMesh.new()
	nose.top_radius = 0.0
	nose.bottom_radius = 1.4
	nose.height = 4.0
	nose.radial_segments = 16
	_part(nose, accent, Vector3(0, 0, -11.0), Vector3(-PI / 2, 0, 0))

	# Tail cone
	var tail := CylinderMesh.new()
	tail.top_radius = 1.4
	tail.bottom_radius = 0.4
	tail.height = 5.0
	tail.radial_segments = 16
	_part(tail, body, Vector3(0, 0.3, 11.5), Vector3(-PI / 2, 0, 0))

	# Main wings, tail wings, vertical fin
	var wing := BoxMesh.new()
	wing.size = Vector3(26.0, 0.35, 4.0)
	_part(wing, dark, Vector3(0, -0.4, 1.0))

	var hwing := BoxMesh.new()
	hwing.size = Vector3(9.0, 0.25, 2.4)
	_part(hwing, dark, Vector3(0, 0.4, 12.5))

	var fin := BoxMesh.new()
	fin.size = Vector3(0.3, 3.8, 2.8)
	_part(fin, accent, Vector3(0, 2.2, 12.3))

	# Engines under the wings
	var eng := CylinderMesh.new()
	eng.top_radius = 0.7
	eng.bottom_radius = 0.7
	eng.height = 3.2
	_part(eng, dark, Vector3(-6.0, -1.2, 0.0), Vector3(PI / 2, 0, 0))
	_part(eng, dark, Vector3(6.0, -1.2, 0.0), Vector3(PI / 2, 0, 0))
