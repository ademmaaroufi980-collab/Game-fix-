extends Node
## Battle Royale mode: ride the plane, jump out, open the parachute and land in a valley with mountains around.
## Weapons, ammo and medkits lie around the map (see br_loot.gd). Enemy soldiers are scattered over the valley: kill them all to win. Press jump on the plane to drop, jump again in the air to open the parachute.
## Does nothing in the other modes.

const UIStyle = preload("res://scripts/ui/theme/ui_style.gd")

const TERMINAL_SPEED := 55.0   # max fall speed (m/s)
const CHUTE_FALL_SPEED := 7.0  # fall speed with the parachute open (m/s)
const CHUTE_BRAKE := 60.0      # how quickly the parachute slows you down (m/s^2)
const PLANE_CAM_DIST := 32.0   # camera distance from the plane while riding it (outside view)
const ENEMY_COUNT := 24        # soldiers in the match (ground soldiers + paratroopers)
const PARATROOPERS := 24       # everybody jumps out of the plane, just like the player
const DROP_INTERVAL := 2.0     # jumps are random: 0.4 s up to 1.5 x this between two jumps
const TROOPER_FALL := 9.0      # parachute descent speed of the soldiers (m/s)
const ENEMY_AREA := 230.0      # use most of the supplied map while staying inside the safe playable area
const ENEMY_SPACING := 22.0    # minimum distance between two soldiers when they spawn
const NAMES: Array = ["VIPER", "GHOST", "RAZOR", "HAWK", "WOLF", "COBRA", "REAPER", "TITAN", "RAVEN", "BLADE", "STORM", "DINGO", "FALCON", "VENOM", "ROOK", "SHADE", "ONYX", "BISON", "LYNX", "ORCA", "JACKAL", "MAMBA", "PHOENIX", "NOMAD"]
const FEED_MAX := 6            # kill notifications on screen at once
const FEED_TIME := 5.0         # seconds a notification stays
const LOOT_WEAPONS := {"rifle": 8, "shotgun": 6, "sniper": 4}   # weapons lying on the map
const LOOT_AMMO := 22
const LOOT_MEDKITS := 14
const LOOT_SPACING := 14.0     # minimum distance between two loot items
const HOUSE_LOOT := 2          # loot items lying inside every house
const SEAT_OFFSET := Vector3(0.0, -1.5, 0.0)   # feet below the plane centre, so the eyes sit inside

var player: Player
var plane: Node3D
var in_plane := true
var prompt: Label
var chute_open := false
var landed := false
var canopy: MeshInstance3D
var enemies: Array[Target] = []
var enemies_left := 0
var ui: GameUI
var terrain: Node3D
var map_asset: Node3D
var won := false
var feed: VBoxContainer
var houses: BrHouses
var zone: BrZone
var names: Array = []
var awake := false              # true once the player has landed: the soldiers start fighting
var to_drop := 0                # paratroopers still inside the plane
var drop_timer := 3.0
var troopers: Array = []        # soldiers currently in the air: {t, h, chute}


func _ready() -> void:
	if not Game.br:
		queue_free()
		return
	_setup.call_deferred()


func _setup() -> void:
	var root := get_parent()
	player = get_tree().get_first_node_in_group("player") as Player
	plane = root.get_node_or_null("BrPlane") as Node3D
	if player == null or plane == null:
		return

	# Remove the normal arena world; the supplied GLB is the actual BR play space.
	for n in root.get_children():
		if n == self:
			continue
		if n is StaticBody3D or n is Area3D or n.is_in_group("targets") or n.name == "Trees":
			n.queue_free()

	_build_ground(root)
	await get_tree().physics_frame
	_build_feed()
	# Keep house metadata for loot placement, but hide its generated geometry because
	# the supplied map already contains the buildings.
	houses = BrHouses.new()
	houses.name = "BrHouses"
	root.add_child(houses)
	houses.visible = false
	# The generated boxes are not used: drop them and describe the REAL buildings of the map instead
	# (minimap, spawn checks).
	for c in houses.get_children():
		c.queue_free()
	houses.body = null
	_collect_buildings()
	zone = BrZone.new()
	zone.name = "BrZone"
	root.add_child(zone)
	_spawn_loot(root)
	_spawn_enemies(root)
	_build_prompt()
	_board_plane()
	_show_intro.call_deferred()


## The BR map: flat valley with mountains all around (see br_terrain.gd).
func _build_ground(root: Node) -> void:
	map_asset = preload("res://assets/models/map.glb").instantiate() as Node3D
	map_asset.name = "BattleRoyaleMap"
	root.add_child(map_asset)
	terrain = map_asset
	_configure_map_physics(map_asset)
	_optimize_map(map_asset)
	_build_walls(root)


func _configure_map_physics(node: Node) -> void:
	# GLB collision bodies can import with their own/default physics layers.
	# Force every static collision in the supplied map onto the game's WORLD layer
	# so movement, bullets, loot placement and zone navigation all agree.
	if node is StaticBody3D:
		var body := node as StaticBody3D
		body.collision_layer = Layers.WORLD
		body.collision_mask = Layers.PLAYER | Layers.TARGETS
		# The ground gets an extra layer, so a ray can tell "ground" from "roof / tree / prop".
		var owner_name := String(body.get_parent().name).to_lower() if body.get_parent() != null else ""
		if owner_name.contains("terrain") or String(body.name).to_lower().contains("terrain"):
			body.collision_layer = Layers.WORLD | Layers.TERRAIN
	for child in node.get_children():
		_configure_map_physics(child)


func _ground_y(x: float, z: float) -> float:
	var space := get_viewport().get_world_3d().direct_space_state
	var from := Vector3(x, 300.0, z)
	var to := Vector3(x, -50.0, z)
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.collision_mask = Layers.WORLD
	query.collide_with_areas = false
	var hit := space.intersect_ray(query)
	if not hit.is_empty():
		return float(hit.position.y)
	return 0.0


## Soldiers (now only paratroopers: everyone competes for the win). They stay frozen until you land, never respawn,
## and killing the last one wins the match.
func _spawn_enemies(root: Node) -> void:
	ui = get_tree().get_first_node_in_group("hud") as GameUI
	var spots: Array[Vector2] = []
	var tries := 0
	var ground := ENEMY_COUNT - PARATROOPERS
	while spots.size() < ground and tries < 2000:
		tries += 1
		var p := Vector2(randf_range(-ENEMY_AREA, ENEMY_AREA), randf_range(-ENEMY_AREA, ENEMY_AREA))
		var ok := is_finite(_surface(p.x, p.y))
		for q in spots:
			if p.distance_to(q) < ENEMY_SPACING:
				ok = false
				break
		if ok:
			spots.append(p)
	for p in spots:
		var t := _make_enemy(root)
		var sy := _surface(p.x, p.y)
		t.global_position = Vector3(p.x, (sy if is_finite(sy) else _ground_y(p.x, p.y)) + 0.3, p.y)
	to_drop = PARATROOPERS
	enemies_left = enemies.size() + to_drop
	_update_counter()


## Scatters weapons, ammo boxes and medkits over the valley.
func _spawn_loot(root: Node) -> void:
	var kinds: Array[String] = []
	for k in LOOT_WEAPONS:
		for n in int(LOOT_WEAPONS[k]):
			kinds.append(k)
	for n in LOOT_AMMO:
		kinds.append("ammo")
	for n in LOOT_MEDKITS:
		kinds.append("medkit")
	var spots: Array[Vector2] = []
	var tries := 0
	while spots.size() < kinds.size() and tries < 4000:
		tries += 1
		var p := Vector2(randf_range(-ENEMY_AREA, ENEMY_AREA), randf_range(-ENEMY_AREA, ENEMY_AREA))
		var ok := is_finite(_surface(p.x, p.y))
		for q in spots:
			if p.distance_to(q) < LOOT_SPACING:
				ok = false
				break
		if ok:
			spots.append(p)
	kinds.shuffle()
	for i in spots.size():
		var sy := _surface(spots[i].x, spots[i].y)
		_make_loot(root, kinds[i], Vector3(spots[i].x, sy if is_finite(sy) else _ground_y(spots[i].x, spots[i].y), spots[i].y))
	# Buildings hold the good stuff: the map has a LOOT_* marker inside every building
	var indoor: Array[String] = ["rifle", "shotgun", "sniper", "rifle", "ammo", "medkit"]
	var markers: Array = []
	if map_asset != null:
		markers = map_asset.find_children("LOOT_*", "Node3D", true, false)
	for m in markers:
		var mp := (m as Node3D).global_position
		for n in HOUSE_LOOT:
			var off := Vector2.ZERO if n == 0 else Vector2(randf_range(-1.8, 1.8), randf_range(-1.8, 1.8))
			var fy := _floor_y(mp.x + off.x, mp.y + 0.6, mp.z + off.y)
			_make_loot(root, indoor[randi() % indoor.size()], Vector3(mp.x + off.x, fy + 0.05, mp.z + off.y))


func _make_loot(root: Node, kind: String, pos: Vector3) -> void:
	var l := Loot.new()
	l.kind = kind
	root.add_child(l)
	l.global_position = pos


## A dead soldier drops something: ammo, a medkit or sometimes a weapon.
func _drop_loot(pos: Vector3) -> void:
	var r := randf()
	var kind := "ammo"
	if r < 0.35:
		kind = "medkit"
	elif r < 0.6:
		kind = ["rifle", "shotgun", "sniper"][randi() % 3]
	_make_loot(get_parent(), kind, pos)


## Creates one soldier: no respawn, asleep until the player has landed.
func _make_enemy(root: Node) -> Target:
	var t := Target.new()
	t.managed = true            # no respawn: a dead soldier stays dead
	t.br_fight = true           # soldiers also shoot each other
	t.roam = true               # nobody stands guard: everyone roams the map for loot and fights
	if names.is_empty():
		names = NAMES.duplicate()
		names.shuffle()
	t.display_name = str(names.pop_back()) if not names.is_empty() else "BOT"
	t.killed_by.connect(_on_killed_by)
	t.player_killed.connect(func(by: Target) -> void: _feed_add(by.display_name, "YOU", true))
	t.patrol_dir = Vector3(randf_range(-1.0, 1.0), 0.0, randf_range(-1.0, 1.0))
	t.patrol_range = randf_range(4.0, 9.0)
	root.add_child(t)
	t.set_physics_process(false)
	t.died.connect(_on_enemy_died)
	enemies.append(t)
	return t


## A soldier jumps out of the plane and floats down under a parachute.
func _drop_trooper() -> void:
	var t := _make_enemy(get_parent())
	var fwd := -plane.global_basis.z
	t.global_position = plane.global_position + Vector3(randf_range(-3.0, 3.0), -2.5, randf_range(-3.0, 3.0))
	t.pivot.rotation.y = atan2(-fwd.x, -fwd.z)
	t.set_meta("air", true)
	var chute := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 2.0
	mesh.height = 2.0
	mesh.is_hemisphere = true
	mesh.radial_segments = 16
	mesh.rings = 6
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.55, 0.12, 0.1)
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	chute.mesh = mesh
	chute.material_override = mat
	chute.position = Vector3(0.0, 3.3, 0.0)
	chute.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	t.add_child(chute)
	t.set_meta("fall", randf_range(6.5, 11.0))
	# every soldier picks its own random landing spot and steers there
	var land := Vector2(randf_range(-ENEMY_AREA, ENEMY_AREA), randf_range(-ENEMY_AREA, ENEMY_AREA))
	for k in 20:
		if not houses.covers(land, 4.0) and is_finite(_surface(land.x, land.y)):
			break   # never land on a roof, inside a wall or high on a mountain
		land = Vector2(randf_range(-ENEMY_AREA, ENEMY_AREA), randf_range(-ENEMY_AREA, ENEMY_AREA))
	troopers.append({"t": t, "h": Vector2(fwd.x, fwd.z) * 18.0, "chute": chute, "land": land})


func _update_troopers(delta: float) -> void:
	if to_drop > 0 and plane != null:
		drop_timer -= delta
		if drop_timer <= 0.0:
			drop_timer = randf_range(0.4, DROP_INTERVAL * 1.5)   # random gaps between jumps
			to_drop -= 1
			_drop_trooper()
	for i in range(troopers.size() - 1, -1, -1):
		var d: Dictionary = troopers[i]
		var t: Target = d["t"]
		if not is_instance_valid(t):
			troopers.remove_at(i)
			continue
		if t.dead:   # shot in the air: drop the parachute and fall (gravity is back on)
			_trooper_down(d, false)
			troopers.remove_at(i)
			continue
		var h: Vector2 = d["h"]
		var pos := t.global_position
		var to_land: Vector2 = (d["land"] as Vector2) - Vector2(pos.x, pos.z)
		var want := Vector2.ZERO
		if to_land.length() > 4.0:
			want = to_land.normalized() * minf(13.0, to_land.length() * 0.5 + 3.0)
		h = h.move_toward(want, 9.0 * delta)
		d["h"] = h
		pos.x = clampf(pos.x + h.x * delta, -ENEMY_AREA, ENEMY_AREA)
		pos.z = clampf(pos.z + h.y * delta, -ENEMY_AREA, ENEMY_AREA)
		pos.y -= float(t.get_meta("fall", TROOPER_FALL)) * delta
		var ground: float = _ground_y(pos.x, pos.z) + 0.1
		if pos.y <= ground:
			pos.y = ground
			t.global_position = pos
			_trooper_down(d, true)
			troopers.remove_at(i)
		else:
			t.global_position = pos


## A soldier left the air (landed or shot): remove the parachute, and let it fight if the player is on the ground.
func _trooper_down(d: Dictionary, landed_ok: bool) -> void:
	var t: Target = d["t"]
	var chute: Node = d["chute"]
	if is_instance_valid(chute):
		chute.queue_free()
	t.remove_meta("air")
	if not landed_ok or awake:
		t.set_physics_process(true)


func _update_counter() -> void:
	if ui == null:
		return
	ui.targets_label.visible = true
	ui.targets_label.text = "ENEMIES LEFT  %d" % enemies_left


func _on_killed_by(victim: Target, killer: Node) -> void:
	_drop_loot.call_deferred(Vector3(victim.global_position.x, maxf(_ground_y(victim.global_position.x, victim.global_position.z), 0.0), victim.global_position.z))
	if killer is Target:
		_feed_add((killer as Target).display_name, victim.display_name, false)
	elif killer == null:
		_feed_add("YOU", victim.display_name, true)
	else:
		_feed_add("ZONE", victim.display_name, false)   # died outside the safe zone


## Kill notification, top right: "KILLER  ▸  VICTIM". Yellow when you are the killer or the victim.
func _feed_add(killer: String, victim: String, about_you: bool) -> void:
	if feed == null:
		return
	var l := Label.new()
	l.text = "%s  ▸  %s" % [killer, victim]
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	l.add_theme_font_size_override("font_size", 22)
	l.add_theme_color_override("font_color", Color(1.0, 0.85, 0.2) if about_you else Color(0.95, 0.95, 0.95))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	feed.add_child(l)
	while feed.get_child_count() > FEED_MAX:
		feed.get_child(0).queue_free()
		feed.remove_child(feed.get_child(0))
	var tw := l.create_tween()
	tw.tween_interval(FEED_TIME)
	tw.tween_property(l, "modulate:a", 0.0, 0.6)
	tw.tween_callback(l.queue_free)


func _build_feed() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 6
	add_child(layer)
	feed = VBoxContainer.new()
	feed.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	feed.offset_left = -420.0
	feed.offset_right = -20.0
	feed.offset_top = 345.0 if Settings.use_touch() else 225.0   # below the minimap
	feed.alignment = BoxContainer.ALIGNMENT_BEGIN
	feed.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(feed)


func _on_enemy_died() -> void:
	enemies_left -= 1
	_update_counter()
	if enemies_left <= 0 and not won:
		won = true
		_win.call_deferred()   # let the killing shot finish scoring first


func _win() -> void:
	if ui:
		ui.add_score(500, "VICTORY")
		ui.end_run("VICTORY", "Last one standing  ·  %d enemies down" % ENEMY_COUNT)


## Mission popup shown once when the match starts. The game waits until you press the button.
func _show_intro() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 20
	layer.process_mode = Node.PROCESS_MODE_ALWAYS   # keeps working while the game is paused
	add_child(layer)
	var overlay := ColorRect.new()
	overlay.color = Color(0.0, 0.0, 0.0, 0.72)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	layer.add_child(overlay)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(center)
	var card := UIStyle.panel(UIStyle.GLASS, 8, 36.0)
	center.add_child(card)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 14)
	card.add_child(col)

	var head := UIStyle.title("BATTLE ROYALE", 46)
	head.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(head)
	var rule := UIStyle.accent_line(160.0, 4.0)
	rule.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	col.add_child(rule)
	var goal := UIStyle.label("ELIMINATE ALL ENEMIES\nAND BE THE ONLY SURVIVOR", 30, Color.WHITE)
	goal.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(goal)
	for tip in [
		"Jump from the plane, open your parachute and land",
		"Find weapons, ammo and medkits on the ground",
		"Stay inside the safe zone: the blue circle closes in",
		"Open the map with M to see the zone and the loot",
	]:
		var l := UIStyle.label("•  " + tip, 20, UIStyle.TEXT_DIM)
		col.add_child(l)

	var close := func() -> void:
		layer.queue_free()
		get_tree().paused = false
		Input.mouse_mode = Settings.gameplay_mouse_mode()
	var ok := UIStyle.accent_button("I'M READY", close, Vector2(280, 64), 26)
	ok.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	col.add_child(ok)
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	ok.grab_focus()


func _build_prompt() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 5
	add_child(layer)
	prompt = Label.new()
	prompt.text = "PRESS JUMP TO DROP   (M: MAP)"
	prompt.add_theme_font_size_override("font_size", 30)
	prompt.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	prompt.add_theme_constant_override("outline_size", 8)
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	prompt.offset_top = -170.0
	prompt.offset_left = -300.0
	prompt.offset_right = 300.0
	prompt.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(prompt)


func _board_plane() -> void:
	in_plane = true
	landed = false
	_close_chute()
	player.set_physics_process(false)
	player.velocity = Vector3.ZERO
	# Outside view: look at the plane from behind/above, mouse orbits around it
	var fwd := -plane.global_basis.z
	player.yaw = atan2(-fwd.x, -fwd.z)
	player.pitch = deg_to_rad(-12.0)
	player.cam_back = PLANE_CAM_DIST
	player.cam_back_target = PLANE_CAM_DIST
	if prompt:
		prompt.text = "PRESS JUMP TO DROP   (M: MAP)"
		prompt.visible = true


func _open_chute() -> void:
	chute_open = true
	var mesh := SphereMesh.new()
	mesh.radius = 2.6
	mesh.height = 2.6
	mesh.is_hemisphere = true
	mesh.radial_segments = 24
	mesh.rings = 8
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.9, 0.42, 0.1)
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mat.roughness = 0.9
	canopy = MeshInstance3D.new()
	canopy.mesh = mesh
	canopy.material_override = mat
	canopy.position = Vector3(0.0, 4.2, 0.0)   # above the head
	canopy.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	player.add_child(canopy)
	if prompt:
		prompt.visible = false


func _close_chute() -> void:
	chute_open = false
	if canopy:
		canopy.queue_free()
		canopy = null


func _physics_process(delta: float) -> void:
	if player == null or plane == null:
		return
	_update_troopers(delta)

	if in_plane:
		player.global_position = plane.global_position + SEAT_OFFSET
		if Input.is_action_just_pressed("jump"):
			in_plane = false
			player.cam_back_target = 0.0   # back to first person
			if prompt:
				prompt.text = "PRESS JUMP TO OPEN PARACHUTE"
			# Leave with the plane's speed, then free fall
			var forward := -plane.global_basis.z
			player.velocity = forward * 28.0
			player.set_physics_process(true)
		return

	if landed:
		return

	# In the air: no double jump (jump is used for the parachute)
	player.air_jumps_left = 0
	player.jump_physics = false
	if not chute_open and Input.is_action_just_pressed("jump"):
		_open_chute()
	if chute_open:
		# Parachute: slow down to a gentle descent
		if player.velocity.y < -CHUTE_FALL_SPEED:
			player.velocity.y = move_toward(player.velocity.y, -CHUTE_FALL_SPEED, CHUTE_BRAKE * delta)
	elif player.velocity.y < -TERMINAL_SPEED:
		player.velocity.y = -TERMINAL_SPEED

	# Touching the ground: put the parachute away and walk
	if player.is_on_floor():
		landed = true
		awake = true
		zone.start()   # the safe zone starts counting down once you stand on the ground
		for t in enemies:
			if is_instance_valid(t) and not t.has_meta("air"):
				t.set_physics_process(true)   # the soldiers wake up
		player.jump_physics = true
		_close_chute()
		if prompt:
			prompt.visible = false


# --------------------------------------------------------------------------- map helpers

const MAP_HALF := Vector2(258.0, 320.0)   # the supplied map is 520 x 646 m


## Invisible walls just inside the edge of the map (the old ones were deleted with the arena).
func _build_walls(root: Node) -> void:
	var body := StaticBody3D.new()
	body.name = "BrWalls"
	body.collision_layer = Layers.WALLS
	body.collision_mask = 0
	var t := 10.0
	var tall := 600.0
	var defs := [
		[Vector3(MAP_HALF.x + t / 2.0, 150.0, 0.0), Vector3(t, tall, MAP_HALF.y * 2.0 + 2.0 * t)],
		[Vector3(-MAP_HALF.x - t / 2.0, 150.0, 0.0), Vector3(t, tall, MAP_HALF.y * 2.0 + 2.0 * t)],
		[Vector3(0.0, 150.0, MAP_HALF.y + t / 2.0), Vector3(MAP_HALF.x * 2.0 + 2.0 * t, tall, t)],
		[Vector3(0.0, 150.0, -MAP_HALF.y - t / 2.0), Vector3(MAP_HALF.x * 2.0 + 2.0 * t, tall, t)],
	]
	for d in defs:
		var cs := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = d[1]
		cs.shape = box
		cs.position = d[0]
		body.add_child(cs)
	root.add_child(body)


## Lighter map: far trees / rocks are culled, they do not cast shadows (the map has ~900 of them).
func _optimize_map(node: Node) -> void:
	if node is MeshInstance3D:
		var n := String(node.name).to_lower()
		if n.begins_with("tree") or n.begins_with("rock"):
			var mi := node as MeshInstance3D
			mi.visibility_range_end = 170.0
			mi.visibility_range_end_margin = 20.0
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	for child in node.get_children():
		_optimize_map(child)


## Ground height at (x, z) for placing things OUTDOORS. Returns INF if the spot is on a roof, inside a
## building, under a tree / big prop or high up on a mountain (nobody should spawn there).
func _surface(x: float, z: float) -> float:
	var space := get_viewport().get_world_3d().direct_space_state
	var from := Vector3(x, 400.0, z)
	var to := Vector3(x, -50.0, z)
	var qw := PhysicsRayQueryParameters3D.create(from, to)
	qw.collision_mask = Layers.WORLD
	qw.collide_with_areas = false
	var hw := space.intersect_ray(qw)
	if hw.is_empty():
		return INF
	var wy: float = hw.position.y
	var qt := PhysicsRayQueryParameters3D.create(from, to)
	qt.collision_mask = Layers.TERRAIN
	qt.collide_with_areas = false
	var ht := space.intersect_ray(qt)
	if ht.is_empty():
		return wy   # ground was not recognised: old behaviour
	var ty: float = ht.position.y
	if wy - ty > 0.7 or ty > 8.0:
		return INF
	return ty


## Floor under a point that is already INSIDE a building (starts a little above the marker).
func _floor_y(x: float, y_from: float, z: float) -> float:
	var space := get_viewport().get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(Vector3(x, y_from, z), Vector3(x, y_from - 5.0, z))
	q.collision_mask = Layers.WORLD
	q.collide_with_areas = false
	var hit := space.intersect_ray(q)
	if not hit.is_empty():
		return float(hit.position.y)
	return y_from - 0.6


## Reads the footprints of the real buildings from the map (used by the minimap and spawn checks).
func _collect_buildings() -> void:
	houses.centers.clear()
	houses.halves.clear()
	if map_asset == null:
		return
	var prefixes := ["town_h", "sr_h", "nv_h", "town_store", "town_twostory", "farm_barn", "farm_house", "farm_storage", "gasstation_shop", "factory_main", "checkpoint_booth"]
	for child in map_asset.get_children():
		var n := String(child.name).to_lower()
		if n.contains("window") or not (child is Node3D):
			continue
		var is_building := false
		for pre in prefixes:
			if n.begins_with(pre):
				is_building = true
				break
		if not is_building:
			continue
		var box := _node_aabb(child as Node3D)
		if box.size.x < 1.0:
			continue
		houses.centers.append(Vector2(box.position.x + box.size.x / 2.0, box.position.z + box.size.z / 2.0))
		houses.halves.append(Vector2(box.size.x / 2.0, box.size.z / 2.0))
	if houses.centers.is_empty() and map_asset != null:
		for m in map_asset.find_children("LOOT_*", "Node3D", true, false):
			var mp := (m as Node3D).global_position
			houses.centers.append(Vector2(mp.x, mp.z))
			houses.halves.append(Vector2(6.0, 6.0))


func _node_aabb(n: Node3D) -> AABB:
	var result := AABB()
	var first := true
	var meshes: Array = n.find_children("*", "MeshInstance3D", true, false)
	if n is MeshInstance3D:
		meshes.append(n)
	for m in meshes:
		var mi := m as MeshInstance3D
		if mi.mesh == null:
			continue
		var a: AABB = mi.global_transform * mi.get_aabb()
		if first:
			result = a
			first = false
		else:
			result = result.merge(a)
	return result
