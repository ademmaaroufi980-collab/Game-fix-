extends Node3D
## Battle Royale map: a big flat valley (y = 0) surrounded by a ring of mountains,
## closed off by invisible walls. Built from a height grid (mesh + HeightMapShape3D collision).

const FLAT_HALF := 200.0       # flat playable square: [-200, 200] on x and z
const MOUNTAIN_FULL := 330.0   # mountains reach full size at this distance (Chebyshev)
const HALF := 500.0            # the whole map: [-500, 500]
const STEP := 8.0              # grid spacing (m)
const BASE_HEIGHT := 50.0
const PEAK_HEIGHT := 140.0

var noise := FastNoiseLite.new()
var tint := FastNoiseLite.new()


func _ready() -> void:
	noise.seed = 21
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = 0.008
	noise.fractal_octaves = 5
	tint.seed = 5
	tint.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	tint.frequency = 0.03
	_build()
	_build_walls()


func height_at(x: float, z: float) -> float:
	var cheb := maxf(absf(x), absf(z))
	var m := smoothstep(FLAT_HALF, MOUNTAIN_FULL, cheb)
	if m <= 0.0:
		return 0.0
	var n := noise.get_noise_2d(x, z) * 0.5 + 0.5
	return m * (BASE_HEIGHT + n * PEAK_HEIGHT)


func _color_at(x: float, z: float, h: float) -> Color:
	var e := STEP
	var slope := (absf(height_at(x + e, z) - height_at(x - e, z)) + absf(height_at(x, z + e) - height_at(x, z - e))) / (2.0 * e)
	var grass := Color(0.24, 0.40, 0.17).lerp(Color(0.38, 0.52, 0.24), tint.get_noise_2d(x, z) * 0.5 + 0.5)
	var rock := Color(0.42, 0.38, 0.34)
	var dark := Color(0.28, 0.26, 0.25)
	var snow := Color(0.94, 0.96, 1.0)
	var c := grass.lerp(rock, smoothstep(2.0, 45.0, h))
	c = c.lerp(dark, smoothstep(0.6, 1.4, slope))
	c = c.lerp(snow, smoothstep(115.0, 150.0, h) * (1.0 - smoothstep(1.1, 1.9, slope) * 0.6))
	return c


func _build() -> void:
	var n := int(HALF * 2.0 / STEP) + 1          # samples per side
	var mid := (n - 1) / 2.0
	var heights := PackedFloat32Array()
	heights.resize(n * n)

	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for j in n:
		for i in n:
			var x := (i - mid) * STEP
			var z := (j - mid) * STEP
			var h := height_at(x, z)
			heights[j * n + i] = h
			st.set_color(_color_at(x, z, h))
			st.set_uv(Vector2(i, j) / float(n - 1))
			st.add_vertex(Vector3(x, h, z))
	for j in n - 1:
		for i in n - 1:
			var a := j * n + i
			var b := a + 1
			var c := a + n
			var d := c + 1
			st.add_index(a)
			st.add_index(b)
			st.add_index(c)
			st.add_index(b)
			st.add_index(d)
			st.add_index(c)
	st.generate_normals()

	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 1.0
	var mi := MeshInstance3D.new()
	mi.mesh = st.commit()
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)

	var body := StaticBody3D.new()
	body.collision_layer = Layers.WORLD
	body.collision_mask = 0
	var cs := CollisionShape3D.new()
	var hm := HeightMapShape3D.new()
	hm.map_width = n
	hm.map_depth = n
	hm.map_data = heights
	cs.shape = hm
	cs.scale = Vector3(STEP, 1.0, STEP)
	body.add_child(cs)
	add_child(body)


## Invisible walls so nobody can walk or fly off the edge of the map.
func _build_walls() -> void:
	var body := StaticBody3D.new()
	body.collision_layer = Layers.WALLS
	body.collision_mask = 0
	var t := 10.0
	var tall := 500.0
	var span := HALF * 2.0 + 2.0 * t
	var defs := [
		[Vector3(HALF + t / 2.0, 150.0, 0.0), Vector3(t, tall, span)],
		[Vector3(-HALF - t / 2.0, 150.0, 0.0), Vector3(t, tall, span)],
		[Vector3(0.0, 150.0, HALF + t / 2.0), Vector3(span, tall, t)],
		[Vector3(0.0, 150.0, -HALF - t / 2.0), Vector3(span, tall, t)],
	]
	for d in defs:
		var cs := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = d[1]
		cs.shape = box
		cs.position = d[0]
		body.add_child(cs)
	add_child(body)
