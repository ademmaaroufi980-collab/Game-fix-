class_name BrHouses
extends Node3D
## Battle royale houses: simple buildings with a door, windows and a roof, scattered over the valley.
## Walls block bullets, sight and movement. Built from boxes, nothing to import.

const COUNT := 12
const AREA := 170.0            # houses stand inside [-170, 170] on x and z
const SPACING := 45.0          # minimum distance between two house centres
const WALL_H := 3.2
const WALL_T := 0.3
const DOOR_W := 2.2
const DOOR_H := 2.5
const WIN_W := 1.6
const WIN_BOTTOM := 1.0
const WIN_TOP := 2.3

var centers: Array[Vector2] = []   # house centres (x, z), read by BrJump for loot / guards
var halves: Array[Vector2] = []    # half size of each house (x, z)

var body: StaticBody3D


func _ready() -> void:
	body = StaticBody3D.new()
	body.collision_layer = Layers.WORLD
	body.collision_mask = 0
	add_child(body)
	var tries := 0
	while centers.size() < COUNT and tries < 2000:
		tries += 1
		var c := Vector2(randf_range(-AREA, AREA), randf_range(-AREA, AREA))
		if c.length() < 25.0:
			continue   # keep the middle of the map open
		var ok := true
		for o in centers:
			if c.distance_to(o) < SPACING:
				ok = false
				break
		if not ok:
			continue
		centers.append(c)
		var half := Vector2(randf_range(4.0, 5.5), randf_range(3.5, 5.0))
		halves.append(half)
		_build_house(c, half)


## True if the point (x, z) is inside a house, or closer than `margin` to it.
func covers(p: Vector2, margin := 3.0) -> bool:
	for i in centers.size():
		var d := (p - centers[i]).abs()
		if d.x < halves[i].x + margin and d.y < halves[i].y + margin:
			return true
	return false


## A random spot inside house `i`, away from the walls.
func inside_point(i: int) -> Vector2:
	var h := halves[i] - Vector2(1.2, 1.2)
	return centers[i] + Vector2(randf_range(-h.x, h.x), randf_range(-h.y, h.y))


func _build_house(c: Vector2, half: Vector2) -> void:
	var wall_col := [Color(0.78, 0.72, 0.6), Color(0.66, 0.68, 0.7), Color(0.72, 0.55, 0.45), Color(0.82, 0.8, 0.74)].pick_random() as Color
	var wmat := _mat(wall_col)
	var door_side := randi() % 4       # 0 = +z, 1 = -z, 2 = +x, 3 = -x
	var win_side := (door_side + 1 + randi() % 3) % 4
	var cx := c.x
	var cz := c.y

	# Four walls. Sides 0/1 run along x, sides 2/3 run along z.
	for side in 4:
		var along_x := side < 2
		var length := half.x * 2.0 if along_x else half.y * 2.0
		var off := Vector3.ZERO
		match side:
			0: off = Vector3(0, 0, half.y)
			1: off = Vector3(0, 0, -half.y)
			2: off = Vector3(half.x, 0, 0)
			3: off = Vector3(-half.x, 0, 0)
		var centre := Vector3(cx, 0.0, cz) + off
		if side == door_side:
			_wall(centre, length, along_x, wmat, 0.0, DOOR_W, 0.0, DOOR_H)
		elif side == win_side:
			_wall(centre, length, along_x, wmat, randf_range(-length * 0.2, length * 0.2), WIN_W, WIN_BOTTOM, WIN_TOP)
		else:
			_wall(centre, length, along_x, wmat, 0.0, 0.0, 0.0, 0.0)

	# Roof (slightly bigger than the walls) and a dark floor
	var rmat := _mat([Color(0.45, 0.18, 0.14), Color(0.3, 0.3, 0.34), Color(0.35, 0.24, 0.16)].pick_random() as Color)
	_box(Vector3(cx, WALL_H + 0.15, cz), Vector3(half.x * 2.0 + 0.8, 0.3, half.y * 2.0 + 0.8), rmat, true)
	_box(Vector3(cx, 0.02, cz), Vector3(half.x * 2.0, 0.04, half.y * 2.0), _mat(Color(0.28, 0.24, 0.2)), false)


## One wall centred at `centre`. `open_w` > 0 cuts an opening `open_w` wide at `open_off` along the
## wall, from height `bottom` to `top` (a door has bottom = 0, a window starts higher).
func _wall(centre: Vector3, length: float, along_x: bool, mat: StandardMaterial3D, open_off: float, open_w: float, bottom: float, top: float) -> void:
	if open_w <= 0.0:
		_seg(centre, length, along_x, 0.0, length, 0.0, WALL_H, mat)
		return
	var a := -length / 2.0
	var b := length / 2.0
	var o0 := open_off - open_w / 2.0
	var o1 := open_off + open_w / 2.0
	_seg(centre, length, along_x, a, o0, 0.0, WALL_H, mat)           # left of the opening
	_seg(centre, length, along_x, o1, b, 0.0, WALL_H, mat)           # right of the opening
	_seg(centre, length, along_x, o0, o1, top, WALL_H, mat)          # above it
	if bottom > 0.0:
		_seg(centre, length, along_x, o0, o1, 0.0, bottom, mat)      # below it (windows)


## A wall piece from `s0` to `s1` along the wall (relative to its centre) and from `y0` to `y1` in height.
func _seg(centre: Vector3, _length: float, along_x: bool, s0: float, s1: float, y0: float, y1: float, mat: StandardMaterial3D) -> void:
	var w := s1 - s0
	if w <= 0.01 or y1 - y0 <= 0.01:
		return
	var mid := (s0 + s1) / 2.0
	var pos := centre + (Vector3(mid, 0, 0) if along_x else Vector3(0, 0, mid)) + Vector3(0, (y0 + y1) / 2.0, 0)
	var size := Vector3(w, y1 - y0, WALL_T) if along_x else Vector3(WALL_T, y1 - y0, w)
	_box(pos, size, mat, true)


func _box(pos: Vector3, size: Vector3, mat: StandardMaterial3D, solid: bool) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	bm.material = mat
	mi.mesh = bm
	mi.position = pos
	add_child(mi)
	if solid:
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = size
		cs.shape = sh
		cs.position = pos
		body.add_child(cs)


func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.9
	return m
