class_name Loot
extends Area3D
## Battle royale loot lying on the ground: a weapon, an ammo box or a medkit.
## Walk over it to pick it up. A coloured light beam makes it visible from far away.

const NAMES := {"rifle": "RIFLE", "shotgun": "SHOTGUN", "sniper": "SNIPER", "ammo": "AMMO", "medkit": "MEDKIT"}
const COLORS := {
	"rifle": Color(0.25, 0.55, 1.0),
	"shotgun": Color(1.0, 0.55, 0.15),
	"sniper": Color(0.75, 0.3, 1.0),
	"ammo": Color(0.95, 0.9, 0.2),
	"medkit": Color(0.2, 1.0, 0.4),
}
const WEAPON_INDEX := {"rifle": 1, "shotgun": 2, "sniper": 3}
const MEDKIT_HEAL := 50.0

var kind := "ammo"
var wm: WeaponManager
var player: Player
var mesh: MeshInstance3D
var taken := false
var retry := 0.0   # pause between two failed pickups so the message does not spam
var asset_visual: Node3D


func _ready() -> void:
	add_to_group("loot")
	collision_layer = 0
	collision_mask = Layers.PLAYER
	var col: Color = COLORS[kind]

	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 1.4
	cs.shape = sh
	cs.position.y = 0.8
	add_child(cs)

	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.emission_enabled = true
	mat.emission = col
	mat.emission_energy_multiplier = 0.8
	if WEAPON_INDEX.has(kind):
		var model_key: String = str({"rifle": "ak47", "shotgun": "shootgun1", "sniper": "awm"}[kind])
		asset_visual = AssetBridge.instantiate(self, model_key)
		if asset_visual != null:
			asset_visual.position = Vector3(0.0, 0.65, 0.0)
			asset_visual.rotation = Vector3.ZERO   # lies flat and spins
			asset_visual.scale = Vector3.ONE * 0.8
			_set_asset_shadow(asset_visual)
	if asset_visual == null:
		mesh = MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(0.9, 0.22, 0.3) if WEAPON_INDEX.has(kind) else Vector3(0.55, 0.4, 0.4)
		bm.material = mat
		mesh.mesh = bm
		mesh.position.y = 0.9
		add_child(mesh)

	# Light beam, visible from far away
	var beam_mat := StandardMaterial3D.new()
	beam_mat.albedo_color = Color(col.r, col.g, col.b, 0.22)
	beam_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	beam_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	beam_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	var beam := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.18
	cm.bottom_radius = 0.18
	cm.height = 16.0
	cm.material = beam_mat
	beam.mesh = cm
	beam.position.y = 8.0
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(beam)

	var label := Label3D.new()
	label.text = NAMES[kind]
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.font_size = 40
	label.pixel_size = 0.008
	label.modulate = col
	label.outline_size = 10
	label.position.y = 1.7
	add_child(label)

	wm = get_tree().get_first_node_in_group("weapon_manager") as WeaponManager
	player = get_tree().get_first_node_in_group("player") as Player


func _process(delta: float) -> void:
	if asset_visual != null:
		asset_visual.rotate_y(delta * 1.8)
		asset_visual.position.y = 0.65 + sin(Time.get_ticks_msec() / 400.0 + position.x) * 0.1
	elif mesh != null:
		mesh.rotate_y(delta * 1.8)
		mesh.position.y = 0.9 + sin(Time.get_ticks_msec() / 400.0 + position.x) * 0.1


func _set_asset_shadow(node: Node) -> void:
	if node is GeometryInstance3D:
		(node as GeometryInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	for child in node.get_children():
		_set_asset_shadow(child)


# Polled so you can come back for a medkit / ammo you could not use at first.
func _physics_process(delta: float) -> void:
	if taken or wm == null or player == null:
		return
	retry -= delta
	if retry > 0.0:
		return
	for body in get_overlapping_bodies():
		if body == player:
			if _collect():
				taken = true
				queue_free()
			else:
				retry = 1.5
			return


func _collect() -> bool:
	match kind:
		"ammo":
			if wm.add_ammo():
				return true
			wm.message.emit("AMMO FULL")
			return false
		"medkit":
			if player.heal(MEDKIT_HEAL):
				wm.message.emit("+%d HEALTH" % int(MEDKIT_HEAL))
				return true
			wm.message.emit("HEALTH FULL")
			return false
		_:
			wm.give_weapon(WEAPON_INDEX[kind])
			return true


## A soldier walked over it: it takes the loot (so the player has to compete for it).
func take_by_bot(bot: Target) -> void:
	if taken:
		return
	taken = true
	match kind:
		"medkit":
			bot.health = minf(bot.max_health, bot.health + MEDKIT_HEAL)
		"rifle", "shotgun", "sniper":
			bot.ai_level = minf(2.0, bot.ai_level + 0.1)   # a better gun makes it a better shot
	queue_free()
