class_name BrZone
extends Node3D
## Battle royale safe zone: a circle that closes in phase after phase. Each phase first waits, then
## shrinks towards a NEW circle (shown in white on the map) that lies inside the current one, so the
## safe area also moves. Standing outside the circle hurts, more and more every phase. Soldiers
## obey it too, so the last fights happen in the final circle.

enum State { OFF, WAIT, SHRINK, FINAL }

const START_RADIUS := 260.0
## [radius of the next circle, seconds to wait, seconds the circle takes to close, damage per second outside]
const PHASES: Array = [
	[150.0, 50.0, 45.0, 1.0],
	[95.0, 35.0, 40.0, 2.0],
	[55.0, 30.0, 35.0, 4.0],
	[28.0, 25.0, 30.0, 7.0],
	[10.0, 20.0, 25.0, 12.0],
	[2.0, 15.0, 20.0, 20.0],
]
const TICK := 1.0              # damage is applied once a second
const CENTER_LIMIT := 140.0    # circles stay near the flat valley
const WALL_HEIGHT := 500.0

var state := State.OFF
var phase := 0
var timer := 0.0
var duration := 1.0
var center := Vector2.ZERO
var radius := START_RADIUS
var from_center := Vector2.ZERO
var from_radius := START_RADIUS
var next_center := Vector2.ZERO
var next_radius := START_RADIUS
var last_player_hit := -100000   # time (ms) of the last zone damage to the player, read by the HUD
var outside := false             # is the player outside the circle?

var player: Player
var ui: GameUI
var wall: MeshInstance3D
var label: Label
var warn: Label
var tint: ColorRect
var tick_t := 0.0


func _ready() -> void:
	add_to_group("br_zone")
	_build_wall()
	_build_hud()


func _build_wall() -> void:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.25, 0.55, 1.0, 0.16)
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mat.disable_fog = true
	var cm := CylinderMesh.new()
	cm.top_radius = 1.0
	cm.bottom_radius = 1.0
	cm.height = WALL_HEIGHT
	cm.radial_segments = 128
	cm.rings = 1
	cm.cap_top = false
	cm.cap_bottom = false
	cm.material = mat
	wall = MeshInstance3D.new()
	wall.mesh = cm
	wall.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(wall)
	_update_wall()


func _build_hud() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 4
	add_child(layer)
	tint = ColorRect.new()
	tint.color = Color(0.2, 0.4, 1.0, 0.0)
	tint.set_anchors_preset(Control.PRESET_FULL_RECT)
	tint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(tint)
	label = _make_label(24, Color(0.75, 0.9, 1.0), 14.0)
	layer.add_child(label)
	warn = _make_label(26, Color(1.0, 0.3, 0.25), 46.0)
	layer.add_child(warn)


func _make_label(size: int, color: Color, top: float) -> Label:
	var l := Label.new()
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	l.offset_left = -300.0
	l.offset_right = 300.0
	l.offset_top = top
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	l.add_theme_constant_override("outline_size", 7)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


## Called by BrJump when the player lands: the first countdown starts.
func start() -> void:
	if state != State.OFF:
		return
	player = get_tree().get_first_node_in_group("player") as Player
	ui = get_tree().get_first_node_in_group("hud") as GameUI
	phase = 0
	state = State.WAIT
	_plan()


func is_active() -> bool:
	return state != State.OFF


## Picks the next (smaller) circle somewhere inside the current one.
func _plan() -> void:
	next_radius = float(PHASES[phase][0])
	timer = float(PHASES[phase][1])
	var room := maxf(0.0, radius - next_radius) * 0.75
	var a := randf() * TAU
	var d := sqrt(randf()) * room
	next_center = (center + Vector2(cos(a), sin(a)) * d).clamp(Vector2(-CENTER_LIMIT, -CENTER_LIMIT), Vector2(CENTER_LIMIT, CENTER_LIMIT))


func dps() -> float:
	return float(PHASES[mini(phase, PHASES.size() - 1)][3])


## Is the point (x, z) inside the circle that is closing now?
func inside(p: Vector2, margin := 0.0) -> bool:
	return p.distance_to(center) <= radius - margin


## Is the point inside the circle the zone is heading for? (Soldiers use this to plan their moves.)
func inside_next(p: Vector2, margin := 0.0) -> bool:
	return p.distance_to(next_center) <= next_radius - margin


func _update_wall() -> void:
	wall.position = Vector3(center.x, WALL_HEIGHT * 0.3, center.y)
	wall.scale = Vector3(radius, 1.0, radius)


func _process(delta: float) -> void:
	_update_wall()
	if state == State.OFF:
		return
	match state:
		State.WAIT:
			timer -= delta
			if timer <= 0.0:
				state = State.SHRINK
				from_center = center
				from_radius = radius
				duration = maxf(1.0, float(PHASES[phase][2]))
				timer = duration
				if ui:
					ui.show_banner("ZONE IS CLOSING", "Get inside the white circle", 3.0)
		State.SHRINK:
			timer -= delta
			var k := 1.0 - clampf(timer / duration, 0.0, 1.0)
			center = from_center.lerp(next_center, k)
			radius = lerpf(from_radius, next_radius, k)
			if timer <= 0.0:
				center = next_center
				radius = next_radius
				phase += 1
				if phase >= PHASES.size():
					state = State.FINAL
					phase = PHASES.size() - 1
				else:
					state = State.WAIT
					_plan()

	tick_t += delta
	if tick_t >= TICK:
		tick_t -= TICK
		_apply_damage()
	_update_hud(delta)


func _apply_damage() -> void:
	var dmg := dps()
	if player != null and not player.dead and outside:
		last_player_hit = Time.get_ticks_msec()
		player.take_damage(dmg, player.global_position)
	for n in get_tree().get_nodes_in_group("targets"):
		var t := n as Target
		if t == null or t.dead or not t.visible or not t.is_physics_processing() or t.has_meta("air"):
			continue
		if not inside(Vector2(t.global_position.x, t.global_position.z)):
			t.take_damage(dmg, t.global_position, self)


func _fmt(sec: float) -> String:
	var s := ceili(sec)
	return "%d:%02d" % [int(s / 60.0), s % 60]


func _update_hud(delta: float) -> void:
	if player != null and not player.dead:
		outside = not inside(Vector2(player.global_position.x, player.global_position.z))
	else:
		outside = false
	match state:
		State.WAIT:
			label.text = "ZONE %d / %d   ·   CLOSES IN %s" % [phase + 1, PHASES.size(), _fmt(timer)]
		State.SHRINK:
			label.text = "ZONE %d / %d   ·   CLOSING  %s" % [phase + 1, PHASES.size(), _fmt(timer)]
		State.FINAL:
			label.text = "FINAL ZONE"
	warn.text = "OUTSIDE THE ZONE   -%d HP / s" % int(dps()) if outside else ""
	var want := 0.22 if outside else 0.0
	tint.color.a = lerpf(tint.color.a, want, 1.0 - exp(-6.0 * delta))
