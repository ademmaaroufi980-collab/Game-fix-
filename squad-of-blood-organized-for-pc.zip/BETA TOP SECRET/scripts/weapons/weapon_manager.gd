class_name WeaponManager
extends Node3D
## Weapon logic: input, hitscan firing, spread/bloom, recoil, aim-down-sights, reload, switching.
## Stats come from WeaponData resources (res://resources/weapons/). Effects, sound and
## viewmodels live in WeaponFX, WeaponAudio and WeaponViewModels.

const DEFAULT_WEAPONS: Array[String] = [
	"res://resources/weapons/pistol.tres",
	"res://resources/weapons/rifle.tres",
	"res://resources/weapons/shotgun.tres",
	"res://resources/weapons/sniper.tres",
]
const RAY_MASK := Layers.WORLD | Layers.TARGETS   # bullets ignore the player and invisible walls

signal weapon_changed(weapon_name: String, mag: int, reserve: int, reloading: bool)
signal hit_confirmed(points: int, head: bool, kill: bool)
signal shot_fired
signal message(text: String)

## Leave empty to use the default four weapons.
@export var weapons: Array[WeaponData] = []

@onready var camera: Camera3D = get_parent() as Camera3D

var player: Player

var current := 0
var owned: Array[bool] = []   # weapons the player carries (all of them, except in battle royale where you find them)
var mags: Array[int] = []
var reserves: Array[int] = []
var cooldown := 0.0
var reloading := false
var reload_t := 0.0
var bloom := 0.0
var aim_t := 0.0
var raise_t := 0.0
var kick := 0.0
var kick_roll := 0.0       # random sideways twist of the gun per shot
var kick_side := 0.0       # random sideways nudge of the gun per shot
var sway := Vector2.ZERO   # the gun lags behind when you turn
var move_off := Vector3.ZERO   # the gun lags behind when you move / jump / fall
var prev_yaw := 0.0
var prev_pitch := 0.0
var idle_t := 0.0
var flash_t := 0.0
var base_fov := 85.0
var is_aiming := false

# Touch controls write these (PC reads the mouse buttons directly).
var touch_fire := false
var touch_aim := false
var prev_touch_fire := false

# Shots fired this frame; their rays are cast in the next physics step.
var shot_queue: Array[Dictionary] = []

var view: Node3D
var guns: Array[Node3D] = []
var muzzles: Array[Node3D] = []
var flashes: Array[Node3D] = []

var fx: WeaponFX
var audio: WeaponAudio


func _ready() -> void:
	add_to_group("weapon_manager")
	player = get_tree().get_first_node_in_group("player") as Player
	base_fov = Settings.fov

	if weapons.is_empty():
		for path in DEFAULT_WEAPONS:
			weapons.append(load(path) as WeaponData)
	for w in weapons:
		mags.append(w.mag)
		reserves.append(w.reserve)
		owned.append(true)

	fx = WeaponFX.new()
	fx.name = "FX"
	add_child(fx)
	fx.setup(player.get_parent())

	audio = WeaponAudio.new()
	audio.name = "Audio"
	add_child(audio)
	audio.setup(weapons)

	view = Node3D.new()
	view.name = "ViewModel"
	add_child(view)
	var built := WeaponViewModels.build(view, weapons)
	guns.assign(built["guns"])
	muzzles.assign(built["muzzles"])
	flashes.assign(built["flashes"])

	current = clampi(Game.loadout, 0, weapons.size() - 1)   # weapon picked in the lobby
	if Game.br:
		# Battle royale: you start with a pistol and a little ammo; everything else has to be found.
		for i in weapons.size():
			owned[i] = i == 0
		current = 0
		reserves[0] = 24
	guns[current].visible = true
	_emit_weapon_state.call_deferred()   # lets the HUD finish connecting first


# --------------------------------------------------------------------------- input

func _unhandled_input(event: InputEvent) -> void:
	if not Settings.input_live():
		return
	for i in weapons.size():
		var action := "weapon_%d" % (i + 1)
		if InputMap.has_action(action) and event.is_action_pressed(action):
			_switch_to(i)
	if event.is_action_pressed("weapon_next"):
		_cycle(1)
	elif event.is_action_pressed("weapon_prev"):
		_cycle(-1)


func _process(delta: float) -> void:
	var w := weapons[current]
	var captured := Settings.input_live()
	var touch := Settings.use_touch()
	var fire_edge := touch_fire and not prev_touch_fire
	prev_touch_fire = touch_fire
	base_fov = Settings.fov
	cooldown = maxf(0.0, cooldown - delta)
	bloom = move_toward(bloom, 0.0, w.bloom_recover * delta)

	# Aim down sights
	var can_aim: bool = captured and not reloading and raise_t < 0.5 and player.sprint_amount < 0.3
	var aim_held: bool = touch_aim if touch else Input.is_action_pressed("aim")
	is_aiming = can_aim and aim_held
	aim_t = move_toward(aim_t, 1.0 if is_aiming else 0.0, delta / w.ads_time)

	# Field of view and mouse sensitivity follow the zoom
	camera.fov = lerpf(base_fov + player.fov_boost, w.zoom_fov, smoothstep(0.0, 1.0, aim_t))
	player.look_scale = lerpf(1.0, w.zoom_fov / base_fov, aim_t)

	if reloading:
		reload_t += delta
		if reload_t >= w.reload_time:
			_finish_reload()

	if captured:
		var held: bool = touch_fire if touch else Input.is_action_pressed("shoot")
		var fresh: bool = fire_edge if touch else Input.is_action_just_pressed("shoot")
		var wants_fire: bool = held if w.auto else fresh
		if wants_fire:
			_try_fire()
		if Input.is_action_just_pressed("reload"):
			_start_reload()

	_animate_view(delta, w)

	if flash_t > 0.0:
		flash_t -= delta
		if flash_t <= 0.0:
			flashes[current].visible = false



# --------------------------------------------------------------------------- shooting

func _current_spread() -> float:
	var w := weapons[current]
	var s: float = w.spread + bloom
	var hspeed := Vector2(player.velocity.x, player.velocity.z).length()
	s += clampf(hspeed / 6.0, 0.0, 1.6) * w.move_spread
	if not player.is_on_floor():
		s += 1.5 + w.spread * 3.0
	if player.prone:
		s *= 0.45
	elif player.crouching:
		s *= 0.6
	s *= lerpf(1.0, w.ads_mult, aim_t)
	return s


func _try_fire() -> void:
	var w := weapons[current]
	if reloading or cooldown > 0.0 or raise_t > 0.4:
		return
	if mags[current] <= 0:
		if reserves[current] > 0:
			_start_reload()
		else:
			audio.play_empty()
			cooldown = 0.3   # don't spam the click while the button is held
		return
	mags[current] -= 1
	cooldown = w.rate
	shot_fired.emit()

	# The aim is captured now; the rays are cast in the next physics step (_physics_process).
	shot_queue.append({
		"w": w,
		"spread": _current_spread(),
		"muzzle": muzzles[current].global_position,
		"origin": camera.global_position,
		"basis": camera.global_transform.basis,
	})

	# Recoil: climbs while firing, partly random sideways, smaller when aiming
	var aim_scale := 1.0 - 0.35 * aim_t
	var yaw_k: float = randf_range(-1.0, 1.0) * w.recoil_yaw
	player.add_recoil(deg_to_rad(w.recoil_pitch) * aim_scale, deg_to_rad(yaw_k) * aim_scale)
	bloom = minf(bloom + w.bloom, w.max_bloom)
	kick = w.kick
	kick_roll = randf_range(-1.0, 1.0) * w.kick * 1.4
	kick_side = randf_range(-1.0, 1.0) * w.kick * 0.2
	player.add_shake(clampf(w.kick * 6.0, 0.15, 0.9))   # camera shake

	flashes[current].visible = true
	flashes[current].rotation.z = randf() * TAU          # a different flash every shot
	flashes[current].scale = Vector3.ONE * randf_range(0.8, 1.5)
	flash_t = 0.045
	audio.play_shot(current)
	_emit_weapon_state()


func _physics_process(_delta: float) -> void:
	while not shot_queue.is_empty():
		_resolve_shot(shot_queue.pop_front())


## Casts the rays of one queued shot and reports score / hit feedback.
func _resolve_shot(shot: Dictionary) -> void:
	var w: WeaponData = shot["w"]
	var spread: float = shot["spread"]
	var muzzle_pos: Vector3 = shot["muzzle"]
	var origin: Vector3 = shot["origin"]
	var cb: Basis = shot["basis"]
	var points := 0
	var any_head := false
	var any_hit := false
	var any_kill := false
	var pellet_scale := 1.0 / sqrt(float(w.pellets))   # keeps multi-pellet weapons from dominating the score
	for i in w.pellets:
		var r := _shoot_pellet(w, spread, muzzle_pos, origin, cb)
		if r["hit"]:
			any_hit = true
			points += roundi((20.0 if r["head"] else 10.0) * pellet_scale)
			if r["head"]:
				any_head = true
			if r["kill"]:
				any_kill = true
				points += 150 if r["head"] else 100
	if any_hit:
		audio.play_hit(any_kill)
		hit_confirmed.emit(points, any_head, any_kill)


func _shoot_pellet(w: WeaponData, spread_deg: float, muzzle_pos: Vector3, origin: Vector3, cb: Basis) -> Dictionary:
	var dir := -cb.z
	if spread_deg > 0.0:
		var rr := sqrt(randf()) * tan(deg_to_rad(spread_deg))
		var th := randf() * TAU
		dir = (dir + cb.x * rr * cos(th) + cb.y * rr * sin(th)).normalized()
	var q := PhysicsRayQueryParameters3D.create(origin, origin + dir * w.max_range, RAY_MASK, [player.get_rid()])
	var res := player.get_world_3d().direct_space_state.intersect_ray(q)
	var end := origin + dir * w.max_range
	var out := {"hit": false, "head": false, "kill": false}
	if not res.is_empty():
		end = res["position"]
		var collider: Object = res["collider"]
		if collider is Target:
			var dmg := w.damage
			if w.falloff > 0.0:
				dmg *= clampf(1.0 - origin.distance_to(end) / w.falloff, 0.25, 1.0)
			var info: Dictionary = (collider as Target).take_damage(dmg, end)
			if not info.is_empty():
				out = {"hit": true, "head": info["head"], "kill": info["kill"]}
			fx.spark(end, true)
		else:
			fx.impact(end, res["normal"])
	fx.tracer(muzzle_pos, end)
	return out


## Public hooks for the touch buttons.
func next_weapon() -> void:
	_cycle(1)


## Switches to the next / previous weapon that the player actually carries.
func _cycle(step: int) -> void:
	var n := weapons.size()
	for k in range(1, n):
		var i := posmod(current + step * k, n)
		if owned[i]:
			_switch_to(i)
			return


func reload() -> void:
	_start_reload()


func _start_reload() -> void:
	var w := weapons[current]
	if reloading or mags[current] >= w.mag or reserves[current] <= 0:
		return
	reloading = true
	reload_t = 0.0
	audio.play_reload()
	_emit_weapon_state()


func _finish_reload() -> void:
	var w := weapons[current]
	var take := mini(w.mag - mags[current], reserves[current])
	mags[current] += take
	reserves[current] -= take
	reloading = false
	_emit_weapon_state()


func _switch_to(i: int) -> void:
	if i == current or not owned[i]:
		return
	reloading = false
	audio.stop_reload()
	guns[current].visible = false
	flashes[current].visible = false
	current = i
	guns[current].visible = true
	raise_t = 1.0
	cooldown = maxf(cooldown, 0.3)
	bloom = 0.0
	_emit_weapon_state()


## Refills reserve ammo. Returns false (and does nothing) if every reserve is already full.
func refill() -> bool:
	var needed := false
	for i in weapons.size():
		if reserves[i] < weapons[i].reserve:
			needed = true
			reserves[i] = weapons[i].reserve
	if not needed:
		return false
	_emit_weapon_state()
	message.emit("AMMO REFILLED")
	return true


## Loot: picks up weapon `i`. A new weapon comes with a full magazine and half a reserve and is
## equipped at once; one you already carry gives extra ammo instead.
func give_weapon(i: int) -> void:
	var w := weapons[i]
	if owned[i]:
		reserves[i] = mini(reserves[i] + w.mag * 2, w.reserve * 2)
		message.emit("+AMMO  %s" % w.display_name)
		_emit_weapon_state()
		return
	owned[i] = true
	mags[i] = w.mag
	reserves[i] = w.reserve / 2
	message.emit("PICKED UP  %s" % w.display_name)
	_switch_to(i)


## Loot: one extra magazine for every weapon you carry. Returns false when everything is already full.
func add_ammo() -> bool:
	var gained := false
	for i in weapons.size():
		if owned[i] and reserves[i] < weapons[i].reserve * 2:
			reserves[i] = mini(reserves[i] + weapons[i].mag, weapons[i].reserve * 2)
			gained = true
	if gained:
		message.emit("+AMMO")
		_emit_weapon_state()
	return gained


func _emit_weapon_state() -> void:
	weapon_changed.emit(weapons[current].display_name, mags[current], reserves[current], reloading)


# Read by the HUD every frame.
func is_scoped() -> bool:
	return weapons[current].scope and aim_t > 0.9


## Crosshair half-gap in screen pixels for the current spread.
func crosshair_gap_px() -> float:
	return _current_spread() * get_viewport().get_visible_rect().size.y / camera.fov


# --------------------------------------------------------------------------- viewmodel animation

func _animate_view(delta: float, w: WeaponData) -> void:
	var scoped: bool = w.scope and aim_t > 0.9
	view.visible = not scoped and player.cam_back < 1.0

	var hip := Vector3(0.18, -0.17, -0.36)
	var ads := Vector3(0.0, w.ads_y, -0.3)
	var pos := hip.lerp(ads, aim_t)

	# Walk bob (same phase as the camera bob)
	var hspeed := Vector2(player.velocity.x, player.velocity.z).length()
	var bob_amt := (minf(hspeed / 6.0, 1.5) if player.is_on_floor() else 0.0) * (1.0 - aim_t * 0.85)
	var bt: float = player.bob_t
	pos += Vector3(cos(bt * 0.5) * 0.008, sin(bt) * 0.006, 0.0) * bob_amt

	var rot := Vector3.ZERO

	# More bob depth: the gun rolls and pitches with each step
	rot.z += sin(bt * 0.5) * 0.03 * bob_amt
	rot.x += sin(bt) * 0.015 * bob_amt

	# Idle breathing when standing still
	idle_t += delta
	var still := clampf(1.0 - hspeed / 2.0, 0.0, 1.0) * (1.0 - aim_t * 0.7)
	pos += Vector3(sin(idle_t * 0.9) * 0.0008, sin(idle_t * 1.7) * 0.0012, 0.0) * still

	# Look sway: the gun drags behind the turn, then settles
	var dyaw := wrapf(player.yaw - prev_yaw, -PI, PI)
	var dpitch := player.pitch - prev_pitch
	prev_yaw = player.yaw
	prev_pitch = player.pitch
	var rate := Vector2(dyaw, dpitch) / maxf(delta, 0.001)
	var sway_target := Vector2(clampf(rate.x * 0.006, -0.04, 0.04), clampf(-rate.y * 0.006, -0.03, 0.03)) * (1.0 - aim_t * 0.75)
	sway = sway.lerp(sway_target, 1.0 - exp(-10.0 * delta))
	pos += Vector3(sway.x, sway.y, 0.0)
	rot.y += sway.x * 3.0
	rot.x += sway.y * 3.0
	rot.z += sway.x * 5.0

	# Movement inertia: strafing pushes the gun sideways, falling and jumping lift and drop it
	var lv := player.global_transform.basis.inverse() * player.velocity
	var move_target := Vector3(-clampf(lv.x * 0.004, -0.03, 0.03), -clampf(player.velocity.y * 0.002, -0.04, 0.03), 0.0) * (1.0 - aim_t * 0.8)
	move_off = move_off.lerp(move_target, 1.0 - exp(-9.0 * delta))
	pos += move_off
	rot.z += move_off.x * 4.0
	pos.y -= player.land_dip * 0.35   # heavier landing

	# Sprint pose (weapon lowered and angled)
	pos += Vector3(0.05, -0.07, 0.03) * player.sprint_amount
	rot.y -= 0.5 * player.sprint_amount
	rot.x += 0.15 * player.sprint_amount

	# Reload animation
	if reloading:
		var s := sin(reload_t / w.reload_time * PI)
		rot.x -= s * 0.9
		rot.z += s * 0.4
		pos.y -= s * 0.08

	# Raise after switching
	if raise_t > 0.0:
		raise_t = move_toward(raise_t, 0.0, delta * 4.0)
		pos.y -= raise_t * 0.25
		rot.x -= raise_t * 0.8

	# Fire kick
	kick = lerpf(kick, 0.0, 1.0 - exp(-16.0 * delta))
	kick_roll = lerpf(kick_roll, 0.0, 1.0 - exp(-14.0 * delta))
	kick_side = lerpf(kick_side, 0.0, 1.0 - exp(-14.0 * delta))
	pos.z += kick
	pos.x += kick_side * (1.0 - aim_t * 0.6)
	rot.x += kick * 3.0
	rot.z += kick_roll * (1.0 - aim_t * 0.6)

	view.position = pos
	view.rotation = rot
