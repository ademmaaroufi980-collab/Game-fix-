class_name WeaponData
extends Resource
## Stats for one weapon. Edit the .tres files in res://resources/weapons/ from the Inspector.
## Angles (spread, bloom, recoil) are in degrees. damage is per pellet.

@export var display_name := "WEAPON"
@export_enum("pistol", "ak47", "shootgun1", "awm") var model := "pistol"

@export_group("Damage")
@export var damage := 20.0
@export var pellets := 1
@export var max_range := 250.0
## Distance over which damage fades to 25% (0 = no falloff).
@export var falloff := 0.0

@export_group("Fire control")
## Seconds between shots.
@export var rate := 0.2
@export var auto := false
@export var mag := 12
@export var reserve := 60
@export var reload_time := 1.2

@export_group("Accuracy")
@export var spread := 0.3
@export var bloom := 0.6
@export var max_bloom := 2.5
@export var bloom_recover := 5.0
@export var move_spread := 1.2
## Spread multiplier while aiming down sights.
@export var ads_mult := 0.35

@export_group("Recoil")
@export var recoil_pitch := 1.4
@export var recoil_yaw := 0.4
## Viewmodel kick-back per shot (metres).
@export var kick := 0.05

@export_group("Aiming")
@export var zoom_fov := 70.0
@export var ads_time := 0.12
## Viewmodel height while aiming.
@export var ads_y := -0.045
@export var scope := false

@export_group("Presentation")
@export var muzzle_pos := Vector3.ZERO
## Procedural shot sound: duration (s), decay, lowpass, thump frequency (Hz).
@export var shot_duration := 0.22
@export var shot_decay := 22.0
@export var shot_lowpass := 0.5
@export var shot_thump := 120.0
