class_name WeaponFX
extends Node
## Pooled bullet effects: tracers, sparks and bullet holes. Nothing is allocated per shot.

const TRACER_POOL := 24
const SPARK_POOL := 24
const HOLE_POOL := 50
const TRACER_LIFE := 0.05
const SPARK_LIFE := 0.1

var tracer_mat: StandardMaterial3D
var hole_mat: StandardMaterial3D
var unit_box: BoxMesh
var spark_mesh_hit: SphereMesh
var spark_mesh_impact: SphereMesh
var hole_mesh: QuadMesh

var tracer_pool: Array[MeshInstance3D] = []
var tracer_until: Array[float] = []
var tracer_idx := 0
var spark_pool: Array[MeshInstance3D] = []
var spark_until: Array[float] = []
var spark_idx := 0
var hole_pool: Array[MeshInstance3D] = []
var hole_idx := 0


## fx_parent is the world node the effects live in.
func setup(fx_parent: Node) -> void:
	_build_materials()
	_build_pool.call_deferred(fx_parent)   # the parent may still be busy setting up children


func _process(_delta: float) -> void:
	var now := _now()
	for i in tracer_pool.size():
		if tracer_pool[i].visible and now >= tracer_until[i]:
			tracer_pool[i].visible = false
	for i in spark_pool.size():
		if spark_pool[i].visible and now >= spark_until[i]:
			spark_pool[i].visible = false


func tracer(from: Vector3, to: Vector3) -> void:
	if tracer_pool.is_empty():
		return
	var dist := from.distance_to(to)
	if dist < 0.5:
		return
	var i := tracer_idx
	tracer_idx = (tracer_idx + 1) % tracer_pool.size()
	var mi := tracer_pool[i]
	tracer_until[i] = _now() + TRACER_LIFE
	mi.visible = true
	mi.look_at_from_position((from + to) * 0.5, to, Vector3.UP if absf((to - from).normalized().y) < 0.99 else Vector3.RIGHT)
	mi.scale = Vector3(0.012, 0.012, dist)


func spark(pos: Vector3, hit_target: bool) -> void:
	if spark_pool.is_empty():
		return
	var i := spark_idx
	spark_idx = (spark_idx + 1) % spark_pool.size()
	var mi := spark_pool[i]
	mi.mesh = spark_mesh_hit if hit_target else spark_mesh_impact
	spark_until[i] = _now() + SPARK_LIFE
	mi.visible = true
	mi.global_position = pos


func impact(pos: Vector3, normal: Vector3) -> void:
	spark(pos + normal * 0.02, false)
	if hole_pool.is_empty():
		return
	var hole := hole_pool[hole_idx]
	hole_idx = (hole_idx + 1) % hole_pool.size()
	var up := Vector3.UP if absf(normal.y) < 0.99 else Vector3.RIGHT
	hole.visible = true
	hole.look_at_from_position(pos + normal * 0.012, pos + normal * 0.012 - normal, up)


func _now() -> float:
	return Time.get_ticks_msec() / 1000.0


func _build_materials() -> void:
	tracer_mat = StandardMaterial3D.new()
	tracer_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	tracer_mat.albedo_color = Color(1.0, 0.9, 0.5)
	hole_mat = StandardMaterial3D.new()
	hole_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	hole_mat.albedo_color = Color(0.03, 0.03, 0.03)
	hole_mat.cull_mode = BaseMaterial3D.CULL_DISABLED

	unit_box = BoxMesh.new()   # tracer length is applied through node scale
	unit_box.size = Vector3.ONE
	unit_box.material = tracer_mat
	spark_mesh_hit = _make_spark_mesh(Color(1.0, 0.25, 0.2))
	spark_mesh_impact = _make_spark_mesh(Color(1.0, 0.8, 0.4))
	hole_mesh = QuadMesh.new()
	hole_mesh.size = Vector2(0.1, 0.1)
	hole_mesh.material = hole_mat


func _make_spark_mesh(color: Color) -> SphereMesh:
	var sm := SphereMesh.new()
	sm.radius = 0.06
	sm.height = 0.12
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = color
	sm.material = m
	return sm


func _fx_node(mesh: Mesh) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.visible = false
	return mi


func _build_pool(parent: Node) -> void:
	for i in TRACER_POOL:
		var t := _fx_node(unit_box)
		parent.add_child(t)
		tracer_pool.append(t)
		tracer_until.append(0.0)
	for i in SPARK_POOL:
		var s := _fx_node(spark_mesh_impact)
		parent.add_child(s)
		spark_pool.append(s)
		spark_until.append(0.0)
	for i in HOLE_POOL:
		var h := _fx_node(hole_mesh)
		parent.add_child(h)
		hole_pool.append(h)
