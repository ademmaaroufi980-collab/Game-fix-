class_name WeaponViewModels
extends RefCounted
## Builds the procedural first-person gun models (boxes) plus muzzle flash nodes.

const DARK := Color(0.12, 0.12, 0.14)
const MID := Color(0.22, 0.23, 0.26)
const WOOD := Color(0.4, 0.26, 0.14)


## Returns {"guns": Array[Node3D], "muzzles": Array[Node3D], "flashes": Array[Node3D]},
## one entry per weapon (same order as `weapons`). Guns start hidden.
static func build(view: Node3D, weapons: Array[WeaponData]) -> Dictionary:
	AssetBridge.prepare()
	var guns: Array[Node3D] = []
	var muzzles: Array[Node3D] = []
	var flashes: Array[Node3D] = []

	var flash_mat := StandardMaterial3D.new()
	flash_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	flash_mat.albedo_color = Color(1.0, 0.75, 0.3)

	for data in weapons:
		var g := Node3D.new()
		g.visible = false
		view.add_child(g)
		var imported := AssetBridge.instantiate(g, data.model, true)
		if imported == null:
			_build_model(g, data.model)
		else:
			# Imported models are authored as world-facing assets; keep them stable in the FPS view.
			imported.position = Vector3.ZERO
			imported.rotation = Vector3.ZERO

		var muzzle := Marker3D.new()
		muzzle.position = data.muzzle_pos
		if imported != null and AssetBridge.MUZZLE.has(data.model):
			muzzle.position = AssetBridge.MUZZLE[data.model]
		g.add_child(muzzle)
		var flash := Node3D.new()
		flash.visible = false
		muzzle.add_child(flash)
		var light := OmniLight3D.new()
		light.light_color = Color(1.0, 0.7, 0.3)
		light.light_energy = 3.0
		light.omni_range = 7.0
		flash.add_child(light)
		var fm := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.05
		sm.height = 0.1
		sm.material = flash_mat
		fm.mesh = sm
		fm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		flash.add_child(fm)
		guns.append(g)
		muzzles.append(muzzle)
		flashes.append(flash)
	return {"guns": guns, "muzzles": muzzles, "flashes": flashes}


static func _build_model(g: Node3D, model: String) -> void:
	match model:
		"pistol":
			_part(g, Vector3(0.05, 0.07, 0.22), Vector3(0, 0, -0.11), DARK)
			_part(g, Vector3(0.045, 0.13, 0.06), Vector3(0, -0.09, -0.03), WOOD, -12.0, 0.0)
		"ak47":
			_part(g, Vector3(0.06, 0.09, 0.45), Vector3(0, 0, -0.22), DARK)
			_part(g, Vector3(0.05, 0.06, 0.25), Vector3(0, 0, -0.5), MID)
			_part(g, Vector3(0.02, 0.02, 0.2), Vector3(0, 0.005, -0.72), DARK)
			_part(g, Vector3(0.04, 0.14, 0.07), Vector3(0, -0.11, -0.2), MID, 8.0)
			_part(g, Vector3(0.05, 0.08, 0.22), Vector3(0, -0.01, 0.1), WOOD, 0.0, 0.0)
			_part(g, Vector3(0.02, 0.03, 0.05), Vector3(0, 0.06, -0.3), DARK)
		"shootgun1":
			_part(g, Vector3(0.06, 0.08, 0.4), Vector3(0, 0, -0.2), DARK)
			_part(g, Vector3(0.035, 0.035, 0.55), Vector3(0, 0.025, -0.6), MID)
			_part(g, Vector3(0.03, 0.03, 0.45), Vector3(0, -0.02, -0.55), MID)
			_part(g, Vector3(0.06, 0.05, 0.15), Vector3(0, -0.03, -0.5), WOOD, 0.0, 0.0)
			_part(g, Vector3(0.05, 0.09, 0.25), Vector3(0, -0.02, 0.1), WOOD, 0.0, 0.0)
		"awm":
			_part(g, Vector3(0.055, 0.08, 0.55), Vector3(0, 0, -0.27), DARK)
			_part(g, Vector3(0.025, 0.025, 0.5), Vector3(0, 0.005, -0.8), MID)
			_part(g, Vector3(0.05, 0.05, 0.25), Vector3(0, 0.075, -0.3), DARK)
			_part(g, Vector3(0.05, 0.1, 0.28), Vector3(0, -0.02, 0.12), WOOD, 0.0, 0.0)
		_:
			push_warning("Unknown weapon model: %s" % model)


static func _part(parent: Node3D, size: Vector3, pos: Vector3, color: Color, rot_x := 0.0, metallic := 0.6) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.metallic = metallic
	m.roughness = 0.45
	bm.material = m
	mi.mesh = bm
	mi.position = pos
	mi.rotation.x = deg_to_rad(rot_x)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
