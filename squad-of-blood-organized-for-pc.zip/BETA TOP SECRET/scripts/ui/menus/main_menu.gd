extends Control
## Lobby (FPS style): your soldier in the middle on a floodlit island. Loadout (weapon stats + outfit)
## on the left, current mode + SELECT MODE + START on the right. SELECT MODE opens a full-screen
## mode picker. Drag anywhere on the scene to turn the soldier.

const UIStyle = preload("res://scripts/ui/theme/ui_style.gd")
## One scene per mode (each inherits scenes/arena.tscn).
const MODE_SCENES := {
	"free": "res://scenes/modes/free_play.tscn",
	"timed": "res://scenes/modes/timed.tscn",
	"rounds": "res://scenes/modes/rounds.tscn",
	"br": "res://scenes/modes/battle_royale.tscn",
}
const SIDE_W := 350.0

# soon = shown in the lobby but cannot be started yet
const VERSION_TEXT := "0.1 BETA"
const AVATAR_PATH := "res://assets/art/player_avatar.jpg"

const MODES := [
	{"key": "free", "num": "01", "title": "FREE PLAY", "tag": "Practice", "meta": "SOLO  ·  NO TIME LIMIT", "color": Color(0.35, 0.85, 0.55), "soon": false},
	{"key": "timed", "num": "02", "title": "TIMED", "tag": "Beat the clock", "meta": "SOLO  ·  60 SECONDS", "color": Color(1.0, 0.78, 0.2), "soon": false},
	{"key": "rounds", "num": "03", "title": "ROUNDS", "tag": "Survive the waves", "meta": "SOLO  ·  ESCALATING", "color": Color(0.95, 0.3, 0.3), "soon": false},
	{"key": "br", "num": "04", "title": "BATTLE ROYALE", "tag": "Drop from the plane", "meta": "SOLO  ·  SKY DROP", "color": Color(0.35, 0.7, 1.0), "soon": false},
]

var stage: LobbyStage
var stage_vp: SubViewport
var ui_root: Control
var settings_layer: Control
var settings_menu: SettingsMenu
var mode_layer: Control
var start_button: Button
var select_button: Button
var mode_bar: ColorRect
var mode_name_label: Label
var mode_tag_label: Label
var desc_label: Label
var best_label: Label
var total_label: Label
var hint_label: Label
var weapon_label: Label
var outfit_label: Label
var cards := {}
var coin_labels: Array[Label] = []
var gem_labels: Array[Label] = []
var level_label: Label
var xp_bar: ProgressBar
var swatch_flow: HFlowContainer
var store_layer: Control
var store_pages: Array[Control] = []
var store_tabs: Array[Button] = []
var store_tiles: Array[Button] = []
var store_sel := 0
var store_name_label: Label
var store_info_label: Label
var store_action: Button
var daily_button: Button
var toast_label: Label
var toast_tw: Tween
var stat_rows := {}
var swatches: Array[Button] = []
var selected := "free"
var stats_ready := false


func _ready() -> void:
	theme = UIStyle.make_theme()
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

	# A skin that is not owned (e.g. a reset save) falls back to the first one
	if not Game.owns(str(LobbyStage.OUTFITS[clampi(Game.outfit, 0, LobbyStage.OUTFITS.size() - 1)]["id"])):
		Game.set_outfit(0)

	_build_stage()
	_build_ui()
	_build_mode_layer()
	_build_store_layer()
	_build_settings_layer()
	Game.wallet_changed.connect(_refresh_wallet)
	_refresh_wallet()

	_refresh_hint()
	Settings.changed.connect(_refresh_hint)
	_select(Game.selected)
	_update_stats(Game.loadout)
	start_button.grab_focus()

	# Fade the interface in while the camera glides towards the soldier
	ui_root.modulate.a = 0.0
	create_tween().tween_property(ui_root, "modulate:a", 1.0, 0.6).set_delay(0.35)

	if not Game.welcome_shown:
		_show_welcome()


# --------------------------------------------------------------------------- welcome popup

## Shown once per launch the first time the lobby opens.
func _show_welcome() -> void:
	Game.welcome_shown = true
	var overlay := ColorRect.new()
	overlay.color = Color(0.0, 0.0, 0.0, 0.7)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(overlay)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(center)

	var card := UIStyle.panel(UIStyle.GLASS, 8, 36.0)
	center.add_child(card)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 14)
	card.add_child(col)

	var head := UIStyle.title("CONGRATULATIONS!", 44)
	head.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	col.add_child(head)
	var rule := UIStyle.accent_line(160.0, 4.0)
	rule.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	col.add_child(rule)
	for line in [
		["This is version %s" % VERSION_TEXT, 28, Color.WHITE],
		["For the developer only", 22, UIStyle.ACCENT_LIGHT],
		["Made with Godot", 18, UIStyle.TEXT_DIM],
	]:
		var l := UIStyle.label(line[0], line[1], line[2])
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(l)

	var close_welcome := func() -> void:
		overlay.queue_free()
		start_button.grab_focus()
	var ok := UIStyle.accent_button("CONTINUE", close_welcome, Vector2(260, 60), 24)
	ok.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	col.add_child(ok)
	ok.grab_focus()


# --------------------------------------------------------------------------- 3D stage

func _build_stage() -> void:
	var svc := SubViewportContainer.new()
	svc.stretch = true
	svc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	svc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(svc)
	stage_vp = SubViewport.new()
	stage_vp.own_world_3d = true
	stage_vp.handle_input_locally = false
	svc.add_child(stage_vp)
	stage = LobbyStage.new()
	stage_vp.add_child(stage)
	_apply_msaa()
	Settings.changed.connect(_apply_msaa)

	# Vignettes: dark sides keep the side panels readable, dark top/bottom frame the scene
	_add_shade(Vector2(0, 0), Vector2(1, 0),
		PackedColorArray([Color(0.02, 0.03, 0.06, 0.78), Color(0, 0, 0, 0), Color(0, 0, 0, 0), Color(0.02, 0.03, 0.06, 0.78)]),
		PackedFloat32Array([0.0, 0.3, 0.7, 1.0]))
	_add_shade(Vector2(0, 0), Vector2(0, 1),
		PackedColorArray([Color(0.02, 0.03, 0.06, 0.65), Color(0, 0, 0, 0), Color(0, 0, 0, 0), Color(0.02, 0.03, 0.06, 0.8)]),
		PackedFloat32Array([0.0, 0.2, 0.72, 1.0]))

	# Invisible layer under the interface that turns the soldier when dragged
	var drag_area := Control.new()
	drag_area.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	drag_area.gui_input.connect(_on_drag_input)
	add_child(drag_area)


func _add_shade(from: Vector2, to: Vector2, colors: PackedColorArray, offsets: PackedFloat32Array, parent: Node = null) -> void:
	var grad := Gradient.new()
	grad.colors = colors
	grad.offsets = offsets
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill_from = from
	gt.fill_to = to
	var shade := TextureRect.new()
	shade.texture = gt
	shade.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	shade.stretch_mode = TextureRect.STRETCH_SCALE
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	if parent == null:
		parent = self
	parent.add_child(shade)


func _apply_msaa() -> void:
	stage_vp.msaa_3d = clampi(Settings.msaa, 0, 2) as Viewport.MSAA


func _on_drag_input(event: InputEvent) -> void:
	var mm := event as InputEventMouseMotion
	if mm and (mm.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
		stage.drag(mm.relative.x)


# --------------------------------------------------------------------------- interface

func _build_ui() -> void:
	var margin := MarginContainer.new()
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 32)
	margin.add_theme_constant_override("margin_right", 32)
	margin.add_theme_constant_override("margin_top", 20)
	margin.add_theme_constant_override("margin_bottom", 16)
	add_child(margin)
	ui_root = margin

	var col := VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", 10)
	margin.add_child(col)

	col.add_child(_build_top_bar())
	var mid := HBoxContainer.new()
	mid.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mid.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(mid)
	mid.add_child(_build_loadout_column())
	mid.add_child(UIStyle.spacer(true))
	mid.add_child(_build_play_column())

	hint_label = UIStyle.label("", 13, UIStyle.TEXT_DIM)
	hint_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_child(hint_label)


func _left(text: String, size: int, color: Color) -> Label:
	var l := UIStyle.label(text, size, color)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	return l


func _build_top_bar() -> Control:
	var bar := HBoxContainer.new()
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_theme_constant_override("separation", 12)

	# Player profile (top left)
	bar.add_child(_build_profile_card())
	bar.add_child(UIStyle.spacer(true))

	# Logo (top centre)
	var logo_box := VBoxContainer.new()
	logo_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	logo_box.add_theme_constant_override("separation", 2)
	logo_box.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	logo_box.add_child(UIStyle.title("SQUAD OF BLOOD", 34))
	var line := UIStyle.accent_line(130.0, 4.0)
	line.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	logo_box.add_child(line)
	logo_box.add_child(UIStyle.label("TACTICAL SHOOTER", 12, UIStyle.TEXT_DIM))
	bar.add_child(logo_box)
	bar.add_child(UIStyle.spacer(true))

	# Currencies + SETTINGS / QUIT (top right)
	var wallet := HBoxContainer.new()
	wallet.mouse_filter = Control.MOUSE_FILTER_IGNORE
	wallet.add_theme_constant_override("separation", 8)
	wallet.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	wallet.add_child(_chip("coins"))
	wallet.add_child(_chip("gems"))
	var plus := UIStyle.button("+", func() -> void: _open_store(1))
	plus.custom_minimum_size = Vector2(44, 44)
	plus.add_theme_font_size_override("font_size", 24)
	plus.tooltip_text = "Get coins and CAC"
	wallet.add_child(plus)
	bar.add_child(wallet)

	var settings_btn := UIStyle.button("SETTINGS", _open_settings)
	var quit_btn := UIStyle.button("QUIT", _on_quit)
	for b in [settings_btn, quit_btn]:
		b.custom_minimum_size = Vector2(120, 44)
		b.add_theme_font_size_override("font_size", 16)
		b.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
		bar.add_child(b)
	return bar


func _chip(kind: String) -> PanelContainer:
	var c := UIStyle.currency_chip(kind)
	var l: Label = c.get_meta("value")
	if kind == "coins":
		coin_labels.append(l)
	else:
		gem_labels.append(l)
	return c


func _build_profile_card() -> Control:
	var card := UIStyle.panel(UIStyle.GLASS, 6, 8.0)
	card.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 12)
	card.add_child(row)
	var av_style := UIStyle.box(UIStyle.ACCENT, UIStyle.ACCENT_LIGHT, 4, 2)
	av_style.content_margin_left = 0
	av_style.content_margin_right = 0
	av_style.content_margin_top = 0
	av_style.content_margin_bottom = 0
	var avatar := PanelContainer.new()
	avatar.custom_minimum_size = Vector2(64, 64)
	avatar.add_theme_stylebox_override("panel", av_style)
	var avatar_tex := load(AVATAR_PATH) as Texture2D
	if avatar_tex != null:
		var pic := TextureRect.new()
		pic.texture = avatar_tex
		pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		pic.mouse_filter = Control.MOUSE_FILTER_IGNORE
		avatar.add_child(pic)
	else:
		var initial := UIStyle.title("P", 28, Color.WHITE)
		initial.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		avatar.add_child(initial)
	row.add_child(avatar)

	var info := VBoxContainer.new()
	info.mouse_filter = Control.MOUSE_FILTER_IGNORE
	info.alignment = BoxContainer.ALIGNMENT_CENTER
	info.add_theme_constant_override("separation", 1)
	info.add_child(_left("OPERATOR", 22, Color.WHITE))
	var lv_row := HBoxContainer.new()
	lv_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	lv_row.add_theme_constant_override("separation", 10)
	level_label = _left("LV 1", 15, UIStyle.ACCENT_LIGHT)
	total_label = _left("", 13, UIStyle.GOLD)
	lv_row.add_child(level_label)
	lv_row.add_child(total_label)
	info.add_child(lv_row)
	xp_bar = ProgressBar.new()
	xp_bar.min_value = 0.0
	xp_bar.max_value = 1.0
	xp_bar.step = 0.001
	xp_bar.show_percentage = false
	xp_bar.custom_minimum_size = Vector2(200, 6)
	xp_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(1, 1, 1, 0.12)
	var fill := StyleBoxFlat.new()
	fill.bg_color = UIStyle.ACCENT
	xp_bar.add_theme_stylebox_override("background", bg)
	xp_bar.add_theme_stylebox_override("fill", fill)
	info.add_child(xp_bar)
	row.add_child(info)
	row.add_child(UIStyle.spacer(false, false, Vector2(8, 0)))
	return card


func _build_loadout_column() -> Control:
	var left := VBoxContainer.new()
	left.mouse_filter = Control.MOUSE_FILTER_IGNORE
	left.custom_minimum_size = Vector2(SIDE_W, 0)
	left.add_theme_constant_override("separation", 8)
	# STORE sits at the top of the left column
	left.add_child(UIStyle.ghost_button("STORE", func() -> void: _open_store(0), Vector2(SIDE_W, 62), 26))
	left.add_child(UIStyle.spacer(false, true))   # pushes the loadout card to the bottom

	var card := UIStyle.card("LOADOUT")
	left.add_child(card)
	var v: VBoxContainer = card.get_meta("body")

	# Weapon picker
	var wrow := HBoxContainer.new()
	wrow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	wrow.add_theme_constant_override("separation", 8)
	var prev := UIStyle.button("<", func() -> void: _cycle_weapon(-1))
	var next := UIStyle.button(">", func() -> void: _cycle_weapon(1))
	for b in [prev, next]:
		b.custom_minimum_size = Vector2(52, 46)
	weapon_label = UIStyle.title(stage.weapon_name(Game.loadout), 28, Color.WHITE)
	weapon_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	weapon_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	wrow.add_child(prev)
	wrow.add_child(weapon_label)
	wrow.add_child(next)
	v.add_child(wrow)

	# Weapon stats
	var stats_box := VBoxContainer.new()
	stats_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stats_box.add_theme_constant_override("separation", 6)
	for s in [["dmg", "DAMAGE"], ["rate", "FIRE RATE"], ["range", "RANGE"], ["mag", "MAGAZINE"]]:
		var row := UIStyle.stat_row(s[1])
		stats_box.add_child(row)
		stat_rows[s[0]] = row
	v.add_child(stats_box)

	# Outfit: the skins you own (buy more in the store)
	v.add_child(UIStyle.section_header("OUTFIT"))
	swatch_flow = HFlowContainer.new()
	swatch_flow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	swatch_flow.add_theme_constant_override("h_separation", 8)
	swatch_flow.add_theme_constant_override("v_separation", 8)
	v.add_child(swatch_flow)
	outfit_label = _left("", 18, UIStyle.ACCENT_LIGHT)
	v.add_child(outfit_label)
	_rebuild_swatches()
	return left


func _build_play_column() -> Control:
	var right := VBoxContainer.new()
	right.mouse_filter = Control.MOUSE_FILTER_IGNORE
	right.custom_minimum_size = Vector2(SIDE_W, 0)
	right.add_theme_constant_override("separation", 10)
	right.add_child(UIStyle.spacer(false, true))   # pushes everything to the bottom

	# Current mode summary
	var card := UIStyle.card("CURRENT MODE")
	right.add_child(card)
	var v: VBoxContainer = card.get_meta("body")
	var name_row := HBoxContainer.new()
	name_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	name_row.add_theme_constant_override("separation", 12)
	mode_bar = ColorRect.new()
	mode_bar.custom_minimum_size = Vector2(6, 34)
	mode_bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	mode_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	name_row.add_child(mode_bar)
	var name_col := VBoxContainer.new()
	name_col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	name_col.add_theme_constant_override("separation", 0)
	mode_name_label = UIStyle.title("", 30, Color.WHITE)
	mode_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	mode_tag_label = _left("", 15, UIStyle.ACCENT_LIGHT)
	name_col.add_child(mode_name_label)
	name_col.add_child(mode_tag_label)
	name_row.add_child(name_col)
	v.add_child(name_row)
	desc_label = _left("", 14, UIStyle.TEXT)
	desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	desc_label.custom_minimum_size = Vector2(SIDE_W - 40.0, 56)
	v.add_child(desc_label)
	best_label = _left("", 20, UIStyle.GOLD)
	v.add_child(best_label)

	# SELECT MODE sits right above START
	select_button = UIStyle.ghost_button("SELECT MODE", _open_modes, Vector2(SIDE_W, 62), 24)
	right.add_child(select_button)
	start_button = UIStyle.accent_button("START", _on_start, Vector2(SIDE_W, 86), 36)
	right.add_child(start_button)
	return right


## Full-screen mode picker: four tall tiles in a row.
func _build_mode_layer() -> void:
	mode_layer = Control.new()
	mode_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mode_layer.visible = false
	add_child(mode_layer)
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.02, 0.04, 0.84)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mode_layer.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mode_layer.add_child(center)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 18)
	center.add_child(box)

	var head := VBoxContainer.new()
	head.add_theme_constant_override("separation", 2)
	head.add_child(UIStyle.title("SELECT MODE", 50))
	head.add_child(UIStyle.label("Choose how you want to fight", 17, UIStyle.TEXT_DIM))
	box.add_child(head)

	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 18)
	box.add_child(row)
	var group := ButtonGroup.new()
	for m in MODES:
		var key: String = m["key"]
		var tile := UIStyle.mode_tile(m["num"], m["title"], m["tag"], _describe(key), m["meta"],
				"BEST  %d" % int(Game.best.get(key, 0)), m["color"])
		tile.button_group = group
		tile.pressed.connect(func() -> void: _pick_mode(key))
		row.add_child(tile)
		cards[key] = tile

	var back := UIStyle.nav_button("BACK", _close_modes, Vector2(220, 54), 22)
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	box.add_child(back)


func _build_settings_layer() -> void:
	settings_layer = Control.new()
	settings_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	settings_layer.visible = false
	add_child(settings_layer)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.7)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	settings_layer.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	settings_layer.add_child(center)
	settings_menu = SettingsMenu.new()
	settings_menu.closed.connect(_close_settings)
	center.add_child(settings_menu)


# --------------------------------------------------------------------------- behaviour

func _mode(key: String) -> Dictionary:
	for m in MODES:
		if m["key"] == key:
			return m
	return MODES[0]


func _is_soon(key: String) -> bool:
	return bool(_mode(key)["soon"])


func _describe(key: String) -> String:
	match key:
		"free":
			return "Enemies hunt you and shoot back, then respawn at random spots. No time limit."
		"timed":
			return "Score as much as you can in %d seconds while enemies shoot back." % int(Game.TIME_LIMIT)
		"rounds":
			return "Clear every enemy before the clock runs out. Each round brings more, smarter enemies and less time."
		"br":
			return "Ride the plane, jump out, open your parachute and land on the ground."
	return ""


func _select(key: String) -> void:
	selected = key
	var m := _mode(key)
	var color: Color = m["color"]
	(cards[key] as Button).set_pressed_no_signal(true)
	for k in cards:
		((cards[k] as Button).get_meta("badge") as Label).visible = k == key
	var soon := _is_soon(key)
	mode_bar.color = color
	mode_name_label.text = str(m["title"])
	mode_tag_label.text = str(m["tag"])
	mode_tag_label.add_theme_color_override("font_color", color.lightened(0.25))
	desc_label.text = _describe(key)
	best_label.visible = not soon
	if not soon:
		best_label.text = "BEST  %d" % int(Game.best.get(key, 0))
	start_button.disabled = soon
	start_button.text = "COMING SOON" if soon else "START"
	var total := 0
	for k in Game.best:
		total += int(Game.best[k])
	total_label.text = "TOTAL BEST  %d" % total


func _open_modes() -> void:
	ui_root.visible = false
	mode_layer.visible = true
	mode_layer.modulate.a = 0.0
	create_tween().tween_property(mode_layer, "modulate:a", 1.0, 0.18)
	(cards[selected] as Button).grab_focus()


func _close_modes() -> void:
	if not mode_layer.visible:
		return
	mode_layer.visible = false
	ui_root.visible = true
	start_button.grab_focus()


func _pick_mode(key: String) -> void:
	_select(key)
	get_tree().create_timer(0.18).timeout.connect(_close_modes)


## Weapon stat bars are relative to the strongest weapon in each category.
func _weapon_stats(w: WeaponData) -> Dictionary:
	return {
		"dmg": w.damage * float(w.pellets),
		"rate": 1.0 / maxf(w.rate, 0.01),
		"range": w.max_range,
		"mag": float(w.mag),
	}


func _update_stats(i: int) -> void:
	var list: Array[WeaponData] = stage.weapons
	if list.is_empty():
		return
	var best := {"dmg": 0.001, "rate": 0.001, "range": 0.001, "mag": 0.001}
	for w in list:
		var s := _weapon_stats(w)
		for k in best:
			best[k] = maxf(best[k], float(s[k]))
	var cur := _weapon_stats(list[posmod(i, list.size())])
	for k in stat_rows:
		var row: HBoxContainer = stat_rows[k]
		var bar: ProgressBar = row.get_meta("bar")
		var val: Label = row.get_meta("value")
		var target := clampf(float(cur[k]) / float(best[k]), 0.06, 1.0)
		if stats_ready:
			create_tween().tween_property(bar, "value", target, 0.25)
		else:
			bar.value = target
		match k:
			"dmg":
				val.text = "%d" % int(round(float(cur[k])))
			"rate":
				val.text = "%.1f/s" % float(cur[k])
			"range":
				val.text = "%dm" % int(round(float(cur[k])))
			"mag":
				val.text = "%d" % int(round(float(cur[k])))
	stats_ready = true


func _cycle_weapon(step: int) -> void:
	var i := posmod(Game.loadout + step, stage.weapon_count())
	Game.set_loadout(i)
	stage.set_weapon(i)
	weapon_label.text = stage.weapon_name(i)
	_update_stats(i)


func _pick_outfit(i: int) -> void:
	Game.set_outfit(i)
	stage.set_outfit(i)
	outfit_label.text = str(LobbyStage.OUTFITS[i]["name"])


func _on_start() -> void:
	if _is_soon(selected):
		return
	Game.set_mode(selected)
	Loading.go(MODE_SCENES.get(selected, MODE_SCENES["free"]))


func _refresh_hint() -> void:
	hint_label.text = UIStyle.controls_move() + "\n" + UIStyle.controls_combat() + ("" if Settings.use_touch() else "  ·  Esc pause")


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if settings_layer.visible:
			settings_menu.close()
			get_viewport().set_input_as_handled()
		elif mode_layer.visible:
			_close_modes()
			get_viewport().set_input_as_handled()
		elif store_layer.visible:
			_close_store()
			get_viewport().set_input_as_handled()


func _open_settings() -> void:
	ui_root.visible = false
	settings_layer.visible = true
	settings_menu.focus_first()


func _close_settings() -> void:
	settings_layer.visible = false
	ui_root.visible = true
	start_button.grab_focus()


func _on_quit() -> void:
	get_tree().quit()


# --------------------------------------------------------------------------- wallet / profile

func _refresh_wallet() -> void:
	for l in coin_labels:
		l.text = str(Game.coins)
	for l in gem_labels:
		l.text = str(Game.gems)
	level_label.text = "LV %d" % Game.level()
	xp_bar.value = Game.level_progress()
	if store_layer != null:
		_refresh_store()


## Lists only the skins you own as colour swatches.
func _rebuild_swatches() -> void:
	for c in swatch_flow.get_children():
		swatch_flow.remove_child(c)
		c.queue_free()
	swatches.clear()
	var group := ButtonGroup.new()
	for i in LobbyStage.OUTFITS.size():
		var o: Dictionary = LobbyStage.OUTFITS[i]
		if not Game.owns(str(o["id"])):
			continue
		var sw := UIStyle.swatch(o["shirt"])
		sw.custom_minimum_size = Vector2(38, 38)
		sw.button_group = group
		sw.tooltip_text = str(o["name"])
		sw.pressed.connect(func() -> void: _pick_outfit(i))
		swatch_flow.add_child(sw)
		swatches.append(sw)
		if i == Game.outfit:
			sw.set_pressed_no_signal(true)
	outfit_label.text = str(LobbyStage.OUTFITS[Game.outfit]["name"])


# --------------------------------------------------------------------------- store

func _build_store_layer() -> void:
	store_layer = Control.new()
	store_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	store_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE   # the soldier can still be dragged
	store_layer.visible = false
	add_child(store_layer)

	# Soldier stays visible on the left, the shop panel sits on the right
	_add_shade(Vector2(0, 0), Vector2(1, 0),
		PackedColorArray([Color(0.02, 0.03, 0.06, 0.45), Color(0, 0, 0, 0), Color(0, 0, 0, 0), Color(0.02, 0.03, 0.06, 0.93), Color(0.02, 0.03, 0.06, 0.96)]),
		PackedFloat32Array([0.0, 0.18, 0.38, 0.62, 1.0]), store_layer)
	_add_shade(Vector2(0, 0), Vector2(0, 1),
		PackedColorArray([Color(0.02, 0.03, 0.06, 0.65), Color(0, 0, 0, 0), Color(0, 0, 0, 0), Color(0.02, 0.03, 0.06, 0.7)]),
		PackedFloat32Array([0.0, 0.2, 0.8, 1.0]), store_layer)

	var margin := MarginContainer.new()
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 32)
	margin.add_theme_constant_override("margin_right", 32)
	margin.add_theme_constant_override("margin_top", 20)
	margin.add_theme_constant_override("margin_bottom", 20)
	store_layer.add_child(margin)
	var col := VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", 12)
	margin.add_child(col)

	var top := HBoxContainer.new()
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_theme_constant_override("separation", 10)
	var head := VBoxContainer.new()
	head.mouse_filter = Control.MOUSE_FILTER_IGNORE
	head.add_theme_constant_override("separation", 2)
	var title := UIStyle.title("STORE", 50)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	head.add_child(title)
	head.add_child(UIStyle.accent_line(110.0, 4.0))
	top.add_child(head)
	top.add_child(UIStyle.spacer(true))
	var chips := HBoxContainer.new()
	chips.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chips.add_theme_constant_override("separation", 8)
	chips.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	chips.add_child(_chip("coins"))
	chips.add_child(_chip("gems"))
	top.add_child(chips)
	var back := UIStyle.nav_button("BACK", _close_store, Vector2(150, 48), 20)
	back.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	top.add_child(back)
	col.add_child(top)

	var mid := HBoxContainer.new()
	mid.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mid.size_flags_vertical = Control.SIZE_EXPAND_FILL
	mid.add_child(UIStyle.spacer(true))
	mid.add_child(_build_store_panel())
	col.add_child(mid)


func _build_store_panel() -> Control:
	var panel := UIStyle.panel(UIStyle.GLASS, 6, 18.0)
	panel.custom_minimum_size = Vector2(580, 0)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	panel.add_child(v)

	var tab_row := HBoxContainer.new()
	tab_row.add_theme_constant_override("separation", 8)
	var group := ButtonGroup.new()
	var names: Array[String] = ["SKINS", "CURRENCY"]
	for i in names.size():
		var tb := Button.new()
		tb.text = names[i]
		tb.toggle_mode = true
		tb.button_group = group
		tb.custom_minimum_size = Vector2(150, 44)
		tb.add_theme_font_size_override("font_size", 18)
		tb.pressed.connect(func() -> void: _store_tab(i))
		tab_row.add_child(tb)
		store_tabs.append(tb)
	v.add_child(tab_row)

	store_pages.append(_build_skins_page())
	store_pages.append(_build_currency_page())
	for p in store_pages:
		v.add_child(p)

	toast_label = UIStyle.label("", 18, Color.WHITE)
	toast_label.modulate.a = 0.0
	v.add_child(toast_label)
	return panel


func _build_skins_page() -> Control:
	var page := VBoxContainer.new()
	page.size_flags_vertical = Control.SIZE_EXPAND_FILL
	page.add_theme_constant_override("separation", 12)

	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.custom_minimum_size = Vector2(0, 220)
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	page.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	scroll.add_child(grid)
	var group := ButtonGroup.new()
	for i in LobbyStage.OUTFITS.size():
		var o: Dictionary = LobbyStage.OUTFITS[i]
		var tile := UIStyle.skin_tile(str(o["name"]), str(o["rarity"]), [o["shirt"], o["vest"], o["accent"]])
		tile.button_group = group
		tile.pressed.connect(func() -> void: _store_select(i))
		grid.add_child(tile)
		store_tiles.append(tile)

	# Selected skin: details and the BUY / EQUIP button
	var detail := UIStyle.panel(Color(0.03, 0.05, 0.08, 0.9), 4, 12.0)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	detail.add_child(row)
	var dcol := VBoxContainer.new()
	dcol.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	dcol.alignment = BoxContainer.ALIGNMENT_CENTER
	dcol.add_theme_constant_override("separation", 2)
	store_name_label = UIStyle.title("", 26, Color.WHITE)
	store_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	store_info_label = _left("", 14, UIStyle.TEXT_DIM)
	dcol.add_child(store_name_label)
	dcol.add_child(store_info_label)
	row.add_child(dcol)
	store_action = UIStyle.accent_button("BUY", _store_action, Vector2(230, 60), 22)
	row.add_child(store_action)
	page.add_child(detail)
	return page


func _build_currency_page() -> Control:
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(0, 300)
	var page := VBoxContainer.new()
	page.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	page.add_theme_constant_override("separation", 10)
	scroll.add_child(page)

	# Free coins
	page.add_child(UIStyle.section_header("FREE COINS"))
	var drow := HBoxContainer.new()
	drow.add_theme_constant_override("separation", 12)
	var dcol := VBoxContainer.new()
	dcol.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	dcol.add_child(_left("DAILY REWARD   +%d COINS" % Game.DAILY_REWARD, 18, Color.WHITE))
	dcol.add_child(_left("Play any mode to earn more: every run pays coins from your score.", 13, UIStyle.TEXT_DIM))
	drow.add_child(dcol)
	daily_button = UIStyle.accent_button("CLAIM", _claim_daily, Vector2(210, 54), 20)
	drow.add_child(daily_button)
	page.add_child(drow)

	# Gems (test purchases)
	page.add_child(UIStyle.section_header("CAC   ·   TEST PURCHASE"))
	var note := _left("Test mode: no real money is charged, CAC is added for free.", 13, UIStyle.TEXT_DIM)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	page.add_child(note)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	var packs := [[80, "$0.99"], [450, "$4.99"], [1000, "$9.99"], [2200, "$19.99"]]
	for p in packs:
		var amount: int = p[0]
		var btn := UIStyle.ghost_button("%d CAC   %s" % [amount, p[1]], func() -> void: _test_buy_gems(amount), Vector2(250, 56), 19)
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(btn)
	page.add_child(grid)

	# Exchange
	page.add_child(UIStyle.section_header("EXCHANGE"))
	var ex := UIStyle.ghost_button("10 CAC   >   600 COINS", _exchange, Vector2(250, 54), 19)
	page.add_child(ex)
	return scroll


func _open_store(tab: int) -> void:
	ui_root.visible = false
	store_layer.visible = true
	store_layer.modulate.a = 0.0
	create_tween().tween_property(store_layer, "modulate:a", 1.0, 0.18)
	store_sel = clampi(Game.outfit, 0, LobbyStage.OUTFITS.size() - 1)
	_store_tab(tab)
	_store_select(store_sel)
	store_tabs[tab].grab_focus()


func _close_store() -> void:
	if not store_layer.visible:
		return
	stage.set_outfit(Game.outfit)   # drop the preview
	store_layer.visible = false
	ui_root.visible = true
	start_button.grab_focus()


func _store_tab(i: int) -> void:
	for k in store_pages.size():
		store_pages[k].visible = k == i
	store_tabs[i].set_pressed_no_signal(true)


func _store_select(i: int) -> void:
	store_sel = i
	stage.set_outfit(i)   # preview on the soldier
	_refresh_store()


func _price_text(o: Dictionary) -> String:
	return "%d %s" % [int(o["price"]), str(o["cur"]).to_upper()]


func _refresh_store() -> void:
	if store_tiles.is_empty():
		return
	for i in store_tiles.size():
		var o: Dictionary = LobbyStage.OUTFITS[i]
		var tile := store_tiles[i]
		var price: Label = tile.get_meta("price")
		if Game.owns(str(o["id"])):
			price.text = "EQUIPPED" if i == Game.outfit else "OWNED"
			price.add_theme_color_override("font_color", Color(0.45, 0.9, 0.55))
		else:
			price.text = _price_text(o)
			var ok := Game.can_afford(str(o["cur"]), int(o["price"]))
			price.add_theme_color_override("font_color", UIStyle.currency_color(str(o["cur"])) if ok else Color(1.0, 0.45, 0.4))
		tile.set_pressed_no_signal(i == store_sel)

	var cur: Dictionary = LobbyStage.OUTFITS[store_sel]
	store_name_label.text = str(cur["name"])
	var rar := str(cur["rarity"]).to_upper()
	if Game.owns(str(cur["id"])):
		store_info_label.text = rar + "  ·  owned"
		store_action.text = "EQUIPPED" if store_sel == Game.outfit else "EQUIP"
		store_action.disabled = store_sel == Game.outfit
	else:
		var missing := int(cur["price"]) - (Game.coins if cur["cur"] == "coins" else Game.gems)
		store_info_label.text = rar + ("  ·  need %d more %s" % [missing, str(cur["cur"])] if missing > 0 else "  ·  ready to buy")
		store_action.text = "BUY  " + _price_text(cur)
		store_action.disabled = false

	if daily_button != null:
		if Game.daily_ready():
			daily_button.text = "CLAIM"
			daily_button.disabled = false
		else:
			var secs := int(Game.daily_remaining())
			daily_button.text = "IN %dH %02dM" % [secs / 3600, (secs % 3600) / 60]
			daily_button.disabled = true


func _store_action() -> void:
	var o: Dictionary = LobbyStage.OUTFITS[store_sel]
	var id := str(o["id"])
	if Game.owns(id):
		Game.set_outfit(store_sel)
		_rebuild_swatches()
		_refresh_store()
		_toast("EQUIPPED  " + str(o["name"]), Color(0.45, 0.9, 0.55))
		return
	if Game.buy_skin(id, str(o["cur"]), int(o["price"])):
		Game.set_outfit(store_sel)
		_rebuild_swatches()
		_refresh_store()
		_toast("UNLOCKED  " + str(o["name"]), UIStyle.GOLD)
	else:
		var hint := "  ·  get CAC in CURRENCY" if o["cur"] == "gems" else "  ·  play a run or claim the daily reward"
		_toast("NOT ENOUGH " + str(o["cur"]).to_upper() + hint, Color(1.0, 0.45, 0.4))


func _claim_daily() -> void:
	var got := Game.claim_daily()
	if got > 0:
		_toast("+%d COINS" % got, UIStyle.COIN_COLOR)


func _test_buy_gems(amount: int) -> void:
	Game.add_test_gems(amount)
	_toast("+%d CAC  (TEST)" % amount, UIStyle.GEM_COLOR)


func _exchange() -> void:
	if Game.exchange_gems(10, 600):
		_toast("10 CAC  >  600 COINS", UIStyle.COIN_COLOR)
	else:
		_toast("NOT ENOUGH CAC", Color(1.0, 0.45, 0.4))


func _toast(text: String, color: Color) -> void:
	toast_label.text = text
	toast_label.add_theme_color_override("font_color", color)
	toast_label.modulate.a = 1.0
	if toast_tw:
		toast_tw.kill()
	toast_tw = create_tween()
	toast_tw.tween_interval(1.6)
	toast_tw.tween_property(toast_label, "modulate:a", 0.0, 0.4)
