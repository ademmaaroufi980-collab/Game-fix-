class_name SettingsMenu
extends VBoxContainer
## Settings panel built from code (used by the main menu and the pause menu).
## Emits `closed` after saving when the player presses BACK.

const UIStyle = preload("res://scripts/ui/theme/ui_style.gd")
const MSAA_LABELS: Array[String] = ["Off", "2x", "4x"]
const CONTROL_LABELS: Array[String] = ["Auto", "PC (keyboard + mouse)", "Mobile (touch)"]

signal closed

var first_focus: Control
var list: VBoxContainer
var pages: Array[VBoxContainer] = []
var tabs: Array[Button] = []


func _ready() -> void:
	theme = UIStyle.make_theme()
	add_theme_constant_override("separation", 14)
	alignment = BoxContainer.ALIGNMENT_CENTER
	add_child(UIStyle.title("SETTINGS", 48))
	var line := UIStyle.accent_line(120.0, 4.0)
	line.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	add_child(line)

	# Tabs
	var tab_row := HBoxContainer.new()
	tab_row.alignment = BoxContainer.ALIGNMENT_CENTER
	tab_row.add_theme_constant_override("separation", 8)
	add_child(tab_row)
	var group := ButtonGroup.new()
	var names: Array[String] = ["CONTROLS", "VIDEO", "AUDIO"]
	for i in names.size():
		var tb := Button.new()
		tb.text = names[i]
		tb.toggle_mode = true
		tb.button_group = group
		tb.custom_minimum_size = Vector2(170, 46)
		tb.add_theme_font_size_override("font_size", 18)
		tb.pressed.connect(func() -> void: _show_page(i))
		tab_row.add_child(tb)
		tabs.append(tb)

	var card := UIStyle.panel(UIStyle.GLASS, 6, 22.0)
	card.custom_minimum_size = Vector2(760, 300)
	add_child(card)
	for i in names.size():
		var page := VBoxContainer.new()
		page.add_theme_constant_override("separation", 6)
		page.visible = false
		card.add_child(page)
		pages.append(page)

	list = pages[0]
	_add_slider("Mouse sensitivity", "sensitivity", 0.2, 3.0, 0.05, "%.2fx", 1.0)
	_add_controls()

	list = pages[1]
	_add_slider("Field of view", "fov", 60.0, 110.0, 1.0, "%.0f°", 1.0)
	_add_check("SSAO (ambient occlusion)", "ssao")
	_add_msaa()
	_add_check("Show FPS", "show_fps")

	list = pages[2]
	_add_slider("Master volume", "volume", 0.0, 1.0, 0.05, "%.0f%%", 100.0)

	_show_page(0)
	tabs[0].set_pressed_no_signal(true)

	var back := UIStyle.accent_button("BACK", close, Vector2(260, 62), 26)
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	add_child(back)


func _show_page(idx: int) -> void:
	for i in pages.size():
		pages[i].visible = i == idx


## Saves and tells the parent menu to switch back.
func close() -> void:
	Settings.save_settings()
	closed.emit()


func focus_first() -> void:
	_show_page(0)
	tabs[0].set_pressed_no_signal(true)
	if first_focus:
		first_focus.grab_focus()


func _row(title: String) -> HBoxContainer:
	if list.get_child_count() > 0:
		list.add_child(HSeparator.new())
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	var l := UIStyle.label(title, 20, UIStyle.TEXT)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	l.custom_minimum_size = Vector2(260, 0)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(l)
	list.add_child(row)
	return row


func _add_slider(title: String, prop: String, lo: float, hi: float, step: float, fmt: String, display_scale: float) -> void:
	var row := _row(title)
	var slider := HSlider.new()
	slider.min_value = lo
	slider.max_value = hi
	slider.step = step
	slider.value = float(Settings.get(prop))
	slider.custom_minimum_size = Vector2(280, 34)
	slider.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(slider)
	var value_label := UIStyle.label(fmt % (slider.value * display_scale), 20, UIStyle.ACCENT_LIGHT)
	value_label.custom_minimum_size = Vector2(76, 0)
	value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(value_label)
	slider.value_changed.connect(func(v: float) -> void:
		Settings.set(prop, v)
		Settings.apply()
		value_label.text = fmt % (v * display_scale))
	if first_focus == null:
		first_focus = slider


func _add_check(title: String, prop: String) -> void:
	var row := _row(title)
	var cb := CheckButton.new()
	cb.button_pressed = bool(Settings.get(prop))
	cb.toggled.connect(func(on: bool) -> void:
		Settings.set(prop, on)
		Settings.apply())
	row.add_child(cb)


func _add_controls() -> void:
	var row := _row("Controls")
	var ob := OptionButton.new()
	for label_text in CONTROL_LABELS:
		ob.add_item(label_text)
	ob.select(clampi(Settings.controls, 0, CONTROL_LABELS.size() - 1))
	ob.custom_minimum_size = Vector2(240, 44)
	ob.item_selected.connect(func(idx: int) -> void:
		Settings.controls = idx
		Settings.apply())
	row.add_child(ob)


func _add_msaa() -> void:
	var row := _row("Anti-aliasing (MSAA)")
	var ob := OptionButton.new()
	for label_text in MSAA_LABELS:
		ob.add_item(label_text)
	ob.select(clampi(Settings.msaa, 0, MSAA_LABELS.size() - 1))
	ob.custom_minimum_size = Vector2(120, 44)
	ob.item_selected.connect(func(idx: int) -> void:
		Settings.msaa = idx
		Settings.apply())
	row.add_child(ob)
