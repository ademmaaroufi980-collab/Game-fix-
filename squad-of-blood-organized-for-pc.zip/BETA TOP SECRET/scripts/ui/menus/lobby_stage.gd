class_name LobbyStage
extends Node3D
## 3D lobby backdrop (Free Fire / PUBG style): your soldier stands on a lit platform on a
## sunset island. Everything is built from primitives in code, so there are no assets.
## Drag to turn the soldier (call drag()), pick an outfit and a weapon with the setters.

const CAM_POS := Vector3(0.0, 1.25, 5.2)   # soldier stands in the middle, side panels left and right
const CAM_PITCH := -7.0
const CAM_FOV := 34.0
const BASE_YAW := PI + 0.2                 # soldier faces the camera, turned slightly towards START
const CHEST_Y := 1.2

# Skins: free ones are owned from the start, the others are bought in the store.
# cur = "free", "coins" (free currency) or "gems" (premium currency, test purchases only).
const OUTFITS := [
	{"id": "forest", "name": "FOREST", "rarity": "common", "cur": "free", "price": 0, "shirt": Color(0.27, 0.36, 0.22), "pants": Color(0.22, 0.28, 0.19), "vest": Color(0.15, 0.19, 0.13), "accent": Color(1.0, 0.7, 0.25)},
	{"id": "desert", "name": "DESERT", "rarity": "common", "cur": "free", "price": 0, "shirt": Color(0.66, 0.54, 0.36), "pants": Color(0.52, 0.42, 0.28), "vest": Color(0.36, 0.3, 0.2), "accent": Color(0.3, 0.85, 1.0)},
	{"id": "urban", "name": "URBAN", "rarity": "common", "cur": "free", "price": 0, "shirt": Color(0.2, 0.22, 0.28), "pants": Color(0.12, 0.13, 0.17), "vest": Color(0.07, 0.08, 0.1), "accent": Color(0.35, 0.75, 1.0)},
	{"id": "crimson", "name": "CRIMSON", "rarity": "common", "cur": "free", "price": 0, "shirt": Color(0.5, 0.1, 0.12), "pants": Color(0.16, 0.16, 0.18), "vest": Color(0.1, 0.1, 0.12), "accent": Color(1.0, 0.35, 0.25)},
	{"id": "arctic", "name": "ARCTIC", "rarity": "rare", "cur": "coins", "price": 600, "shirt": Color(0.82, 0.88, 0.94), "pants": Color(0.55, 0.62, 0.7), "vest": Color(0.35, 0.42, 0.5), "accent": Color(0.5, 0.9, 1.0)},
	{"id": "steel", "name": "STEEL", "rarity": "rare", "cur": "coins", "price": 900, "shirt": Color(0.4, 0.45, 0.5), "pants": Color(0.25, 0.28, 0.32), "vest": Color(0.15, 0.17, 0.2), "accent": Color(1.0, 0.85, 0.3)},
	{"id": "nightops", "name": "NIGHT OPS", "rarity": "epic", "cur": "coins", "price": 1500, "shirt": Color(0.1, 0.1, 0.14), "pants": Color(0.07, 0.07, 0.1), "vest": Color(0.16, 0.12, 0.24), "accent": Color(0.7, 0.35, 1.0)},
	{"id": "inferno", "name": "INFERNO", "rarity": "epic", "cur": "gems", "price": 40, "shirt": Color(0.55, 0.2, 0.05), "pants": Color(0.2, 0.1, 0.06), "vest": Color(0.1, 0.06, 0.05), "accent": Color(1.0, 0.55, 0.1)},
	{"id": "toxic", "name": "TOXIC", "rarity": "epic", "cur": "gems", "price": 60, "shirt": Color(0.25, 0.45, 0.1), "pants": Color(0.1, 0.16, 0.08), "vest": Color(0.06, 0.09, 0.05), "accent": Color(0.7, 1.0, 0.1)},
	{"id": "phantom", "name": "PHANTOM", "rarity": "epic", "cur": "coins", "price": 2500, "shirt": Color(0.08, 0.08, 0.1), "pants": Color(0.04, 0.04, 0.05), "vest": Color(0.1, 0.1, 0.12), "accent": Color(1.0, 0.15, 0.3)},
	{"id": "royal", "name": "ROYAL", "rarity": "legendary", "cur": "gems", "price": 90, "shirt": Color(0.2, 0.15, 0.4), "pants": Color(0.12, 0.09, 0.25), "vest": Color(0.1, 0.08, 0.2), "accent": Color(1.0, 0.85, 0.3)},
	{"id": "golden", "name": "GOLDEN", "rarity": "legendary", "cur": "gems", "price": 150, "shirt": Color(0.8, 0.62, 0.18), "pants": Color(0.45, 0.33, 0.1), "vest": Color(0.25, 0.18, 0.06), "accent": Color(1.0, 0.95, 0.6)},
]

# Where the gun is held (chest-local) and where the hands grip it (gun-local), per model.
const HOLD := {
	"pistol": {"pos": Vector3(0.03, -0.02, -0.42), "pitch": 6.0, "r": Vector3(0.0, -0.06, -0.03), "l": Vector3(0.02, -0.07, -0.06)},
	"rifle": {"pos": Vector3(0.13, -0.1, -0.2), "pitch": 8.0, "r": Vector3(0.0, -0.11, -0.2), "l": Vector3(0.0, -0.03, -0.48)},
	"shotgun": {"pos": Vector3(0.13, -0.1, -0.18), "pitch": 9.0, "r": Vector3(0.0, -0.05, 0.0), "l": Vector3(0.0, -0.03, -0.5)},
	"sniper": {"pos": Vector3(0.13, -0.08, -0.16), "pitch": 12.0, "r": Vector3(0.0, -0.04, 0.05), "l": Vector3(0.0, -0.03, -0.45)},
}
# The weapon files use the model names of the 3D assets (ak47 / shootgun1 / awm): same grips as above.
const HOLD_ALIASES := {"ak47": "rifle", "shootgun1": "shotgun", "awm": "sniper"}


static func hold_for(model: String) -> Dictionary:
	return HOLD[HOLD_ALIASES.get(model, model)] if (HOLD.has(model) or HOLD_ALIASES.has(model)) else HOLD["rifle"]

var mats := {}                    # outfit materials by name
var weapons: Array[WeaponData] = []
var guns: Array[Node3D] = []
var current_weapon := 0
var outfit := 0

var hero: Node3D
var chest: Node3D
var head: Node3D
var gun_mount: Node3D
var arms_root: Node3D
var camera: Camera3D
var ring_mat: StandardMaterial3D
var goggles_mat: StandardMaterial3D
var trunk_mat: StandardMaterial3D
var leaf_mat: StandardMaterial3D
var leaf_mat2: StandardMaterial3D

var time := 0.0
var spin := 0.0
var spin_vel := 0.0
var idle_t := 99.0


func _ready() -> void:
	_build_environment()
	_build_lights()
	_build_island()
	_build_platform()
	_build_scenery()
	_build_hero()
	_build_particles()
	_build_camera()
	set_outfit(Game.outfit)
	set_weapon(Game.loadout)


func _process(delta: float) -> void:
	time += delta
	idle_t += delta
	# Inertia after a drag, then ease back to facing the camera
	if idle_t > 0.08:
		spin += spin_vel * delta
		spin_vel = lerpf(spin_vel, 0.0, 1.0 - exp(-4.0 * delta))
	spin = wrapf(spin, -PI, PI)
	if idle_t > 2.5:
		spin = lerp_angle(spin, 0.0, 1.0 - exp(-1.6 * delta))
	hero.rotation.y = BASE_YAW + spin

	# Idle animation: breathing and looking around
	var breath := sin(time * 1.7)
	chest.position.y = CHEST_Y + breath * 0.006
	chest.scale = Vector3(1.0, 1.0 + breath * 0.008, 1.0)
	head.rotation.y = sin(time * 0.5) * 0.18
	head.rotation.x = sin(time * 0.8) * 0.03

	# Slow camera drift
	camera.rotation_degrees.y = sin(time * 0.35) * 0.8
	camera.rotation_degrees.x = CAM_PITCH + sin(time * 0.5) * 0.3


## Turn the soldier by a pointer movement in pixels.
func drag(dx: float) -> void:
	idle_t = 0.0
	spin += dx * 0.011
	spin_vel = dx * 0.011 * 60.0


func weapon_count() -> int:
	return weapons.size()


func weapon_name(i: int) -> String:
	return weapons[posmod(i, weapons.size())].display_name


func set_outfit(i: int) -> void:
	outfit = posmod(i, OUTFITS.size())
	var o: Dictionary = OUTFITS[outfit]
	(mats["shirt"] as StandardMaterial3D).albedo_color = o["shirt"]
	(mats["pants"] as StandardMaterial3D).albedo_color = o["pants"]
	(mats["vest"] as StandardMaterial3D).albedo_color = o["vest"]
	var a: Color = o["accent"]
	goggles_mat.albedo_color = a
	goggles_mat.emission = a
	ring_mat.albedo_color = a
	ring_mat.emission = a
	_pulse()


func set_weapon(i: int) -> void:
	if guns.is_empty():
		return
	current_weapon = posmod(i, guns.size())
	for g in guns.size():
		guns[g].visible = g == current_weapon
	var hold: Dictionary = hold_for(weapons[current_weapon].model)
	gun_mount.position = hold["pos"]
	gun_mount.rotation_degrees = Vector3(hold["pitch"], 0.0, 0.0)
	_rebuild_arms()
	_pulse()


## Short glow on the platform ring when something changes.
func _pulse() -> void:
	var tw := create_tween()
	tw.tween_property(ring_mat, "emission_energy_multiplier", 3.0, 0.5).from(9.0)


# --------------------------------------------------------------------------- helpers

func _mat(color: Color, rough := 0.8, metal := 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metal
	return m


func _emissive(color: Color, energy := 2.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.emission_enabled = true
	m.emission = color
	m.emission_energy_multiplier = energy
	return m


func _box(size: Vector3) -> BoxMesh:
	var m := BoxMesh.new()
	m.size = size
	return m


func _cyl(top: float, bottom: float, height: float, segments := 16) -> CylinderMesh:
	var m := CylinderMesh.new()
	m.top_radius = top
	m.bottom_radius = bottom
	m.height = height
	m.radial_segments = segments
	m.rings = 1
	return m


func _sphere(radius: float, squash := 1.0) -> SphereMesh:
	var m := SphereMesh.new()
	m.radius = radius
	m.height = radius * 2.0 * squash
	m.radial_segments = 20
	m.rings = 10
	return m


func _add(parent: Node3D, mesh: Mesh, mat: Material, pos := Vector3.ZERO, rot_deg := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees = rot_deg
	parent.add_child(mi)
	return mi


## A box stretched between two points (arms).
func _limb(parent: Node3D, from: Vector3, to: Vector3, thick: float, mat: Material) -> void:
	var length := from.distance_to(to)
	if length < 0.001:
		return
	var up := (to - from) / length
	var ref := Vector3.RIGHT if absf(up.dot(Vector3.RIGHT)) < 0.9 else Vector3.FORWARD
	var x := ref.cross(up).normalized()
	var z := x.cross(up).normalized()
	var mi := _add(parent, _box(Vector3(thick, length, thick)), mat, (from + to) * 0.5)
	mi.basis = Basis(x, up, z)


# --------------------------------------------------------------------------- world

func _build_environment() -> void:
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.13, 0.22, 0.48)
	sky_mat.sky_horizon_color = Color(1.0, 0.62, 0.36)
	sky_mat.sky_curve = 0.15
	sky_mat.ground_horizon_color = Color(0.95, 0.58, 0.38)
	sky_mat.ground_bottom_color = Color(0.1, 0.14, 0.24)
	sky_mat.ground_curve = 0.08
	sky_mat.sun_angle_max = 25.0
	sky_mat.sun_curve = 0.15
	var sky := Sky.new()
	sky.sky_material = sky_mat

	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.glow_enabled = true
	env.glow_intensity = 0.8
	env.glow_bloom = 0.08
	env.fog_enabled = true
	env.fog_light_color = Color(0.95, 0.62, 0.42)
	env.fog_density = 0.012
	env.fog_sky_affect = 0.0
	env.adjustment_enabled = true
	env.adjustment_saturation = 1.15
	env.adjustment_contrast = 1.06

	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)


func _build_lights() -> void:
	# Warm key light from the camera side
	var key := DirectionalLight3D.new()
	key.light_color = Color(1.0, 0.82, 0.62)
	key.light_energy = 1.5
	key.rotation_degrees = Vector3(-32.0, 35.0, 0.0)
	key.shadow_enabled = true
	key.directional_shadow_max_distance = 14.0
	key.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_ONLY
	add_child(key)

	# The sun you see in the sky, low behind the island (lights nothing)
	var sun := DirectionalLight3D.new()
	sun.light_color = Color(1.0, 0.7, 0.4)
	sun.light_energy = 2.0
	sun.rotation_degrees = Vector3(-6.0, 160.0, 0.0)
	sun.sky_mode = DirectionalLight3D.SKY_MODE_SKY_ONLY
	add_child(sun)

	# Cool and warm rim lights for the "hero" outline, soft fill from the front
	_omni(Vector3(-2.8, 2.6, -2.8), Color(0.5, 0.7, 1.0), 2.4, 9.0)
	_omni(Vector3(2.8, 2.2, -2.5), Color(1.0, 0.6, 0.3), 2.0, 9.0)
	_omni(Vector3(-3.0, 1.6, 3.5), Color(0.8, 0.85, 1.0), 0.5, 10.0)


func _omni(pos: Vector3, color: Color, energy: float, range_m: float) -> void:
	var l := OmniLight3D.new()
	l.position = pos
	l.light_color = color
	l.light_energy = energy
	l.omni_range = range_m
	add_child(l)


func _build_island() -> void:
	var grass := _mat(Color(0.3, 0.42, 0.2), 1.0)
	var rock := _mat(Color(0.3, 0.24, 0.2), 1.0)
	_add(self, _cyl(15.0, 15.0, 0.6, 48), grass, Vector3(0, -0.6, 0))   # top surface at y = -0.3
	_add(self, _cyl(15.0, 5.0, 8.0, 32), rock, Vector3(0, -4.9, 0))

	var sea := PlaneMesh.new()
	sea.size = Vector2(900, 900)
	_add(self, sea, _mat(Color(0.1, 0.28, 0.38), 0.25, 0.2), Vector3(0, -9.0, 0))

	# Distant mountains (x, height, z)
	var far := _mat(Color(0.26, 0.3, 0.45), 1.0)
	for p in [Vector3(-80, 34, -110), Vector3(-35, 26, -125), Vector3(10, 40, -135), Vector3(55, 30, -120), Vector3(95, 36, -105), Vector3(-110, 24, -80)]:
		var h: float = p.y
		_add(self, _cyl(0.0, h * 0.9, h, 6), far, Vector3(p.x, -9.0 + h * 0.5, p.z))


func _build_platform() -> void:
	var metal := _mat(Color(0.09, 0.1, 0.12), 0.35, 0.8)
	_add(self, _cyl(1.9, 2.0, 0.3, 48), metal, Vector3(0, -0.15, 0))
	_add(self, _cyl(1.7, 1.7, 0.02, 48), _mat(Color(0.05, 0.06, 0.08), 0.2, 0.6), Vector3(0, 0.005, 0))
	ring_mat = _emissive(Color(1.0, 0.6, 0.2), 3.0)
	var ring := TorusMesh.new()
	ring.inner_radius = 1.82
	ring.outer_radius = 1.92
	ring.rings = 48
	ring.ring_segments = 8
	_add(self, ring, ring_mat, Vector3(0, 0.01, 0))


func _build_scenery() -> void:
	trunk_mat = _mat(Color(0.28, 0.18, 0.1), 1.0)
	leaf_mat = _mat(Color(0.14, 0.32, 0.17), 1.0)
	leaf_mat2 = _mat(Color(0.2, 0.4, 0.2), 1.0)

	for t in [Vector3(-6, -6, 1.3), Vector3(-8.5, -3, 1.0), Vector3(-4.5, -9, 1.6), Vector3(-1, -11, 1.4),
			Vector3(3, -10, 1.5), Vector3(6.5, -8, 1.2), Vector3(9, -4.5, 1.1), Vector3(-10, -8, 1.7),
			Vector3(11, -9, 1.6), Vector3(8.5, 1.5, 1.0), Vector3(-9, 2.5, 1.2)]:
		_tree(Vector3(t.x, -0.3, t.y), t.z)

	var rock := _mat(Color(0.36, 0.34, 0.33), 1.0)
	for r in [[Vector3(-3.2, -0.3, 1.8), Vector3(0.9, 0.6, 0.8)], [Vector3(3.4, -0.3, -1.2), Vector3(0.7, 0.5, 0.9)],
			[Vector3(-3.8, -0.3, -1.6), Vector3(1.2, 0.8, 1.0)], [Vector3(4.2, -0.3, 2.4), Vector3(0.6, 0.4, 0.6)]]:
		var mi := _add(self, _sphere(0.5), rock, r[0], Vector3(0, r[0].x * 31.0, 0))
		mi.scale = r[1]

	# Supply crates, sandbag wall, flag and a jeep
	var crate := _mat(Color(0.72, 0.4, 0.13), 0.6)
	_add(self, _box(Vector3(0.9, 0.9, 0.9)), crate, Vector3(4.6, 0.15, -2.4), Vector3(0, 12, 0))
	_add(self, _box(Vector3(0.9, 0.9, 0.9)), crate, Vector3(5.6, 0.15, -2.8), Vector3(0, -8, 0))
	_add(self, _box(Vector3(0.8, 0.8, 0.8)), crate, Vector3(5.0, 1.0, -2.6), Vector3(0, 30, 0))
	var sand := _mat(Color(0.62, 0.55, 0.38), 1.0)
	for i in 6:
		var bag := _add(self, _sphere(0.28), sand, Vector3(3.0 + i * 0.5, -0.12, -1.3), Vector3(0, 8.0 * i, 0))
		bag.scale = Vector3(1.0, 0.55, 0.7)
	_add(self, _cyl(0.04, 0.04, 4.0, 8), _mat(Color(0.7, 0.7, 0.72), 0.4, 0.8), Vector3(7.0, 1.7, -3.5))
	_add(self, _box(Vector3(1.1, 0.65, 0.02)), _emissive(Color(1.0, 0.5, 0.15), 1.6), Vector3(7.58, 3.4, -3.5))
	_jeep(Vector3(-3.6, -0.3, -6.0), 40.0)


func _tree(pos: Vector3, s: float) -> void:
	var t := Node3D.new()
	t.position = pos
	t.scale = Vector3.ONE * s
	add_child(t)
	_add(t, _cyl(0.1, 0.16, 1.2, 8), trunk_mat, Vector3(0, 0.6, 0))
	_add(t, _cyl(0.0, 0.95, 1.5, 8), leaf_mat, Vector3(0, 1.7, 0))
	_add(t, _cyl(0.0, 0.75, 1.3, 8), leaf_mat2, Vector3(0, 2.5, 0))
	_add(t, _cyl(0.0, 0.5, 1.1, 8), leaf_mat, Vector3(0, 3.2, 0))


func _jeep(pos: Vector3, yaw: float) -> void:
	var j := Node3D.new()
	j.position = pos
	j.rotation_degrees.y = yaw
	add_child(j)
	var body := _mat(Color(0.25, 0.3, 0.2), 0.7, 0.2)
	var dark := _mat(Color(0.08, 0.08, 0.09), 0.9)
	_add(j, _box(Vector3(2.4, 0.55, 1.2)), body, Vector3(0, 0.65, 0))
	_add(j, _box(Vector3(1.1, 0.5, 1.1)), body, Vector3(-0.25, 1.15, 0))
	_add(j, _box(Vector3(0.05, 0.38, 0.95)), _mat(Color(0.5, 0.65, 0.8), 0.1, 0.6), Vector3(0.32, 1.17, 0))
	for sx in [-0.85, 0.85]:
		for sz in [-0.62, 0.62]:
			_add(j, _cyl(0.36, 0.36, 0.24, 16), dark, Vector3(sx, 0.36, sz), Vector3(90, 0, 0))
	var lamp := _emissive(Color(1.0, 0.9, 0.6), 2.0)
	for sz in [-0.4, 0.4]:
		_add(j, _box(Vector3(0.04, 0.14, 0.2)), lamp, Vector3(1.21, 0.72, sz))


func _build_particles() -> void:
	var p := CPUParticles3D.new()
	p.amount = 60
	p.lifetime = 7.0
	p.preprocess = 7.0
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = Vector3(7.0, 0.2, 5.0)
	p.position = Vector3(0, 0.2, -1.0)
	p.direction = Vector3(0, 1, 0)
	p.spread = 25.0
	p.gravity = Vector3(0.15, 0.0, 0.0)
	p.initial_velocity_min = 0.25
	p.initial_velocity_max = 0.7
	p.scale_amount_min = 0.5
	p.scale_amount_max = 1.5
	var m := SphereMesh.new()
	m.radius = 0.018
	m.height = 0.036
	m.radial_segments = 6
	m.rings = 3
	m.material = _emissive(Color(1.0, 0.75, 0.4), 3.0)
	p.mesh = m
	add_child(p)


func _build_camera() -> void:
	camera = Camera3D.new()
	camera.fov = CAM_FOV
	camera.near = 0.1
	camera.far = 400.0
	camera.position = CAM_POS + Vector3(0.0, -0.25, 1.6)   # starts closer and lower, then glides in
	camera.rotation_degrees = Vector3(CAM_PITCH, 0.0, 0.0)
	camera.current = true
	add_child(camera)
	var tw := create_tween()
	tw.tween_property(camera, "position", CAM_POS, 1.4).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)


# --------------------------------------------------------------------------- the soldier

func _build_hero() -> void:
	mats["shirt"] = _mat(Color.WHITE, 0.85)
	mats["pants"] = _mat(Color.WHITE, 0.9)
	mats["vest"] = _mat(Color.WHITE, 0.7, 0.1)
	mats["skin"] = _mat(Color(0.86, 0.66, 0.52), 0.6)
	mats["dark"] = _mat(Color(0.07, 0.07, 0.08), 0.8)
	goggles_mat = _emissive(Color.WHITE, 1.6)
	var shirt: StandardMaterial3D = mats["shirt"]
	var pants: StandardMaterial3D = mats["pants"]
	var vest: StandardMaterial3D = mats["vest"]
	var skin: StandardMaterial3D = mats["skin"]
	var dark: StandardMaterial3D = mats["dark"]

	hero = Node3D.new()
	hero.name = "Hero"
	hero.rotation.y = BASE_YAW
	add_child(hero)

	# Legs (the soldier faces -Z in its own space)
	for sx in [-1.0, 1.0]:
		var x: float = 0.12 * sx
		_add(hero, _box(Vector3(0.19, 0.42, 0.22)), pants, Vector3(x, 0.66, 0))
		_add(hero, _box(Vector3(0.16, 0.38, 0.19)), pants, Vector3(x * 1.1, 0.28, 0))
		_add(hero, _box(Vector3(0.12, 0.1, 0.05)), vest, Vector3(x * 1.05, 0.5, -0.12))
		_add(hero, _box(Vector3(0.19, 0.12, 0.34)), dark, Vector3(x * 1.1, 0.06, -0.04))

	# Hips and belt
	_add(hero, _box(Vector3(0.42, 0.16, 0.26)), pants, Vector3(0, 0.9, 0))
	_add(hero, _box(Vector3(0.44, 0.05, 0.28)), dark, Vector3(0, 0.96, 0))
	_add(hero, _box(Vector3(0.1, 0.13, 0.08)), vest, Vector3(0.26, 0.86, -0.02))
	_add(hero, _box(Vector3(0.1, 0.13, 0.08)), vest, Vector3(-0.26, 0.86, -0.02))

	# Upper body pivot (breathing animates this)
	chest = Node3D.new()
	chest.position = Vector3(0, CHEST_Y, 0)
	hero.add_child(chest)
	_add(chest, _box(Vector3(0.42, 0.46, 0.25)), shirt, Vector3.ZERO)
	_add(chest, _box(Vector3(0.46, 0.38, 0.29)), vest, Vector3(0, 0.03, 0))
	for px in [-0.13, 0.0, 0.13]:
		_add(chest, _box(Vector3(0.11, 0.1, 0.06)), dark, Vector3(px, -0.06, -0.17))
	for sx in [-1.0, 1.0]:
		_add(chest, _box(Vector3(0.12, 0.05, 0.3)), vest, Vector3(0.16 * sx, 0.23, 0))
	# Backpack
	_add(chest, _box(Vector3(0.36, 0.46, 0.18)), vest, Vector3(0, 0.0, 0.23))
	_add(chest, _box(Vector3(0.3, 0.16, 0.12)), shirt, Vector3(0, -0.12, 0.35))
	_add(chest, _cyl(0.08, 0.08, 0.4, 12), dark, Vector3(0, 0.3, 0.25), Vector3(0, 0, 90))

	# Neck and head
	_add(chest, _cyl(0.05, 0.06, 0.08, 10), skin, Vector3(0, 0.27, 0))
	head = Node3D.new()
	head.position = Vector3(0, 0.42, 0)
	chest.add_child(head)
	_add(head, _sphere(0.115, 1.1), skin)
	_add(head, _sphere(0.15, 0.7), vest, Vector3(0, 0.07, 0))          # helmet
	_add(head, _cyl(0.122, 0.122, 0.035, 20), dark, Vector3(0, 0.015, 0))   # head strap
	_add(head, _box(Vector3(0.21, 0.05, 0.05)), goggles_mat, Vector3(0, 0.015, -0.105))
	_add(head, _box(Vector3(0.17, 0.07, 0.07)), dark, Vector3(0, -0.06, -0.085))   # face mask

	# Weapons (reuses the first-person models) and arms that hold them
	for path in WeaponManager.DEFAULT_WEAPONS:
		weapons.append(load(path) as WeaponData)
	gun_mount = Node3D.new()
	gun_mount.name = "GunMount"
	chest.add_child(gun_mount)
	var built := WeaponViewModels.build(gun_mount, weapons)
	guns.assign(built["guns"])


func _rebuild_arms() -> void:
	if arms_root:
		arms_root.queue_free()
	arms_root = Node3D.new()
	chest.add_child(arms_root)
	var hold: Dictionary = hold_for(weapons[current_weapon].model)
	_arm(1.0, gun_mount.transform * (hold["r"] as Vector3))
	_arm(-1.0, gun_mount.transform * (hold["l"] as Vector3))


func _arm(side: float, hand: Vector3) -> void:
	var shirt: StandardMaterial3D = mats["shirt"]
	var dark: StandardMaterial3D = mats["dark"]
	var shoulder := Vector3(0.26 * side, 0.18, 0.0)
	var elbow := (shoulder + hand) * 0.5 + Vector3(0.09 * side, -0.14, 0.1)
	_add(arms_root, _sphere(0.075), shirt, shoulder)
	_limb(arms_root, shoulder, elbow, 0.12, shirt)
	_limb(arms_root, elbow, hand, 0.095, shirt)
	_add(arms_root, _box(Vector3(0.1, 0.1, 0.13)), dark, hand)
