class_name BulletBar
extends Control
## Progress bar drawn as a bullet flying along a track, leaving a glowing trail behind it.
## Set `value` from 0 to 1.

const BULLET_LEN := 64.0
const BULLET_H := 20.0
const TIP_LEN := 22.0         # length of the pointed part
const TRACK_H := 8.0
const BRASS := Color(0.86, 0.66, 0.26)
const BRASS_DARK := Color(0.62, 0.44, 0.14)
const COPPER := Color(0.78, 0.4, 0.22)
const TRAIL := Color(1.0, 0.6, 0.15)

var value := 0.0:
	set(v):
		value = clampf(v, 0.0, 1.0)
		queue_redraw()


func _init() -> void:
	custom_minimum_size = Vector2(520, BULLET_H + 8.0)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _draw() -> void:
	var cy := size.y * 0.5
	var tip_x := lerpf(BULLET_LEN, size.x, value)   # the tip reaches the end at 100%
	var tail_x := tip_x - BULLET_LEN

	# Track
	_pill(Vector2(0.0, cy - TRACK_H * 0.5), Vector2(size.x, TRACK_H), Color(1, 1, 1, 0.10))

	# Trail behind the bullet: bright near it, fading towards the start
	var trail_w := maxf(0.0, tail_x)
	if trail_w > 1.0:
		var steps := 24
		for i in steps:
			var x0 := trail_w * float(i) / steps
			var x1 := trail_w * float(i + 1) / steps
			var a := lerpf(0.05, 0.95, float(i + 1) / steps)
			draw_rect(Rect2(x0, cy - TRACK_H * 0.5, x1 - x0 + 1.0, TRACK_H), Color(TRAIL.r, TRAIL.g, TRAIL.b, a))

	_draw_bullet(tail_x, tip_x, cy)


func _draw_bullet(tail_x: float, tip_x: float, cy: float) -> void:
	var half := BULLET_H * 0.5
	var shoulder_x := tip_x - TIP_LEN

	# Glow
	draw_circle(Vector2(shoulder_x, cy), BULLET_H * 1.1, Color(TRAIL.r, TRAIL.g, TRAIL.b, 0.12))

	# Brass case with a rim at the back
	draw_rect(Rect2(tail_x + 4.0, cy - half + 1.0, shoulder_x - tail_x - 4.0, BULLET_H - 2.0), BRASS)
	draw_rect(Rect2(tail_x + 4.0, cy + half * 0.25, shoulder_x - tail_x - 4.0, half * 0.75 - 1.0), BRASS_DARK)
	draw_rect(Rect2(tail_x, cy - half, 4.0, BULLET_H), BRASS_DARK)
	draw_line(Vector2(tail_x + 9.0, cy - half + 1.0), Vector2(tail_x + 9.0, cy + half - 1.0), BRASS_DARK, 1.5)

	# Copper tip: a rounded point (ogive)
	var pts := PackedVector2Array()
	var n := 10
	for i in n + 1:
		var t := float(i) / n
		var x := shoulder_x + TIP_LEN * t
		var h := (half - 1.0) * sqrt(maxf(0.0, 1.0 - t * t))   # circular profile
		pts.append(Vector2(x, cy - h))
	for i in range(n, -1, -1):
		var t := float(i) / n
		var x := shoulder_x + TIP_LEN * t
		var h := (half - 1.0) * sqrt(maxf(0.0, 1.0 - t * t))
		pts.append(Vector2(x, cy + h))
	draw_colored_polygon(pts, COPPER)

	# Highlight along the top
	draw_line(Vector2(tail_x + 6.0, cy - half + 3.0), Vector2(shoulder_x + TIP_LEN * 0.45, cy - half + 3.0), Color(1, 1, 1, 0.35), 1.5)


func _pill(pos: Vector2, sz: Vector2, color: Color) -> void:
	var box := StyleBoxFlat.new()
	box.bg_color = color
	box.set_corner_radius_all(int(sz.y * 0.5))
	draw_style_box(box, Rect2(pos, sz))
