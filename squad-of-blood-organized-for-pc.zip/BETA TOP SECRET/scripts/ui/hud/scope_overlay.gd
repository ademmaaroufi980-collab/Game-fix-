extends Control
## Sniper scope: black outside a circle, thin crosshair inside.

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)


func _draw() -> void:
	var c := size / 2.0
	var r := size.y * 0.46
	var outer := size.length() * 0.6
	draw_arc(c, (r + outer) / 2.0, 0.0, TAU, 256, Color.BLACK, outer - r + 2.0)
	draw_arc(c, r, 0.0, TAU, 128, Color.BLACK, 3.0)
	var lc := Color(0, 0, 0, 0.9)
	draw_line(c - Vector2(r, 0), c + Vector2(r, 0), lc, 1.5)
	draw_line(c - Vector2(0, r), c + Vector2(0, r), lc, 1.5)
	draw_circle(c, 2.5, Color(1, 0.15, 0.1, 0.9))
