class_name GameUI
extends CanvasLayer
## HUD (dynamic crosshair, hitmarker, ammo, stamina, dash, score, scope) and pause menu.

const UIStyle = preload("res://scripts/ui/theme/ui_style.gd")
const ScopeOverlay = preload("res://scripts/ui/hud/scope_overlay.gd")
const MENU_SCENE := "res://scenes/main_menu.tscn"
const CROSS_LEN := 7.0
const COMBO_TIME := 4.0   # seconds to land the next kill and keep the streak
const COMBO_MAX := 5      # highest score multiplier

var player: Player
var wm: WeaponManager

var pause_panel: Control
var pause_box: Control
var settings_menu: SettingsMenu
var fps_label: Label
var last_fps := -1
var resume_button: Button

var cross_root: Control
var cross_rects: Array[ColorRect] = []
var cross_gap := 6.0
var cross_target := 6.0
var hit_marks: Array[ColorRect] = []
var hit_tween: Tween
var scope: Control

var score := 0
var score_label: Label
var best_label: Label
var time_label: Label
var stats := SessionStats.new()
var stats_label: Label
var time_left := Game.TIME_LIMIT
var run_paid := false   # coins for this run were already paid out
var round_over := false
var results_panel: Control
var results_label: Label
var results_title: Label
var round_label: Label
var targets_label: Label
var banner_title: Label
var banner_sub: Label
var banner_tween: Tween
var combo_label: Label
var combo := 0
var combo_timer := 0.0
var rounds: RoundManager
var touch: TouchControls
var hint_move: Label
var hint_combat: Label
var br_box: VBoxContainer
var bl_box: VBoxContainer
var stamina_title: Label
var dash_title: Label
var again_button: Button
var weapon_label: Label
var ammo_label: Label
var reload_label: Label
var msg_label: Label
var msg_tween: Tween
var health_label: Label
var health_bar: ProgressBar
var damage_flash: ColorRect
var damage_tween: Tween
var stamina_bar: ProgressBar
var dash_bar: ProgressBar


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 10
	add_to_group("hud")
	_build_scope()
	_build_crosshair()
	_build_hud()
	_build_pause_menu()
	_build_results_panel()
	_set_paused(false)
	time_label.visible = Game.timed or Game.rounds
	round_label.visible = Game.rounds
	targets_label.visible = Game.rounds

	player = get_tree().get_first_node_in_group("player") as Player
	if player:
		player.damaged.connect(_on_player_damaged)
		player.died.connect(_on_player_died)
	wm = get_tree().get_first_node_in_group("weapon_manager") as WeaponManager
	if wm:
		wm.weapon_changed.connect(set_weapon)
		wm.hit_confirmed.connect(_on_hit_confirmed)
		wm.shot_fired.connect(func() -> void: stats.shots += 1)
		wm.message.connect(show_message)

	if Game.rounds:
		rounds = RoundManager.new()
		rounds.name = "Rounds"
		rounds.ui = self
		rounds.process_mode = Node.PROCESS_MODE_PAUSABLE   # this HUD runs while paused; the rounds must not
		add_child(rounds)

	Settings.changed.connect(_on_settings_changed)
	_on_settings_changed()


func _exit_tree() -> void:
	Game.submit(score)


func _process(delta: float) -> void:
	if Game.timed and not round_over and not get_tree().paused:
		time_left = maxf(0.0, time_left - delta)
		show_time(time_left)
		if time_left <= 0.0:
			_end_run("TIME UP")
	if combo > 0 and not get_tree().paused and not round_over:
		combo_timer -= delta
		if combo_timer <= 0.0:
			combo = 0
			_refresh_combo()
		else:
			combo_label.modulate.a = minf(1.0, combo_timer)   # fades out over the last second
	# Continuous values are read from the game objects; events arrive through signals.
	if wm:
		var scoped := wm.is_scoped()
		set_crosshair(wm.crosshair_gap_px(), not scoped and (player == null or player.cam_back < 1.0))
		set_scope(scoped)
	if player:
		set_stamina(player.stamina_fraction(), player.sprint_locked)
		health_bar.value = player.health_fraction()
		health_label.text = "HEALTH  %d" % ceili(player.health)
		set_dash(player.dash_fraction())

	fps_label.visible = Settings.show_fps
	var fps := Engine.get_frames_per_second()
	if fps != last_fps:
		last_fps = fps
		fps_label.text = "%d FPS" % fps
	cross_gap = lerpf(cross_gap, cross_target, 1.0 - exp(-18.0 * delta))
	var g := cross_gap
	var L := CROSS_LEN
	cross_rects[0].position = Vector2(-1, -g - L)
	cross_rects[1].position = Vector2(-1, g)
	cross_rects[2].position = Vector2(-g - L, -1)
	cross_rects[3].position = Vector2(g, -1)


func _unhandled_input(event: InputEvent) -> void:
	if round_over:
		return
	if event.is_action_pressed("ui_cancel"):
		if settings_menu.visible:
			settings_menu.close()   # Esc inside settings goes back to the pause menu
		else:
			_set_paused(not get_tree().paused)
		get_viewport().set_input_as_handled()


# Pause automatically when the window loses focus so the game doesn't keep running.
func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		if pause_panel and not get_tree().paused and not round_over:
			_set_paused(true)
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:   # Android back button
		if pause_panel and not get_tree().paused and not round_over:
			_set_paused(true)


# ---------------------------------------------------------------- public API (called by game code)

## Pauses the game (touch pause button).
func pause() -> void:
	if not round_over and not get_tree().paused:
		_set_paused(true)


func _on_player_damaged(_amount: float) -> void:
	if damage_tween:
		damage_tween.kill()
	damage_flash.modulate.a = 1.0
	damage_tween = create_tween()
	damage_tween.tween_property(damage_flash, "modulate:a", 0.0, 0.5)


func _on_player_died() -> void:
	if not round_over:
		var z := get_tree().get_first_node_in_group("br_zone")
		if z != null and Time.get_ticks_msec() - int(z.get("last_player_hit")) < 700:
			_end_run("YOU DIED", "Caught outside the safe zone")
		else:
			_end_run("YOU DIED", "Shot down by an enemy")


func _on_settings_changed() -> void:
	_layout_hud()
	_refresh_hints()
	_sync_touch()


## Creates or removes the on-screen controls to match the chosen control scheme.
func _sync_touch() -> void:
	var want := Settings.use_touch()
	if want and touch == null:
		touch = TouchControls.new()
		touch.name = "Touch"
		touch.ui = self
		touch.player = player
		touch.wm = wm
		touch.process_mode = Node.PROCESS_MODE_PAUSABLE   # idle while paused
		touch.visible = not get_tree().paused
		add_child(touch)
	elif not want and touch != null:
		touch.release_all()
		touch.queue_free()
		touch = null


func _touch_paused(p: bool) -> void:
	if touch:
		touch.visible = not p
		if p:
			touch.release_all()


## Moves the ammo and stamina blocks to the top when touch buttons need the bottom corners.
func _layout_hud() -> void:
	var t := Settings.use_touch()
	var a := 0.0 if t else 1.0
	br_box.anchor_top = a
	br_box.anchor_bottom = a
	br_box.offset_top = 12.0 if t else -130.0
	br_box.offset_bottom = 122.0 if t else -20.0
	bl_box.anchor_top = a
	bl_box.anchor_bottom = a
	bl_box.offset_top = 40.0 if t else -140.0
	bl_box.offset_bottom = 160.0 if t else -20.0


func _refresh_hints() -> void:
	hint_move.text = UIStyle.controls_move()
	hint_combat.text = UIStyle.controls_combat()
	var t := Settings.use_touch()
	stamina_title.text = "STAMINA" if t else "STAMINA  (Shift)"
	dash_title.text = "DASH" if t else "DASH  (Q)"


## Updates the timer label (timed mode and round mode).
func show_time(seconds: float) -> void:
	time_label.text = "TIME  %d" % ceili(seconds)
	time_label.add_theme_color_override("font_color", Color(1, 0.35, 0.3) if seconds <= 10.0 else Color.WHITE)


func set_round_info(round_no: int, alive: int, total: int) -> void:
	round_label.text = "ROUND  %d" % round_no
	targets_label.text = "TARGETS  %d / %d" % [total - alive, total]


## Big centred text (round start, round cleared, ...).
func show_banner(title: String, sub: String = "", seconds := 2.0) -> void:
	banner_title.text = title
	banner_sub.text = sub
	banner_title.modulate.a = 1.0
	banner_sub.modulate.a = 1.0
	if banner_tween:
		banner_tween.kill()
	banner_tween = create_tween()
	banner_tween.tween_interval(seconds)
	banner_tween.tween_property(banner_title, "modulate:a", 0.0, 0.4)
	banner_tween.parallel().tween_property(banner_sub, "modulate:a", 0.0, 0.4)


func combo_multiplier() -> int:
	return 1 + mini(combo, COMBO_MAX - 1)


func _refresh_combo() -> void:
	combo_label.visible = combo > 0
	combo_label.modulate.a = 1.0
	combo_label.text = "STREAK %d  ·  x%d" % [combo, combo_multiplier()]


func set_crosshair(gap_px: float, show: bool) -> void:
	cross_target = clampf(gap_px, 4.0, 90.0)
	cross_root.visible = show


func set_scope(on: bool) -> void:
	scope.visible = on


func set_weapon(weapon_name: String, mag: int, reserve: int, reloading: bool) -> void:
	weapon_label.text = weapon_name
	ammo_label.text = "%d / %d" % [mag, reserve]
	ammo_label.add_theme_color_override("font_color", Color(1, 0.3, 0.25) if mag == 0 else Color.WHITE)
	reload_label.visible = reloading


func set_stamina(f: float, locked: bool) -> void:
	stamina_bar.value = f
	stamina_bar.modulate = Color(1, 0.4, 0.4) if locked else Color.WHITE


func set_dash(f: float) -> void:
	dash_bar.value = f
	dash_bar.modulate = Color(1, 0.75, 0.3) if f >= 1.0 else Color(0.7, 0.7, 0.7)


func _on_hit_confirmed(points: int, head: bool, kill: bool) -> void:
	stats.hits += 1
	if head:
		stats.headshots += 1
	var mult := combo_multiplier()   # the streak you had BEFORE this hit
	if kill:
		stats.kills += 1
		combo += 1
		combo_timer = COMBO_TIME
		stats.best_streak = maxi(stats.best_streak, combo)
		_refresh_combo()
	hitmarker(kill)
	var text := "HEADSHOT" if head else ("KILL" if kill else "")
	if mult > 1:
		text = ("%s  x%d" % [text, mult]).strip_edges()
	add_score(points * mult, text)


func hitmarker(kill: bool) -> void:
	for h in hit_marks:
		h.color = Color(1, 0.2, 0.2) if kill else Color.WHITE
		h.modulate.a = 1.0
	if hit_tween:
		hit_tween.kill()
	hit_tween = create_tween()
	hit_tween.tween_interval(0.05)
	for h in hit_marks:
		hit_tween.parallel().tween_property(h, "modulate:a", 0.0, 0.2)


func add_score(points: int, text: String) -> void:
	if points <= 0:
		return
	score += points
	score_label.text = "SCORE  %d" % score
	best_label.text = "BEST  %d" % maxi(score, Game.best_score())
	var l := UIStyle.label("+%d %s" % [points, text], 22, Color(1, 0.85, 0.4) if text != "" else Color.WHITE)
	l.position = get_viewport().get_visible_rect().size / 2.0 + Vector2(30, -50)
	add_child(l)
	var tw := l.create_tween()
	tw.tween_property(l, "position:y", l.position.y - 50.0, 0.8)
	tw.parallel().tween_property(l, "modulate:a", 0.0, 0.8)
	tw.tween_callback(l.queue_free)


func show_message(text: String, seconds := 1.5) -> void:
	msg_label.text = text
	msg_label.modulate.a = 1.0
	if msg_tween:
		msg_tween.kill()
	msg_tween = create_tween()
	msg_tween.tween_interval(seconds)
	msg_tween.tween_property(msg_label, "modulate:a", 0.0, 0.4)


# ---------------------------------------------------------------- building

func _build_scope() -> void:
	scope = ScopeOverlay.new()
	scope.visible = false
	add_child(scope)


func _build_crosshair() -> void:
	cross_root = Control.new()
	cross_root.set_anchors_preset(Control.PRESET_CENTER)
	cross_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(cross_root)
	var sizes := [Vector2(2, CROSS_LEN), Vector2(2, CROSS_LEN), Vector2(CROSS_LEN, 2), Vector2(CROSS_LEN, 2)]
	for s in sizes:
		var cr := ColorRect.new()
		cr.color = Color(1, 1, 1, 0.9)
		cr.size = s
		cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		cross_root.add_child(cr)
		cross_rects.append(cr)
	# Hitmarker: two crossed bars
	for ang in [PI / 4.0, -PI / 4.0]:
		var h := ColorRect.new()
		h.size = Vector2(18, 2)
		h.position = Vector2(-9, -1)
		h.pivot_offset = Vector2(9, 1)
		h.rotation = ang
		h.modulate.a = 0.0
		h.mouse_filter = Control.MOUSE_FILTER_IGNORE
		cross_root.add_child(h)
		hit_marks.append(h)


func _anchored_box(a_x: float, a_y: float, left: float, top: float, right: float, bottom: float) -> VBoxContainer:
	var box := VBoxContainer.new()
	box.anchor_left = a_x
	box.anchor_right = a_x
	box.anchor_top = a_y
	box.anchor_bottom = a_y
	box.offset_left = left
	box.offset_top = top
	box.offset_right = right
	box.offset_bottom = bottom
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(box)
	return box


func _bar(color: Color, height: float) -> ProgressBar:
	var b := ProgressBar.new()
	b.min_value = 0.0
	b.max_value = 1.0
	b.step = 0.001
	b.value = 1.0
	b.show_percentage = false
	b.custom_minimum_size = Vector2(240, height)
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0, 0, 0, 0.5)
	bg.set_corner_radius_all(4)
	var fill := StyleBoxFlat.new()
	fill.bg_color = color
	fill.set_corner_radius_all(4)
	b.add_theme_stylebox_override("background", bg)
	b.add_theme_stylebox_override("fill", fill)
	return b


func _build_hud() -> void:
	# Red flash over the whole screen when you get hit
	damage_flash = ColorRect.new()
	damage_flash.color = Color(0.8, 0.0, 0.0, 0.35)
	damage_flash.set_anchors_preset(Control.PRESET_FULL_RECT)
	damage_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	damage_flash.modulate.a = 0.0
	add_child(damage_flash)

	fps_label = UIStyle.label("", 16, Color(1, 1, 1, 0.7))
	fps_label.position = Vector2(12, 8)
	add_child(fps_label)

	# Score (top centre)
	var top := _anchored_box(0.5, 0.0, -200, 12, 200, 60)
	score_label = UIStyle.label("SCORE  0", 30, Color(1, 0.85, 0.5))
	top.add_child(score_label)
	best_label = UIStyle.label("BEST  %d" % Game.best_score(), 18, Color(1, 1, 1, 0.7))
	top.add_child(best_label)
	time_label = UIStyle.label("TIME  %d" % int(Game.TIME_LIMIT), 26, Color.WHITE)
	top.add_child(time_label)
	round_label = UIStyle.label("ROUND  0", 24, Color(0.6, 0.9, 1.0))
	top.add_child(round_label)
	targets_label = UIStyle.label("TARGETS  0 / 0", 18, Color(1, 1, 1, 0.8))
	top.add_child(targets_label)

	# Weapon + ammo (bottom right)
	br_box = _anchored_box(1.0, 1.0, -320, -130, -24, -20)
	weapon_label = UIStyle.label("", 22, Color(1, 0.85, 0.5))
	weapon_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	ammo_label = UIStyle.label("", 54)
	ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	br_box.add_child(weapon_label)
	br_box.add_child(ammo_label)

	# Kill streak (bottom centre)
	var cb := _anchored_box(0.5, 1.0, -200, -80, 200, -20)
	combo_label = UIStyle.label("", 28, Color(1, 0.6, 0.2))
	combo_label.visible = false
	cb.add_child(combo_label)

	# Round banner (upper centre)
	var bn := _anchored_box(0.5, 0.22, -400, 0, 400, 140)
	banner_title = UIStyle.label("", 64, Color(1, 0.85, 0.5))
	banner_title.modulate.a = 0.0
	bn.add_child(banner_title)
	banner_sub = UIStyle.label("", 26, Color(0.9, 0.95, 1.0))
	banner_sub.modulate.a = 0.0
	bn.add_child(banner_sub)

	# Stamina + dash (bottom left)
	bl_box = _anchored_box(0.0, 1.0, 24, -140, 280, -20)
	var hl := UIStyle.label("HEALTH  100", 14, Color(1, 1, 1, 0.8))
	hl.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	bl_box.add_child(hl)
	health_label = hl
	health_bar = _bar(Color(0.9, 0.2, 0.2), 14)
	bl_box.add_child(health_bar)
	var sl := UIStyle.label("STAMINA  (Shift)", 14, Color(1, 1, 1, 0.8))
	sl.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	bl_box.add_child(sl)
	stamina_title = sl
	stamina_bar = _bar(Color(0.3, 0.8, 0.4), 14)
	bl_box.add_child(stamina_bar)
	var dl := UIStyle.label("DASH  (Q)", 14, Color(1, 1, 1, 0.8))
	dl.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	bl_box.add_child(dl)
	dash_title = dl
	dash_bar = _bar(Color(1, 0.65, 0.2), 10)
	bl_box.add_child(dash_bar)

	# Status text under the crosshair
	reload_label = UIStyle.label("RELOADING", 24, Color(1, 0.85, 0.5))
	reload_label.visible = false
	var mid := _anchored_box(0.5, 0.5, -200, 70, 200, 130)
	mid.add_child(reload_label)
	msg_label = UIStyle.label("", 22, Color(0.6, 1, 0.6))
	msg_label.modulate.a = 0.0
	mid.add_child(msg_label)

	fps_label.z_index = 1


func _build_pause_menu() -> void:
	pause_panel = Control.new()
	pause_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	pause_panel.theme = UIStyle.make_theme()
	add_child(pause_panel)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.5)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	pause_panel.add_child(dim)

	# Dark band on the left, behind the menu
	var grad := Gradient.new()
	grad.colors = PackedColorArray([Color(0.02, 0.03, 0.06, 0.92), Color(0.02, 0.03, 0.06, 0.6), Color(0, 0, 0, 0)])
	grad.offsets = PackedFloat32Array([0.0, 0.4, 0.75])
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(1, 0)
	var band := TextureRect.new()
	band.texture = gt
	band.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	band.stretch_mode = TextureRect.STRETCH_SCALE
	band.mouse_filter = Control.MOUSE_FILTER_IGNORE
	band.set_anchors_preset(Control.PRESET_FULL_RECT)
	pause_panel.add_child(band)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	pause_panel.add_child(center)

	# Left-aligned vertical menu (FPS style)
	var left := MarginContainer.new()
	left.set_anchors_preset(Control.PRESET_FULL_RECT)
	left.add_theme_constant_override("margin_left", 70)
	left.add_theme_constant_override("margin_right", 40)
	left.add_theme_constant_override("margin_top", 40)
	left.add_theme_constant_override("margin_bottom", 40)
	pause_panel.add_child(left)
	pause_box = left
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	box.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	box.add_theme_constant_override("separation", 10)
	left.add_child(box)

	var title := UIStyle.title("PAUSED", 64)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	box.add_child(title)
	box.add_child(UIStyle.accent_line(160.0, 5.0))
	stats_label = UIStyle.label("", 20, Color(1, 0.9, 0.7))
	stats_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	box.add_child(stats_label)
	box.add_child(UIStyle.spacer(false, false, Vector2(0, 10)))
	resume_button = UIStyle.accent_button("RESUME", func(): _set_paused(false), Vector2(380, 68), 28)
	box.add_child(resume_button)
	box.add_child(UIStyle.nav_button("SETTINGS", _open_settings))
	box.add_child(UIStyle.nav_button("LOBBY", _to_menu))
	box.add_child(UIStyle.nav_button("QUIT", func(): get_tree().quit()))
	box.add_child(UIStyle.spacer(false, false, Vector2(0, 14)))
	hint_move = UIStyle.label(UIStyle.controls_move(), 14, Color(0.75, 0.8, 0.9))
	hint_move.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	hint_move.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint_move.custom_minimum_size = Vector2(380, 0)
	box.add_child(hint_move)
	hint_combat = UIStyle.label(UIStyle.controls_combat(), 14, Color(0.75, 0.8, 0.9))
	hint_combat.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	hint_combat.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint_combat.custom_minimum_size = Vector2(380, 0)
	box.add_child(hint_combat)

	settings_menu = SettingsMenu.new()
	settings_menu.visible = false
	settings_menu.closed.connect(_close_settings)
	center.add_child(settings_menu)


func _open_settings() -> void:
	pause_box.visible = false
	settings_menu.visible = true
	settings_menu.focus_first()


func _close_settings() -> void:
	settings_menu.visible = false
	pause_box.visible = true
	resume_button.grab_focus()


func _build_results_panel() -> void:
	results_panel = Control.new()
	results_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	results_panel.visible = false
	results_panel.theme = UIStyle.make_theme()
	add_child(results_panel)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.75)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	results_panel.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	results_panel.add_child(center)
	var card := UIStyle.panel(UIStyle.GLASS, 6, 32.0)
	center.add_child(card)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	card.add_child(box)
	results_title = UIStyle.title("TIME UP", 64)
	box.add_child(results_title)
	var rline := UIStyle.accent_line(140.0, 4.0)
	rline.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	box.add_child(rline)
	results_label = UIStyle.label("", 28)
	box.add_child(results_label)
	again_button = UIStyle.accent_button("PLAY AGAIN", _restart, Vector2(280, 62), 26)
	box.add_child(again_button)
	box.add_child(UIStyle.button("LOBBY", _to_menu))
	for b in box.get_children():
		if b is Button:
			b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER


## Ends the run and shows the results screen. `extra` is an optional line under the title.
func _end_run(title: String, extra := "") -> void:
	round_over = true
	var new_best := Game.submit(score)
	var earned := _pay_run()
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_touch_paused(true)
	pause_panel.visible = false
	results_title.text = title
	var lines := ["SCORE  %d%s" % [score, "   NEW BEST!" if new_best else ""]]
	lines.append("+%d COINS" % earned)
	if extra != "":
		lines.append(extra)
	lines.append(stats.summary())
	lines.append("BEST  %d" % Game.best_score())
	results_label.text = "\n".join(lines)
	results_panel.visible = true
	again_button.grab_focus()


## Called by the round manager when the run is over.
func end_run(title: String, extra := "") -> void:
	_end_run(title, extra)


## Pays the coins for this run once (end of run, restart or back to the lobby).
func _pay_run() -> int:
	if run_paid:
		return 0
	run_paid = true
	return Game.award_run(score)


func _restart() -> void:
	_pay_run()
	get_tree().paused = false
	Loading.go(get_tree().current_scene.scene_file_path)


func _set_paused(p: bool) -> void:
	get_tree().paused = p
	if p:
		Game.submit(score)
		stats_label.text = stats.summary()
	pause_panel.visible = p
	settings_menu.visible = false
	pause_box.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if p else Settings.gameplay_mouse_mode()
	_touch_paused(p)
	if p:
		resume_button.grab_focus()


func _to_menu() -> void:
	_pay_run()
	get_tree().paused = false
	get_tree().change_scene_to_file(MENU_SCENE)
