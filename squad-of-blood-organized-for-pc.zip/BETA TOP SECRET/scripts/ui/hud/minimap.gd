extends Control
## Minimap (top-right) shown in every mode. North is up.
##   Tap/click the minimap or press M to open the BIG MAP. On the big map: left click sets a
##   marker (where you want to land / go), right click removes it, M / Esc / X closes it.
## Normal modes: arena, hills, props, trees, enemies (red), ammo (green).
## Battle Royale: shaded terrain, houses, loot, the plane, the safe zone (blue = now, white = next) and
## enemies that are close to you. The small map follows you; the big map (M) shows the whole land.

const TerrainScript = preload("res://scripts/world/environment/terrain.gd")
const BrTerrain = preload("res://scripts/modes/battle_royale/map/br_terrain.gd")
const BrPlane = preload("res://scripts/modes/battle_royale/drop/br_plane.gd")

const SMALL := 190.0
const MARGIN := 14.0
const WORLD_HALF := 62.0       # half-size of the map area in normal modes (terrain is 60)
const BR_WORLD_HALF := 260.0   # BR: valley (200) plus a strip of mountains
const BR_VIEW_HALF := 110.0    # BR small map: how many metres you see around yourself
const BR_TEX := 168            # resolution of the pre-rendered BR terrain picture
const RADAR_RANGE := 55.0      # enemies closer than this show up as red blips

var player: Player
var plane: Node3D
var props: Array[Vector2] = []
var trees: Array[Vector2] = []
var pickups: Array[Node3D] = []
var half := WORLD_HALF
var sz := SMALL
var big := false
var has_marker := false
var marker := Vector2.ZERO
var vc := Vector2.ZERO         # world point at the centre of the map view
var vh := WORLD_HALF           # half-size of the world area the view shows
var br_tex: ImageTexture
var br_tried := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	half = BR_WORLD_HALF if Game.br else WORLD_HALF
	vh = half
	clip_contents = true
	_layout()
	_setup.call_deferred()


func _setup() -> void:
	player = get_tree().get_first_node_in_group("player") as Player
	var root := get_tree().current_scene
	if root == null:
		return
	plane = root.get_node_or_null("BrPlane") as Node3D
	if Game.br:
		return
	for n in root.get_children():
		if n is StaticBody3D and n.name != "Terrain":
			props.append(_flat((n as Node3D).global_position))
		elif n is AmmoPickup:
			pickups.append(n as Node3D)


## The Trees node fills in its tree spots a frame later, so read them when they are ready.
func _load_trees() -> void:
	for n in get_tree().get_nodes_in_group("trees"):
		var list: Variant = n.get("tree_spots")
		if list is Array:
			for v: Vector3 in list:
				trees.append(Vector2(v.x, v.z))


func _flat(p: Vector3) -> Vector2:
	return Vector2(p.x, p.z)


# --------------------------------------------------------------------------- layout / input

func _layout() -> void:
	if big:
		var vp := get_viewport_rect().size
		sz = clampf(minf(vp.x, vp.y) * 0.82, 300.0, 900.0)
		anchor_left = 0.5
		anchor_right = 0.5
		anchor_top = 0.5
		anchor_bottom = 0.5
		offset_left = -sz / 2.0
		offset_right = sz / 2.0
		offset_top = -sz / 2.0
		offset_bottom = sz / 2.0
		mouse_filter = Control.MOUSE_FILTER_STOP
	else:
		sz = SMALL
		var top := 135.0 if Settings.use_touch() else MARGIN   # touch HUD uses the top corners
		anchor_left = 1.0
		anchor_right = 1.0
		anchor_top = 0.0
		anchor_bottom = 0.0
		offset_left = -(SMALL + MARGIN)
		offset_right = -MARGIN
		offset_top = top
		offset_bottom = top + SMALL
		mouse_filter = Control.MOUSE_FILTER_PASS


func _set_big(on: bool) -> void:
	big = on
	_layout()
	if on:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	else:
		Input.mouse_mode = Settings.gameplay_mouse_mode()


func _input(event: InputEvent) -> void:
	if get_tree().paused:
		return
	var k := event as InputEventKey
	if k and k.pressed and not k.echo:
		if k.keycode == KEY_M:
			_set_big(not big)
			get_viewport().set_input_as_handled()
		elif k.keycode == KEY_ESCAPE and big:
			_set_big(false)
			get_viewport().set_input_as_handled()


func _gui_input(event: InputEvent) -> void:
	var e := event as InputEventMouseButton
	if e == null or not e.pressed:
		return
	if not big:
		if e.button_index == MOUSE_BUTTON_LEFT:
			_set_big(true)
			accept_event()
		return
	if e.button_index == MOUSE_BUTTON_LEFT:
		if Rect2(sz - 36.0, 6.0, 30.0, 30.0).has_point(e.position):
			_set_big(false)
		else:
			marker = _from_map(e.position)
			has_marker = true
	elif e.button_index == MOUSE_BUTTON_RIGHT:
		has_marker = false
	accept_event()


func _process(_delta: float) -> void:
	visible = not get_tree().paused
	if get_tree().paused:
		return
	if not Game.br and trees.is_empty() and Engine.get_process_frames() > 5:
		_load_trees()
	if Game.br:
		_update_br_view()
	queue_redraw()


func _update_br_view() -> void:
	if br_tex == null and not br_tried:
		_build_br_texture()
	if big or player == null or not is_instance_valid(player):
		vc = Vector2.ZERO
		vh = half
	else:
		vh = BR_VIEW_HALF
		var lim := half - vh
		vc = _flat(player.global_position).clamp(Vector2(-lim, -lim), Vector2(lim, lim))


## Renders the BR map once into a picture (grass, rock, snow by height, hill shading).
## The heights come from physics rays against the ground of the imported map, so this waits until the map exists.
var br_wait := 0

func _build_br_texture() -> void:
	var map := get_tree().current_scene.get_node_or_null("BattleRoyaleMap")
	if map == null:
		return
	br_wait += 1
	if br_wait < 8:
		return   # give the physics server a few frames to register the map collision
	br_tried = true
	var space := get_viewport().get_world_3d().direct_space_state
	var span := 2.0 * half
	var heights := PackedFloat32Array()
	heights.resize(BR_TEX * BR_TEX)
	for j in BR_TEX:
		for i in BR_TEX:
			var x := (float(i) + 0.5) / BR_TEX * span - half
			var z := (float(j) + 0.5) / BR_TEX * span - half
			heights[j * BR_TEX + i] = _map_height(space, x, z)
	var img := Image.create(BR_TEX, BR_TEX, false, Image.FORMAT_RGB8)
	for j in BR_TEX:
		for i in BR_TEX:
			var h := heights[j * BR_TEX + i]
			var hx0 := heights[j * BR_TEX + maxi(i - 1, 0)]
			var hx1 := heights[j * BR_TEX + mini(i + 1, BR_TEX - 1)]
			var hz0 := heights[maxi(j - 1, 0) * BR_TEX + i]
			var hz1 := heights[mini(j + 1, BR_TEX - 1) * BR_TEX + i]
			var c := _br_color(h)
			# Light from the north-west: slopes facing it are brighter
			var shade := clampf(1.0 + ((hx1 - hx0) + (hz1 - hz0)) * 0.05, 0.55, 1.35)
			img.set_pixel(i, j, Color(c.r * shade, c.g * shade, c.b * shade))
	br_tex = ImageTexture.create_from_image(img)


func _map_height(space: PhysicsDirectSpaceState3D, x: float, z: float) -> float:
	var q := PhysicsRayQueryParameters3D.create(Vector3(x, 300.0, z), Vector3(x, -20.0, z))
	q.collision_mask = Layers.TERRAIN
	q.collide_with_areas = false
	var hit := space.intersect_ray(q)
	if hit.is_empty():
		q.collision_mask = Layers.WORLD
		hit = space.intersect_ray(q)
	if hit.is_empty():
		return 0.0
	return float(hit.position.y)


func _br_color(h: float) -> Color:
	var grass := Color(0.30, 0.42, 0.22)
	var rock := Color(0.45, 0.42, 0.38)
	var snow := Color(0.92, 0.94, 0.97)
	if h < 3.0:
		return grass
	if h < 28.0:
		return grass.lerp(rock, (h - 3.0) / 25.0)
	return rock.lerp(snow, clampf((h - 28.0) / 45.0, 0.0, 1.0))


# --------------------------------------------------------------------------- drawing

## World (x, z) to a point inside the map, clamped to the border.
func _to_map(p: Vector2, clamp_it := true) -> Vector2:
	var q := Vector2(sz, sz) / 2.0 + (p - vc) * (sz / (2.0 * vh))
	if not clamp_it:
		return q
	return q.clamp(Vector2(4, 4), Vector2(sz - 4, sz - 4))


## Map point back to world (x, z).
func _from_map(q: Vector2) -> Vector2:
	var p := (q - Vector2(sz, sz) / 2.0) * (2.0 * half / sz)
	return p.clamp(Vector2(-half, -half), Vector2(half, half))


func _arrow(pos: Vector2, dir: Vector2, color: Color, length := 8.0) -> void:
	var k := sz / SMALL if big else 1.0
	length *= minf(k, 2.0)
	var perp := Vector2(-dir.y, dir.x)
	var pts := PackedVector2Array([pos + dir * length, pos - dir * (length * 0.5) + perp * (length * 0.55), pos - dir * (length * 0.5) - perp * (length * 0.55)])
	draw_colored_polygon(pts, color)
	draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[0]]), Color(0, 0, 0, 0.7), 1.0)


func _text(pos: Vector2, text: String, size: int, color := Color(1, 1, 1, 0.85)) -> void:
	draw_string_outline(ThemeDB.fallback_font, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, 4, Color(0, 0, 0, 0.8))
	draw_string(ThemeDB.fallback_font, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)


func _draw() -> void:
	var s := sz / (2.0 * vh)
	var box := Rect2(Vector2.ZERO, Vector2(sz, sz))
	var fs := 20 if big else 12
	draw_rect(box, Color(0.04, 0.06, 0.09, 0.78 if big else 0.62))

	if Game.br:
		_draw_br(s, fs, box)
	else:
		# Terrain bounds, flat arena, hills
		var t := TerrainScript.HALF as float
		draw_rect(Rect2(_to_map(Vector2(-t, -t)), Vector2(2 * t, 2 * t) * s), Color(0.2, 0.28, 0.2, 0.55))
		var a := TerrainScript.ARENA_HALF as float
		draw_rect(Rect2(_to_map(Vector2(-a, -a)), Vector2(2 * a, 2 * a) * s), Color(0.55, 0.6, 0.55, 0.22))
		for h: Vector4 in TerrainScript.HILLS:
			draw_circle(_to_map(Vector2(h.x, h.y)), h.z * s, Color(0.35, 0.3, 0.2, 0.5))
		var dot := 1.5 * (2.0 if big else 1.0)
		for p in trees:
			draw_circle(_to_map(p), dot, Color(0.1, 0.45, 0.15, 0.9))
		for p in props:
			draw_rect(Rect2(_to_map(p) - Vector2(dot, dot), Vector2(dot, dot) * 2.0), Color(0.7, 0.7, 0.72, 0.9))
		for n in get_tree().get_nodes_in_group("targets"):
			if n is Target and (n as Target).visible and not (n as Target).dead:
				draw_circle(_to_map(_flat((n as Target).global_position)), dot * 2.0, Color(0.95, 0.2, 0.2))
		for n in pickups:
			if is_instance_valid(n) and n.visible:
				draw_circle(_to_map(_flat(n.global_position)), dot * 1.7, Color(0.3, 0.9, 0.35))

	# Marker (line from you + pin + distance)
	var me := Vector2.ZERO
	if player and is_instance_valid(player):
		me = _flat(player.global_position)
	if has_marker:
		var mp := _to_map(marker)
		draw_line(_to_map(me), mp, Color(1, 0.85, 0.2, 0.6), 1.5)
		var r := 7.0 if big else 5.0
		draw_colored_polygon(PackedVector2Array([mp + Vector2(0, -r * 1.6), mp + Vector2(r, 0), mp + Vector2(0, r * 1.6), mp + Vector2(-r, 0)]), Color(1, 0.85, 0.2))
		_text(Vector2(6, sz - 8), "TARGET  %d m" % int(me.distance_to(marker)), fs, Color(1, 0.9, 0.4))

	# You (with a view cone in battle royale)
	if player and is_instance_valid(player):
		var dir := Vector2(-sin(player.yaw), -cos(player.yaw))
		if Game.br:
			var mpos := _to_map(me)
			var len_px := sz * 0.16
			var cone := PackedVector2Array([mpos, mpos + dir.rotated(-0.6) * len_px, mpos + dir * len_px * 1.05, mpos + dir.rotated(0.6) * len_px])
			draw_colored_polygon(cone, Color(0.4, 0.9, 1.0, 0.16))
		_arrow(_to_map(me), dir, Color(0.2, 0.85, 1.0))

	draw_rect(box, Color(1, 1, 1, 0.55), false, 2.0)
	if Game.br:
		_draw_br_frame()
	_text(Vector2(sz / 2.0 - 4.0, fs + 3.0), "N", fs)
	if big:
		draw_rect(Rect2(sz - 36.0, 6.0, 30.0, 30.0), Color(0, 0, 0, 0.55))
		_text(Vector2(sz - 29.0, 28.0), "X", 20, Color(1, 0.5, 0.4))
		_text(Vector2(10, 26), "MAP   click: marker   right click: clear   M / Esc: close", 14, Color(1, 1, 1, 0.8))
	else:
		_text(Vector2(sz - 16.0, sz - 6.0), "M", 11, Color(1, 1, 1, 0.55))


# --------------------------------------------------------------------------- battle royale map

func _draw_br(s: float, fs: int, box: Rect2) -> void:
	# Terrain picture (the part of the world that is in view)
	if br_tex != null:
		var tex := float(BR_TEX)
		var region := Rect2((vc - Vector2(vh, vh) + Vector2(half, half)) / (2.0 * half) * tex, Vector2(2.0 * vh, 2.0 * vh) / (2.0 * half) * tex)
		draw_texture_rect_region(br_tex, box, region)
	else:
		draw_rect(box, Color(0.3, 0.42, 0.24))
	draw_rect(box, Color(0.0, 0.03, 0.06, 0.18))   # slightly dark so the symbols stand out

	# Grid every 100 m
	var step := 100.0
	var g := -half
	while g <= half:
		if absf(g) <= 400.0:
			var a := _to_map(Vector2(g, -half), false)
			var b := _to_map(Vector2(g, half), false)
			draw_line(a, b, Color(1, 1, 1, 0.08), 1.0)
			a = _to_map(Vector2(-half, g), false)
			b = _to_map(Vector2(half, g), false)
			draw_line(a, b, Color(1, 1, 1, 0.08), 1.0)
		g += step

	# Flight path and plane
	var path := PackedVector2Array()
	var steps := 96
	for i in steps + 1:
		var pt: Vector2 = BrPlane.sample(BrPlane.lap_length() * i / steps)[0]
		path.append(_to_map(pt, false))
	draw_polyline(path, Color(1, 1, 1, 0.22), 1.2)
	if plane and is_instance_valid(plane):
		var fwd := -plane.global_basis.z
		_arrow(_to_map(_flat(plane.global_position), false), Vector2(fwd.x, fwd.z).normalized(), Color(0.97, 0.97, 0.97), 10.0)

	# Houses
	var hs := get_tree().current_scene.get_node_or_null("BrHouses") as BrHouses
	if hs:
		for i in hs.centers.size():
			var c := hs.centers[i]
			var hh := hs.halves[i]
			var r := Rect2(_to_map(c - hh, false), hh * 2.0 * s)
			draw_rect(r, Color(0.93, 0.8, 0.55))
			draw_rect(r, Color(0.15, 0.1, 0.05, 0.9), false, 1.0)

	# Loot
	var dot := 3.0 if big else 2.2
	for n in get_tree().get_nodes_in_group("loot"):
		var l := n as Loot
		if l == null:
			continue
		var col: Color = Loot.COLORS[l.kind]
		var lp := _to_map(_flat(l.global_position), false)
		draw_circle(lp, dot + 1.0, Color(0, 0, 0, 0.55))
		draw_circle(lp, dot, col)

	# Safe zone: danger shading outside the blue circle, the circle itself, the next circle in white
	var zone := get_tree().get_first_node_in_group("br_zone") as BrZone
	if zone != null and zone.is_active():
		var zc := _to_map(zone.center, false)
		var zr := zone.radius * s
		var n_seg := 96
		var far := zr + sz * 2.0
		for i in n_seg:
			var a0 := TAU * i / n_seg
			var a1 := TAU * (i + 1) / n_seg
			var d0 := Vector2(cos(a0), sin(a0))
			var d1 := Vector2(cos(a1), sin(a1))
			draw_colored_polygon(PackedVector2Array([zc + d0 * zr, zc + d1 * zr, zc + d1 * far, zc + d0 * far]), Color(0.75, 0.1, 0.12, 0.3))
		draw_arc(zc, zr, 0.0, TAU, 128, Color(0.3, 0.65, 1.0), 2.5 if big else 2.0)
		draw_arc(_to_map(zone.next_center, false), zone.next_radius * s, 0.0, TAU, 96, Color(1, 1, 1, 0.9), 1.5)

	# Enemies close to you (radar)
	if player and is_instance_valid(player):
		var me := _flat(player.global_position)
		for n in get_tree().get_nodes_in_group("targets"):
			var t := n as Target
			if t == null or t.dead or not t.visible or not t.is_physics_processing() or t.has_meta("air"):
				continue
			var tp := _flat(t.global_position)
			var d := tp.distance_to(me)
			if d > RADAR_RANGE:
				continue
			var a := clampf(1.0 - d / RADAR_RANGE, 0.0, 1.0) * 0.6 + 0.4
			var bp := _to_map(tp, false)
			draw_circle(bp, dot + 2.5, Color(1, 0.15, 0.1, 0.25 * a))
			draw_circle(bp, dot + 0.8, Color(1, 0.2, 0.15, a))

	# Zone info (bottom left)
	if zone != null and zone.is_active() and player and is_instance_valid(player):
		var me2 := _flat(player.global_position)
		var dist := me2.distance_to(zone.center) - zone.radius
		if dist > 0.0:
			_text(Vector2(8, sz - 8), "OUTSIDE  %d m" % int(dist), fs, Color(1, 0.45, 0.4))
		else:
			_text(Vector2(8, sz - 8), "SAFE", fs, Color(0.6, 0.85, 1.0))


## Frame and corner marks for the battle royale map.
func _draw_br_frame() -> void:
	var gold := Color(1.0, 0.85, 0.5, 0.95)
	var l := 14.0 if not big else 28.0
	for c in [Vector2(0, 0), Vector2(sz, 0), Vector2(0, sz), Vector2(sz, sz)]:
		var sx := 1.0 if c.x == 0.0 else -1.0
		var sy := 1.0 if c.y == 0.0 else -1.0
		draw_line(c + Vector2(0, 1.5 * sy), c + Vector2(l * sx, 1.5 * sy), gold, 3.0)
		draw_line(c + Vector2(1.5 * sx, 0), c + Vector2(1.5 * sx, l * sy), gold, 3.0)
