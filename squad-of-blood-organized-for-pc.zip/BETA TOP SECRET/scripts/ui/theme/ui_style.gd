extends RefCounted
## Menu look & feel: palette, one shared Theme (buttons, sliders, switches, dropdowns)
## and small helpers that build styled controls from code.

const ACCENT := Color(1.0, 0.55, 0.12)
const ACCENT_LIGHT := Color(1.0, 0.8, 0.5)
const ACCENT_DARK := Color(0.78, 0.36, 0.06)
const GLASS := Color(0.06, 0.08, 0.12, 0.8)
const TEXT := Color(0.93, 0.96, 1.0)
const TEXT_DIM := Color(0.68, 0.74, 0.84)
const GOLD := Color(1, 0.85, 0.6)

const CONTROLS_MOVE := "WASD move · Shift sprint · C crouch · Z prone · Space jump (x2) · Q dash"
const CONTROLS_COMBAT := "LMB fire · RMB aim · R reload · 1-4 / wheel weapons"
const TOUCH_MOVE := "Left side: stick to move (push fully up to sprint) · Right side: drag to look · JUMP / DASH / CROUCH / PRONE buttons"
const TOUCH_COMBAT := "FIRE hold · AIM toggle · RELOAD · tap the weapon name to switch"

static var _theme: Theme


## Control hints for the active scheme (PC or touch).
static func controls_move() -> String:
	return TOUCH_MOVE if Settings.use_touch() else CONTROLS_MOVE


static func controls_combat() -> String:
	return TOUCH_COMBAT if Settings.use_touch() else CONTROLS_COMBAT


# --------------------------------------------------------------------------- labels

static func label(text: String, size: int, color := Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


## Big heading with outline and drop shadow.
static func title(text: String, size: int, color := GOLD) -> Label:
	var l := label(text, size, color)
	l.add_theme_constant_override("outline_size", maxi(4, int(size * 0.12)))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.45))
	l.add_theme_constant_override("shadow_offset_y", 3)
	return l


## Small orange section header ("SELECT MODE").
static func section(text: String) -> Label:
	var l := label(text, 15, ACCENT)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	l.add_theme_constant_override("outline_size", 3)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
	return l


## Empty layout filler that never eats mouse clicks.
static func spacer(expand_h := false, expand_v := false, min_size := Vector2.ZERO) -> Control:
	var s := Control.new()
	s.mouse_filter = Control.MOUSE_FILTER_IGNORE
	s.custom_minimum_size = min_size
	if expand_h:
		s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	if expand_v:
		s.size_flags_vertical = Control.SIZE_EXPAND_FILL
	return s


# --------------------------------------------------------------------------- style boxes

static func box(bg: Color, border := Color(1, 1, 1, 0.14), radius := 4, border_w := 1) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_corner_radius_all(radius)
	sb.set_border_width_all(border_w)
	sb.border_color = border
	sb.content_margin_left = 22
	sb.content_margin_right = 22
	sb.content_margin_top = 10
	sb.content_margin_bottom = 10
	sb.anti_aliasing = true
	return sb


static func _plain(bg: Color, radius := 6) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_corner_radius_all(radius)
	sb.anti_aliasing = true
	return sb


## Outline drawn on top of a focused button (keyboard / gamepad).
static func focus_box(radius := 10) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.draw_center = false
	sb.set_corner_radius_all(radius)
	sb.set_border_width_all(2)
	sb.border_color = Color(1, 1, 1, 0.9)
	sb.anti_aliasing = true
	return sb


## Glass card used to group menu content.
static func panel_style(bg := GLASS, radius := 6, margin := 20.0) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_corner_radius_all(radius)
	sb.set_border_width_all(1)
	sb.border_color = Color(1, 1, 1, 0.12)
	sb.border_width_top = 2
	sb.set_content_margin_all(margin)
	sb.shadow_color = Color(0, 0, 0, 0.45)
	sb.shadow_size = 18
	sb.shadow_offset = Vector2(0, 6)
	sb.anti_aliasing = true
	return sb


static func panel(bg := GLASS, radius := 6, margin := 20.0) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", panel_style(bg, radius, margin))
	return p


# --------------------------------------------------------------------------- buttons

static func button(text: String, on_pressed: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(280, 58)
	b.add_theme_font_size_override("font_size", 24)
	b.theme = make_theme()
	b.pressed.connect(on_pressed)
	return b


## Big orange call-to-action button (START, BACK). Slanted and glowing.
static func accent_button(text: String, on_pressed: Callable, min_size := Vector2(320, 72), font_size := 30) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.add_theme_font_size_override("font_size", font_size)
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color.WHITE)
	b.add_theme_color_override("font_focus_color", Color.WHITE)
	b.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.4))
	b.add_theme_constant_override("outline_size", 4)
	b.add_theme_color_override("font_outline_color", Color(0.35, 0.12, 0.0, 0.8))
	b.add_theme_stylebox_override("normal", _accent_box(ACCENT, ACCENT_LIGHT, true))
	b.add_theme_stylebox_override("hover", _accent_box(Color(1.0, 0.67, 0.25), Color.WHITE, true))
	b.add_theme_stylebox_override("pressed", _accent_box(ACCENT_DARK, ACCENT_LIGHT, false))
	var focus := focus_box(12)
	focus.set("skew", Vector2(-0.14, 0.0))
	b.add_theme_stylebox_override("focus", focus)
	b.add_theme_stylebox_override("disabled", _accent_box(Color(0.2, 0.22, 0.27), Color(1, 1, 1, 0.1), false))
	b.pressed.connect(on_pressed)
	return b


static func _accent_box(bg: Color, border: Color, glow: bool) -> StyleBoxFlat:
	var sb := box(bg, border, 4, 2)
	sb.content_margin_left = 34
	sb.content_margin_right = 34
	sb.set("skew", Vector2(-0.14, 0.0))   # slanted look (set() so an engine without it just ignores it)
	if glow:
		sb.shadow_color = Color(1, 0.5, 0.1, 0.45)
		sb.shadow_size = 16
	return sb


## Selectable game-mode card: title + one-line tag. Put cards in one ButtonGroup.
static func mode_card(title_text: String, tag_text: String, soon := false) -> Button:
	var b := Button.new()
	b.toggle_mode = true
	b.custom_minimum_size = Vector2(380, 58)
	var base := Color(0.08, 0.09, 0.12, 0.8) if soon else Color(0.09, 0.12, 0.18, 0.86)
	var picked := _card_box(Color(0.9, 0.45, 0.1, 0.95), ACCENT_LIGHT, 8)
	b.add_theme_stylebox_override("normal", _card_box(base, Color(1, 1, 1, 0.16), 5))
	b.add_theme_stylebox_override("hover", _card_box(Color(0.18, 0.23, 0.32, 0.92), Color(1, 0.8, 0.5, 0.8), 5))
	b.add_theme_stylebox_override("pressed", picked)
	b.add_theme_stylebox_override("hover_pressed", picked)
	var focus := focus_box(12)
	focus.set("skew", Vector2(-0.06, 0.0))
	b.add_theme_stylebox_override("focus", focus)

	var col := VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_theme_constant_override("separation", 0)
	col.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	col.offset_left = 24
	col.offset_right = -12
	var t := label(title_text, 24, Color(1, 1, 1, 0.5) if soon else Color.WHITE)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	var s := label(tag_text, 14, ACCENT if soon else TEXT_DIM)
	s.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	col.add_child(t)
	col.add_child(s)
	b.add_child(col)
	return b


static func _card_box(bg: Color, border: Color, left_w: int) -> StyleBoxFlat:
	var sb := box(bg, border, 4, 1)
	sb.border_width_left = left_w
	sb.set("skew", Vector2(-0.06, 0.0))
	return sb


## Square colour swatch (toggle) for outfit selection.
static func swatch(color: Color) -> Button:
	var b := Button.new()
	b.toggle_mode = true
	b.custom_minimum_size = Vector2(46, 46)
	var picked := box(color, ACCENT, 10, 4)
	picked.shadow_color = Color(1, 0.55, 0.12, 0.6)
	picked.shadow_size = 8
	b.add_theme_stylebox_override("normal", box(color, Color(1, 1, 1, 0.3), 10, 2))
	b.add_theme_stylebox_override("hover", box(color.lightened(0.15), Color.WHITE, 10, 2))
	b.add_theme_stylebox_override("pressed", picked)
	b.add_theme_stylebox_override("hover_pressed", picked)
	b.add_theme_stylebox_override("focus", focus_box())
	return b


# --------------------------------------------------------------------------- shared theme

## One Theme for all menus: set it on a menu root and everything below is styled.
static func make_theme() -> Theme:
	if _theme:
		return _theme
	var t := Theme.new()
	t.default_font_size = 20
	_style_buttons(t, "Button")
	_style_buttons(t, "OptionButton")

	# Slider: thin rounded track, orange fill, round knob
	var track := _plain(Color(1, 1, 1, 0.14), 5)
	track.content_margin_top = 5
	track.content_margin_bottom = 5
	var fill := _plain(ACCENT, 5)
	fill.content_margin_top = 5
	fill.content_margin_bottom = 5
	var fill_hi := _plain(ACCENT_LIGHT, 5)
	fill_hi.content_margin_top = 5
	fill_hi.content_margin_bottom = 5
	t.set_stylebox("slider", "HSlider", track)
	t.set_stylebox("grabber_area", "HSlider", fill)
	t.set_stylebox("grabber_area_highlight", "HSlider", fill_hi)
	var knob := _knob(ACCENT)
	var knob_hi := _knob(ACCENT_LIGHT)
	t.set_icon("grabber", "HSlider", knob)
	t.set_icon("grabber_highlight", "HSlider", knob_hi)
	t.set_icon("grabber_disabled", "HSlider", knob)

	# Check button drawn as a pill switch
	var on_icon := _switch(true)
	var off_icon := _switch(false)
	for suffix in ["", "_mirrored"]:
		t.set_icon("checked" + suffix, "CheckButton", on_icon)
		t.set_icon("unchecked" + suffix, "CheckButton", off_icon)
		t.set_icon("checked_disabled" + suffix, "CheckButton", on_icon)
		t.set_icon("unchecked_disabled" + suffix, "CheckButton", off_icon)
	t.set_color("font_color", "CheckButton", TEXT)
	t.set_color("font_hover_color", "CheckButton", Color.WHITE)
	t.set_color("font_pressed_color", "CheckButton", Color.WHITE)

	# Dropdown list of OptionButton
	var popup := box(Color(0.07, 0.09, 0.13, 0.98), Color(1, 1, 1, 0.16), 10, 1)
	popup.set_content_margin_all(8)
	t.set_stylebox("panel", "PopupMenu", popup)
	t.set_stylebox("hover", "PopupMenu", _plain(ACCENT_DARK, 6))
	t.set_color("font_color", "PopupMenu", TEXT)
	t.set_color("font_hover_color", "PopupMenu", Color.WHITE)
	t.set_constant("v_separation", "PopupMenu", 12)

	var line := StyleBoxLine.new()
	line.color = Color(1, 1, 1, 0.08)
	line.thickness = 1
	t.set_stylebox("separator", "HSeparator", line)
	t.set_constant("separation", "HSeparator", 8)

	_theme = t
	return t


static func _style_buttons(t: Theme, type: String) -> void:
	var pressed := box(ACCENT_DARK, ACCENT_LIGHT, 4, 2)
	var hover := box(Color(0.2, 0.25, 0.34, 0.95), Color(1, 0.8, 0.5, 0.8), 4, 2)
	hover.border_width_left = 6
	t.set_stylebox("normal", type, box(Color(0.1, 0.13, 0.19, 0.88)))
	t.set_stylebox("hover", type, hover)
	t.set_stylebox("pressed", type, pressed)
	t.set_stylebox("hover_pressed", type, pressed)
	t.set_stylebox("focus", type, focus_box())
	t.set_stylebox("disabled", type, box(Color(0.08, 0.09, 0.11, 0.8), Color(1, 1, 1, 0.08)))
	t.set_color("font_color", type, TEXT)
	t.set_color("font_hover_color", type, Color.WHITE)
	t.set_color("font_pressed_color", type, Color.WHITE)
	t.set_color("font_hover_pressed_color", type, Color.WHITE)
	t.set_color("font_focus_color", type, Color.WHITE)
	t.set_color("font_disabled_color", type, Color(1, 1, 1, 0.4))


## Round slider knob with a white centre.
static func _knob(color: Color) -> ImageTexture:
	var s := 30
	var img := Image.create(s, s, false, Image.FORMAT_RGBA8)
	var c := Vector2(s, s) * 0.5
	for y in s:
		for x in s:
			var d := Vector2(x + 0.5, y + 0.5).distance_to(c)
			var col := Color.WHITE if d < 6.0 else color
			col.a = clampf(0.5 - (d - (s * 0.5 - 1.0)), 0.0, 1.0)
			img.set_pixel(x, y, col)
	return ImageTexture.create_from_image(img)


## Pill-shaped on/off switch icon for CheckButton.
static func _switch(on: bool) -> ImageTexture:
	var w := 56
	var h := 30
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	var track := ACCENT if on else Color(0.3, 0.33, 0.4)
	var r := h * 0.5
	var knob_x := (w - r) if on else r
	for y in h:
		for x in w:
			var p := Vector2(x + 0.5, y + 0.5)
			var cx := clampf(p.x, r, w - r)
			var a_track := clampf(0.5 - (p.distance_to(Vector2(cx, r)) - r), 0.0, 1.0)
			var a_knob := clampf(0.5 - (p.distance_to(Vector2(knob_x, r)) - (r - 4.0)), 0.0, 1.0)
			var col := Color(track.r, track.g, track.b, a_track)
			col = col.lerp(Color(1, 1, 1, 1), a_knob)
			img.set_pixel(x, y, col)
	return ImageTexture.create_from_image(img)


# --------------------------------------------------------------------------- FPS-style building blocks

const MODE_FREE := Color(0.35, 0.85, 0.55)
const MODE_TIMED := Color(1.0, 0.78, 0.2)
const MODE_ROUNDS := Color(0.95, 0.3, 0.3)
const MODE_BR := Color(0.35, 0.7, 1.0)


## Short orange bar used under big titles.
static func accent_line(width := 120.0, height := 4.0) -> ColorRect:
	var r := ColorRect.new()
	r.color = ACCENT
	r.custom_minimum_size = Vector2(width, height)
	r.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return r


## Section header: small orange block, the text and a thin line that fills the row.
static func section_header(text: String) -> Control:
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 10)
	var block := ColorRect.new()
	block.color = ACCENT
	block.custom_minimum_size = Vector2(6, 16)
	block.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	block.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(block)
	var l := label(text, 15, ACCENT_LIGHT)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	row.add_child(l)
	var line := ColorRect.new()
	line.color = Color(1, 1, 1, 0.12)
	line.custom_minimum_size = Vector2(0, 1)
	line.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	line.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(line)
	return row


## Glass card with a section header. Add your content to `card.get_meta("body")`.
static func card(title_text: String, bg := GLASS, margin := 18.0) -> PanelContainer:
	var p := panel(bg, 6, margin)
	var body := VBoxContainer.new()
	body.mouse_filter = Control.MOUSE_FILTER_IGNORE
	body.add_theme_constant_override("separation", 10)
	p.add_child(body)
	if title_text != "":
		body.add_child(section_header(title_text))
	p.set_meta("body", body)
	return p


## Transparent button with a left accent bar, for vertical lists (pause menu, back buttons).
static func nav_button(text: String, on_pressed: Callable, min_size := Vector2(360, 56), font_size := 24) -> Button:
	var b := Button.new()
	b.text = text
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.custom_minimum_size = min_size
	b.add_theme_font_size_override("font_size", font_size)
	var normal := box(Color(0.04, 0.06, 0.09, 0.6), Color(1, 1, 1, 0.08), 2, 1)
	normal.border_width_left = 4
	normal.border_color = Color(1, 1, 1, 0.22)
	normal.content_margin_left = 26
	var hover := box(Color(0.16, 0.2, 0.28, 0.92), ACCENT, 2, 1)
	hover.border_width_left = 8
	hover.content_margin_left = 26
	var pressed := box(ACCENT_DARK, ACCENT_LIGHT, 2, 1)
	pressed.border_width_left = 8
	pressed.content_margin_left = 26
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", pressed)
	b.add_theme_stylebox_override("hover_pressed", pressed)
	b.add_theme_stylebox_override("focus", hover)
	b.add_theme_color_override("font_color", TEXT)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_focus_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color.WHITE)
	b.pressed.connect(on_pressed)
	return b


## Dark slanted button with an orange outline (secondary call to action, e.g. SELECT MODE).
static func ghost_button(text: String, on_pressed: Callable, min_size := Vector2(340, 60), font_size := 24) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.add_theme_font_size_override("font_size", font_size)
	b.add_theme_color_override("font_color", ACCENT_LIGHT)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color.WHITE)
	b.add_theme_color_override("font_focus_color", Color.WHITE)
	b.add_theme_constant_override("outline_size", 3)
	b.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.6))
	b.add_theme_stylebox_override("normal", _ghost_box(Color(0.05, 0.07, 0.1, 0.9), Color(1, 0.55, 0.12, 0.85)))
	b.add_theme_stylebox_override("hover", _ghost_box(Color(0.78, 0.36, 0.06, 0.95), ACCENT_LIGHT))
	b.add_theme_stylebox_override("pressed", _ghost_box(ACCENT_DARK, ACCENT_LIGHT))
	var focus := focus_box(4)
	focus.set("skew", Vector2(-0.14, 0.0))
	b.add_theme_stylebox_override("focus", focus)
	b.pressed.connect(on_pressed)
	return b


static func _ghost_box(bg: Color, border: Color) -> StyleBoxFlat:
	var sb := box(bg, border, 4, 2)
	sb.content_margin_left = 30
	sb.content_margin_right = 30
	sb.set("skew", Vector2(-0.14, 0.0))
	return sb


## Weapon stat row: name, thin bar and a value. `row.get_meta("bar")` is the ProgressBar (0..1),
## `row.get_meta("value")` the value label.
static func stat_row(name_text: String, color := ACCENT) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 10)
	var n := label(name_text, 13, TEXT_DIM)
	n.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	n.custom_minimum_size = Vector2(84, 0)
	row.add_child(n)
	var bar := ProgressBar.new()
	bar.min_value = 0.0
	bar.max_value = 1.0
	bar.step = 0.001
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(0, 8)
	bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_theme_stylebox_override("background", _plain(Color(1, 1, 1, 0.1), 2))
	bar.add_theme_stylebox_override("fill", _plain(color, 2))
	row.add_child(bar)
	var v := label("", 13, Color.WHITE)
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	v.custom_minimum_size = Vector2(54, 0)
	row.add_child(v)
	row.set_meta("bar", bar)
	row.set_meta("value", v)
	return row


## Tall selectable mode tile for the SELECT MODE screen. Put tiles in one ButtonGroup.
## `tile.get_meta("badge")` is a label that is shown while the tile is the chosen mode.
static func mode_tile(num: String, title_text: String, tag_text: String, desc: String, meta_text: String, best_text: String, color: Color) -> Button:
	var b := Button.new()
	b.toggle_mode = true
	b.custom_minimum_size = Vector2(250, 380)
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var dim := color.darkened(0.55)
	b.add_theme_stylebox_override("normal", _tile_box(Color(0.06, 0.08, 0.12, 0.92), dim))
	b.add_theme_stylebox_override("hover", _tile_box(Color(0.12, 0.16, 0.23, 0.97), color))
	var picked := _tile_box(Color(color.r * 0.3, color.g * 0.3, color.b * 0.3, 0.97), color)
	picked.shadow_color = Color(color.r, color.g, color.b, 0.4)
	picked.shadow_size = 18
	b.add_theme_stylebox_override("pressed", picked)
	b.add_theme_stylebox_override("hover_pressed", picked)
	b.add_theme_stylebox_override("focus", _tile_box(Color(0.12, 0.16, 0.23, 0.97), Color.WHITE))

	var col := VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	col.offset_left = 20
	col.offset_right = -20
	col.offset_top = 18
	col.offset_bottom = -16
	col.add_theme_constant_override("separation", 6)
	b.add_child(col)

	var n := title(num, 56, color)
	n.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	col.add_child(n)
	var t := title(title_text, 28, Color.WHITE)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	col.add_child(t)
	var tg := label(tag_text, 15, color.lightened(0.25))
	tg.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	col.add_child(tg)
	var bar := ColorRect.new()
	bar.color = color
	bar.custom_minimum_size = Vector2(60, 3)
	bar.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(bar)
	var d := label(desc, 14, TEXT)
	d.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	d.size_flags_vertical = Control.SIZE_EXPAND_FILL
	d.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(d)
	var m := label(meta_text, 12, TEXT_DIM)
	m.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	col.add_child(m)
	var best := label(best_text, 20, GOLD)
	best.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	col.add_child(best)
	var badge := label("SELECTED", 14, color)
	badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	badge.visible = false
	col.add_child(badge)
	b.set_meta("badge", badge)
	return b


static func _tile_box(bg: Color, border: Color) -> StyleBoxFlat:
	var sb := box(bg, border, 4, 2)
	sb.border_width_top = 6
	return sb


# --------------------------------------------------------------------------- store

const COIN_COLOR := Color(1.0, 0.8, 0.25)
const GEM_COLOR := Color(0.95, 0.62, 0.1)   # amber, matches the CAC card
const CAC_ICON_PATH := "res://assets/art/cac_icon.png"


static func rarity_color(rarity: String) -> Color:
	match rarity:
		"rare":
			return Color(0.35, 0.65, 1.0)
		"epic":
			return Color(0.72, 0.42, 1.0)
		"legendary":
			return Color(1.0, 0.72, 0.2)
	return Color(0.65, 0.7, 0.78)


## Currency colour for "coins" / "gems" (anything else = white).
static func currency_color(cur: String) -> Color:
	if cur == "coins":
		return COIN_COLOR
	if cur == "gems":
		return GEM_COLOR
	return Color.WHITE


## Plain-shape currency icon, used when the CAC artwork is missing: round coin or tilted diamond.
static func _coin_icon(color: Color, diamond: bool) -> Panel:
	var icon := Panel.new()
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var ib := StyleBoxFlat.new()
	ib.bg_color = color
	ib.border_color = color.darkened(0.45)
	ib.set_border_width_all(3)
	ib.anti_aliasing = true
	if diamond:
		ib.set_corner_radius_all(2)
		icon.position = Vector2(7, 7)
		icon.size = Vector2(16, 16)
		icon.pivot_offset = Vector2(8, 8)
		icon.rotation = PI / 4.0
	else:
		ib.set_corner_radius_all(11)
		icon.position = Vector2(4, 4)
		icon.size = Vector2(22, 22)
	icon.add_theme_stylebox_override("panel", ib)
	return icon


## Small pill showing a currency icon and an amount. `chip.get_meta("value")` is the amount label.
## kind: "coins" (round gold coin) or "gems" (the paid currency: the black CAC card).
static func currency_chip(kind: String) -> PanelContainer:
	var color := currency_color(kind)
	var p := PanelContainer.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var chip_bg := Color(0.0, 0.0, 0.0, 0.95) if kind == "gems" else Color(0.04, 0.06, 0.1, 0.9)
	var sb := box(chip_bg, Color(color.r, color.g, color.b, 0.55), 4, 1)
	sb.content_margin_left = 10
	sb.content_margin_right = 14
	sb.content_margin_top = 5
	sb.content_margin_bottom = 5
	p.add_theme_stylebox_override("panel", sb)
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 8)
	p.add_child(row)

	var holder := Control.new()
	holder.custom_minimum_size = Vector2(30, 30)
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var card_tex: Texture2D = load(CAC_ICON_PATH) if kind == "gems" else null
	if card_tex != null:
		var logo := TextureRect.new()
		logo.texture = card_tex
		logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		logo.size = Vector2(30, 30)
		logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
		holder.add_child(logo)
	else:
		holder.add_child(_coin_icon(color, kind == "gems"))
	row.add_child(holder)

	var v := label("0", 21, Color.WHITE)
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	v.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(v)
	p.set_meta("value", v)
	return p


## Store tile for one skin: three colour bars (shirt, vest, accent), name, rarity and a price line.
## `tile.get_meta("price")` is the price label, set by the store.
static func skin_tile(name_text: String, rarity: String, colors: Array) -> Button:
	var rc := rarity_color(rarity)
	var b := Button.new()
	b.toggle_mode = true
	b.custom_minimum_size = Vector2(236, 104)
	var normal := _tile_box(Color(0.06, 0.08, 0.12, 0.92), rc.darkened(0.5))
	normal.border_width_top = 3
	var hover := _tile_box(Color(0.12, 0.16, 0.23, 0.97), rc)
	hover.border_width_top = 3
	var picked := _tile_box(Color(rc.r * 0.28, rc.g * 0.28, rc.b * 0.28, 0.97), rc)
	picked.border_width_top = 3
	picked.shadow_color = Color(rc.r, rc.g, rc.b, 0.35)
	picked.shadow_size = 12
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", picked)
	b.add_theme_stylebox_override("hover_pressed", picked)
	b.add_theme_stylebox_override("focus", hover)

	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	row.offset_left = 12
	row.offset_right = -12
	row.offset_top = 12
	row.offset_bottom = -10
	row.add_theme_constant_override("separation", 12)
	b.add_child(row)

	var strip := VBoxContainer.new()
	strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	strip.add_theme_constant_override("separation", 3)
	for c in colors:
		var r := ColorRect.new()
		r.color = c
		r.custom_minimum_size = Vector2(44, 0)
		r.size_flags_vertical = Control.SIZE_EXPAND_FILL
		r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		strip.add_child(r)
	row.add_child(strip)

	var col := VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_theme_constant_override("separation", 1)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var n := label(name_text, 20, Color.WHITE)
	n.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	col.add_child(n)
	var rl := label(rarity.to_upper(), 12, rc)
	rl.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	col.add_child(rl)
	var price := label("", 16, TEXT)
	price.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	col.add_child(price)
	row.add_child(col)
	b.set_meta("price", price)
	return b
