class_name Player
extends CharacterBody3D
## First-person controller: walk, sprint (stamina), crouch, double jump, slide-dash, view recoil.

signal damaged(amount: float)
signal died

# Movement
const WALK_SPEED := 6.0
const SPRINT_SPEED := 9.5
const CROUCH_SPEED := 3.0
const ACCEL := 45.0
const AIR_ACCEL := 12.0

# Jump: snappy rise, heavier fall, short hang at the top (about 1.5 m high, 1 s in the air; a tap gives a 0.7 m hop)
const JUMP_VELOCITY := 7.0
const DOUBLE_JUMP_SCALE := 0.85    # the air jump is a bit weaker than the first one
const AIR_JUMPS := 1
const RISE_GRAVITY := 1.7          # gravity multiplier while going up
const FALL_GRAVITY := 2.3          # gravity multiplier while falling
const CUT_GRAVITY := 3.5           # multiplier when jump is released early (short hop)
const HANG_SPEED := 1.2            # |vertical speed| below this counts as the apex
const HANG_GRAVITY := 0.7          # gravity multiplier at the apex
const MAX_FALL_SPEED := 40.0
const COYOTE_TIME := 0.1           # can still jump this long after leaving a ledge
const JUMP_BUFFER := 0.12          # a jump pressed this early before landing still counts

# Dash: a fast slide that starts quick and bleeds speed off, low to the ground
const DASH_SPEED := 18.0
const DASH_TIME := 0.5
const DASH_COOLDOWN := 1.8
const DASH_EXIT_SPEED := 6.0       # speed left when the slide ends
const DASH_FOV := 12.0

# Body
const STAND_HEIGHT := 2.0
const CROUCH_HEIGHT := 1.2
const PRONE_HEIGHT := 1.0          # lying flat (the capsule cannot be thinner than its width)
const PRONE_SPEED := 1.5
const EYE_OFFSET := 0.3
const HEIGHT_SPEED := 7.0          # m/s the capsule grows or shrinks when crouching
const SLIDE_HEIGHT_SPEED := 12.0   # faster drop when a slide starts

# Stamina
const STAMINA_MAX := 100.0
const SPRINT_DRAIN := 22.0
const STAMINA_REGEN := 18.0

# Health
const MAX_HEALTH := 100.0
const REGEN_DELAY := 6.0           # seconds without being hit before health comes back
const REGEN_RATE := 6.0            # health per second

const SPAWN_POINT := Vector3(0, 0.05, 15)

@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D
@onready var col: CollisionShape3D = $CollisionShape3D
@onready var body_mesh: MeshInstance3D = $MeshInstance3D

@export var mouse_sensitivity := 0.002

# Read by the weapon manager
var look_scale := 1.0
var sprint_amount := 0.0
var fov_boost := 0.0
var crouching := false
var prone := false           # lying flat: slow, quiet, small target, steadier aim
var sprinting := false

var yaw := 0.0
var pitch := 0.0
var kick_queue := Vector2.ZERO     # recoil still to be applied (pitch, yaw) in radians
var recoil_accum := Vector2.ZERO   # recoil that has not been compensated yet
var recoil_hold := 0.0

var health := MAX_HEALTH
var dead := false
var since_hit := 99.0
var stamina := STAMINA_MAX
var sprint_locked := false
var regen_delay := 0.0
var air_jumps_left := AIR_JUMPS
var coyote := 0.0
var jump_buffer := 0.0
var dash_timer := 0.0
var dash_cd := 0.0
var dash_dir := Vector3.ZERO
var jump_physics := true   # false while parachuting (the BR mode owns the fall)
var cur_height := STAND_HEIGHT
var was_on_floor := true
var prev_vy := 0.0
var land_dip := 0.0
var bob_t := 0.0
var bob_amp := 0.0
var shake := 0.0       # camera shake from firing (0..1), decays quickly
var shake_t := 0.0
var cam_roll := 0.0    # smoothed lean into strafing
var cam_back_target := 0.0   # >0: third-person, camera this many metres behind the head (e.g. outside the BR plane)
var cam_back := 0.0

var wm: WeaponManager
var audio: PlayerAudio
var slide_fx: SlideFX
var last_step := 0
var skin_visual: Node3D
var skin_third := false


func _ready() -> void:
	Input.mouse_mode = Settings.gameplay_mouse_mode()
	audio = PlayerAudio.new()
	audio.name = "Audio"
	add_child(audio)
	slide_fx = SlideFX.new()
	slide_fx.name = "SlideFX"
	add_child(slide_fx)
	slide_fx.setup(camera, self)
	collision_layer = Layers.PLAYER
	collision_mask = Layers.WORLD | Layers.WALLS | Layers.TARGETS
	body_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_SHADOWS_ONLY
	wm = get_tree().get_first_node_in_group("weapon_manager") as WeaponManager
	_apply_height(STAND_HEIGHT)
	_setup_asset_skin()


func _setup_asset_skin() -> void:
	# Keep the original capsule as the gameplay collider, but use the supplied
	# Samurai GLB as the visible third-person character.
	skin_visual = AssetBridge.instantiate(self, "sammuray")
	if skin_visual == null:
		return
	skin_visual.name = "SamuraiSkin"
	skin_visual.position = Vector3(0.0, 0.0, 0.0)
	skin_visual.rotation = Vector3.ZERO
	skin_visual.scale = Vector3.ONE
	_hide_asset_ground(skin_visual)
	_set_asset_shadow(skin_visual)


func _hide_asset_ground(node: Node) -> void:
	for child in node.get_children():
		if child.name.to_lower().contains("ground"):
			if child is Node3D:
				(child as Node3D).visible = false
		_hide_asset_ground(child)


## First person: the skin must not be drawn (the camera is inside it), only its shadow.
## Third person (plane view): draw it normally.
func _set_asset_shadow(node: Node, body_visible := false) -> void:
	if node is GeometryInstance3D:
		(node as GeometryInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if body_visible else GeometryInstance3D.SHADOW_CASTING_SETTING_SHADOWS_ONLY
	for child in node.get_children():
		_set_asset_shadow(child, body_visible)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		look(event.relative)


## Turns the view by a pointer movement in pixels. Used by mouse-look (PC) and drag-look (touch).
func look(relative: Vector2, gain := 1.0) -> void:
	var s := mouse_sensitivity * Settings.sensitivity * look_scale * gain
	yaw -= relative.x * s
	var dp: float = relative.y * s
	pitch = clampf(pitch - dp, deg_to_rad(-89.0), deg_to_rad(89.0))
	# Pulling down compensates outstanding recoil
	if dp > 0.0:
		recoil_accum.x = maxf(0.0, recoil_accum.x - dp)


## Called by weapons: a short camera shake (roll + small position jolt; never changes the aim).
func add_shake(amount: float) -> void:
	shake = minf(shake + amount, 1.0)


## Called by weapons. Angles in radians (positive pitch = view goes up).
func add_recoil(pitch_kick: float, yaw_kick: float) -> void:
	kick_queue += Vector2(pitch_kick, yaw_kick)
	recoil_accum += Vector2(pitch_kick, yaw_kick)
	recoil_hold = 0.14


func _process(delta: float) -> void:
	# Smoothly apply recoil kick
	var take := kick_queue * (1.0 - exp(-30.0 * delta))
	kick_queue -= take
	pitch += take.x
	yaw += take.y

	# Recover (pull the view back down) after a short pause in shooting
	recoil_hold = maxf(0.0, recoil_hold - delta)
	if recoil_hold <= 0.0:
		var rec := recoil_accum * (1.0 - exp(-6.0 * delta))
		recoil_accum -= rec
		pitch -= rec.x
		yaw -= rec.y

	pitch = clampf(pitch, deg_to_rad(-89.0), deg_to_rad(89.0))
	rotation.y = yaw
	head.rotation.x = pitch

	# Head bob + landing dip
	var hspeed := Vector2(velocity.x, velocity.z).length()
	var target_amp := 0.0
	if is_on_floor() and hspeed > 0.5:
		target_amp = clampf(hspeed / WALK_SPEED, 0.0, 1.5)
	bob_amp = lerpf(bob_amp, target_amp, 1.0 - exp(-10.0 * delta))
	bob_t += delta * hspeed * 1.5
	# One footstep per half bob cycle while walking on the ground
	var step_i := int(floorf(bob_t / PI))
	if step_i != last_step and is_on_floor() and hspeed > 0.5:
		audio.step(-16.0 if prone else (-8.0 if crouching else (2.0 if sprinting else 0.0)))
	last_step = step_i
	land_dip = lerpf(land_dip, 0.0, 1.0 - exp(-9.0 * delta))
	camera.position = Vector3(cos(bob_t * 0.5) * 0.02 * bob_amp, sin(bob_t) * 0.03 * bob_amp - land_dip, 0.0)

	# Depth: lean into strafing, sway side to side while running, shake when firing.
	# Only roll and position are touched, so the aim direction never changes.
	var calm := 1.0 - 0.6 * (wm.aim_t if wm != null else 0.0)   # steadier while aiming
	var local_v := global_transform.basis.inverse() * velocity
	var strafe := clampf(local_v.x / SPRINT_SPEED, -1.0, 1.0)
	cam_roll = lerpf(cam_roll, -strafe * deg_to_rad(2.2) * calm, 1.0 - exp(-8.0 * delta))
	var run_sway := cos(bob_t * 0.5) * deg_to_rad(0.8) * bob_amp * calm
	shake = maxf(0.0, shake - (shake * 9.0 + 0.4) * delta)
	shake_t += delta * 70.0
	var jolt := shake * calm
	camera.position += Vector3(sin(shake_t * 1.1) * 0.006, sin(shake_t * 1.9) * 0.006, 0.012) * jolt

	# Third-person orbit (BR plane): pull the camera back along its own view direction
	cam_back = lerpf(cam_back, cam_back_target, 1.0 - exp(-4.0 * delta))
	if cam_back < 0.02 and cam_back_target <= 0.0:
		cam_back = 0.0
	camera.position += Vector3(0.0, cam_back * 0.08, cam_back)
	var want_third := cam_back > 1.0
	if want_third != skin_third and skin_visual != null:
		skin_third = want_third
		_set_asset_shadow(skin_visual, want_third)
	camera.rotation.z = cam_roll + run_sway + sin(shake_t * 1.3) * deg_to_rad(1.4) * jolt

	# Smooth crouch height
	var target_h := PRONE_HEIGHT if prone else (CROUCH_HEIGHT if crouching else STAND_HEIGHT)
	if not is_equal_approx(cur_height, target_h):
		var rate := SLIDE_HEIGHT_SPEED if dash_timer > 0.0 else HEIGHT_SPEED
		_apply_height(move_toward(cur_height, target_h, rate * delta))


func _apply_height(h: float) -> void:
	cur_height = h
	(col.shape as CapsuleShape3D).height = h
	col.position.y = h / 2.0
	(body_mesh.mesh as CapsuleMesh).height = h
	body_mesh.position.y = h / 2.0
	head.position.y = h - EYE_OFFSET


## True while falling with the floor within reach of the jump buffer window.
func _about_to_land() -> bool:
	if velocity.y > 0.0:
		return false
	var reach := maxf(0.35, -velocity.y * JUMP_BUFFER)
	return test_move(global_transform, Vector3.DOWN * reach)


func _ground_jump() -> void:
	velocity.y = JUMP_VELOCITY
	coyote = 0.0
	jump_buffer = 0.0
	if dash_timer > 0.0:
		dash_timer = 0.0   # jumping out of a slide keeps the momentum


func _physics_process(delta: float) -> void:
	var on_floor := is_on_floor()
	_update_health(delta)
	_update_landing(on_floor)
	_update_crouch()

	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_backward")
	var direction := (transform.basis * Vector3(input_dir.x, 0.0, input_dir.y)).normalized()
	var aiming: bool = wm != null and wm.is_aiming

	var speed := _update_sprint(delta, input_dir, aiming)
	_update_jump(delta, on_floor)
	_update_dash(delta, direction)
	_apply_gravity(delta, on_floor)
	_apply_movement(delta, on_floor, direction, speed)

	prev_vy = velocity.y
	move_and_slide()

	var slide_amount := minf(1.0, _dash_progress() * 3.0)   # fades out over the last third of the slide
	slide_fx.set_state(slide_amount, on_floor)
	audio.set_wind(slide_amount)

	var fov_target := DASH_FOV * _dash_progress() + 6.0 * sprint_amount
	fov_boost = lerpf(fov_boost, fov_target, 1.0 - exp(-10.0 * delta))

	if global_position.y < -30.0:
		global_position = SPAWN_POINT
		velocity = Vector3.ZERO


func _update_health(delta: float) -> void:
	since_hit += delta
	if not dead and health < MAX_HEALTH and since_hit > REGEN_DELAY:
		health = minf(MAX_HEALTH, health + REGEN_RATE * delta)


func _update_landing(on_floor: bool) -> void:
	if on_floor:
		air_jumps_left = AIR_JUMPS
		if not was_on_floor and prev_vy < -5.0:
			land_dip = clampf(-prev_vy * 0.012, 0.04, 0.2)
			audio.land(clampf(-prev_vy / 15.0, 0.3, 1.0))
	was_on_floor = on_floor


## Prone (Z) toggles lying flat. Jump, crouch, dash or sprint get you up again.
## Crouch is held; a slide forces it. Only stand up if there is room above.
func _update_crouch() -> void:
	if Input.is_action_just_pressed("prone") and not prone and dash_timer <= 0.0 and is_on_floor():
		prone = true
		crouching = false
		return
	if prone:
		var leave := Input.is_action_just_pressed("prone") or Input.is_action_just_pressed("jump") \
				or Input.is_action_just_pressed("crouch") or Input.is_action_just_pressed("dash") \
				or Input.is_action_pressed("sprint")
		if not leave:
			return
		if test_move(global_transform, Vector3.UP * (CROUCH_HEIGHT - PRONE_HEIGHT + 0.05)):
			return   # no room to get up (under a low roof)
		prone = false
		# Not enough room to stand fully? come up crouching until there is.
		crouching = test_move(global_transform, Vector3.UP * (STAND_HEIGHT - PRONE_HEIGHT + 0.05))
	if Input.is_action_pressed("crouch") or dash_timer > 0.0:
		crouching = true
	elif crouching and not test_move(global_transform, Vector3.UP * (STAND_HEIGHT - CROUCH_HEIGHT + 0.05)):
		crouching = false


## Sprint drains stamina. Returns the ground speed the player is aiming for.
func _update_sprint(delta: float, input_dir: Vector2, aiming: bool) -> float:
	var want_sprint := Input.is_action_pressed("sprint") and input_dir.y < -0.1 \
			and not crouching and not prone and not aiming and not sprint_locked
	sprinting = want_sprint and stamina > 0.0
	if sprinting:
		stamina = maxf(0.0, stamina - SPRINT_DRAIN * delta)
		regen_delay = 0.8
		if stamina <= 0.0:
			sprint_locked = true
	else:
		regen_delay = maxf(0.0, regen_delay - delta)
		if regen_delay <= 0.0:
			stamina = minf(STAMINA_MAX, stamina + STAMINA_REGEN * delta)
		if sprint_locked and stamina > 25.0:
			sprint_locked = false
	sprint_amount = move_toward(sprint_amount, 1.0 if sprinting else 0.0, delta * 6.0)

	var speed := WALK_SPEED
	if sprinting:
		speed = SPRINT_SPEED
	elif prone:
		speed = PRONE_SPEED
	elif crouching:
		speed = CROUCH_SPEED
	if aiming:
		speed *= 0.65
	return speed


## Ground jump (coyote time + buffered press), then one air jump.
func _update_jump(delta: float, on_floor: bool) -> void:
	coyote = COYOTE_TIME if on_floor else maxf(0.0, coyote - delta)
	jump_buffer = maxf(0.0, jump_buffer - delta)

	if prone:
		jump_buffer = 0.0
		return   # cannot jump while lying down (the jump key gets you up instead)
	if Input.is_action_just_pressed("jump"):
		if coyote > 0.0:
			_ground_jump()
		elif air_jumps_left > 0 and not _about_to_land():
			air_jumps_left -= 1
			velocity.y = JUMP_VELOCITY * DOUBLE_JUMP_SCALE
		else:
			# Pressed just before landing: remember it instead of burning the air jump.
			jump_buffer = JUMP_BUFFER
	elif jump_buffer > 0.0 and on_floor:
		_ground_jump()


## Starts a slide on the dash key and counts it down.
func _update_dash(delta: float, direction: Vector3) -> void:
	dash_cd = maxf(0.0, dash_cd - delta)
	if Input.is_action_just_pressed("dash") and dash_cd <= 0.0 and dash_timer <= 0.0:
		dash_dir = direction if direction != Vector3.ZERO else -transform.basis.z
		dash_dir.y = 0.0
		dash_dir = dash_dir.normalized()
		dash_timer = DASH_TIME
		dash_cd = DASH_COOLDOWN
		audio.dash()
	elif dash_timer > 0.0:
		dash_timer = maxf(0.0, dash_timer - delta)


## 1 at the start of a slide, easing to 0 at the end.
func _dash_progress() -> float:
	return dash_timer / DASH_TIME


## Heavier on the way down, lighter at the apex, extra heavy when jump is let go early.
func _apply_gravity(delta: float, on_floor: bool) -> void:
	if on_floor:
		return
	var mult := 1.0
	if jump_physics:
		if velocity.y > HANG_SPEED:
			mult = RISE_GRAVITY if Input.is_action_pressed("jump") else CUT_GRAVITY
		elif velocity.y > -HANG_SPEED:
			mult = HANG_GRAVITY
		else:
			mult = FALL_GRAVITY
	velocity += get_gravity() * mult * delta
	if jump_physics:
		velocity.y = maxf(velocity.y, -MAX_FALL_SPEED)


func _apply_movement(delta: float, on_floor: bool, direction: Vector3, speed: float) -> void:
	if dash_timer > 0.0:
		# Fast at first, then the slide loses speed quickly (ease-out)
		var t := _dash_progress()
		var dash_speed := lerpf(DASH_EXIT_SPEED, DASH_SPEED, t * t)
		velocity.x = dash_dir.x * dash_speed
		velocity.z = dash_dir.z * dash_speed
		return
	var accel := ACCEL if on_floor else AIR_ACCEL
	velocity.x = move_toward(velocity.x, direction.x * speed, accel * delta)
	velocity.z = move_toward(velocity.z, direction.z * speed, accel * delta)


## Loot: restores health. Returns false when already at full health.
func heal(amount: float) -> bool:
	if dead or health >= MAX_HEALTH:
		return false
	health = minf(MAX_HEALTH, health + amount)
	return true


## 0..1, read by the HUD.
func stamina_fraction() -> float:
	return stamina / STAMINA_MAX


## 0..1 (1 = dash ready), read by the HUD.
func dash_fraction() -> float:
	return 1.0 - dash_cd / DASH_COOLDOWN


## Called by enemies when they hit you. `_from` is the shooter's position.
func take_damage(amount: float, _from: Vector3) -> void:
	if dead:
		return
	health = maxf(0.0, health - amount)
	since_hit = 0.0
	add_recoil(deg_to_rad(1.2), randf_range(-0.012, 0.012))   # the hit knocks your aim a little
	audio.hurt()
	damaged.emit(amount)
	if health <= 0.0:
		dead = true
		died.emit()


## 0..1, read by the HUD.
func health_fraction() -> float:
	return health / MAX_HEALTH
