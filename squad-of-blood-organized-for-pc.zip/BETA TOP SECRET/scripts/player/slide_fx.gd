class_name SlideFX
extends Node
## Air and dust effects for the dash slide: wind streaks rushing past the camera and dust kicked up at the feet.

const STREAK_AMOUNT := 48
const STREAK_LIFE := 0.22
const STREAK_SPEED := 34.0
const DUST_AMOUNT := 20

var streaks: CPUParticles3D
var dust: CPUParticles3D
var amount := 0.0   # 0..1, smoothed
var target := 0.0
var grounded := false


## camera gets the wind streaks, body (the player) gets the dust.
func setup(camera: Camera3D, body: Node3D) -> void:
	streaks = _make_streaks()
	camera.add_child(streaks)
	dust = _make_dust()
	body.add_child(dust)


## intensity 0..1 (0 = no slide). on_floor decides if dust is kicked up.
func set_state(intensity: float, on_floor: bool) -> void:
	target = intensity
	grounded = on_floor


func _process(delta: float) -> void:
	amount = lerpf(amount, target, 1.0 - exp(-14.0 * delta))
	var active := amount > 0.05
	streaks.emitting = active
	dust.emitting = active and grounded


## Thin white lines in front of the camera that fly towards it.
func _make_streaks() -> CPUParticles3D:
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.vertex_color_use_as_albedo = true
	mat.albedo_color = Color(1, 1, 1, 0.45)
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.008, 0.008, 1.4)
	mesh.material = mat

	var p := CPUParticles3D.new()
	p.mesh = mesh
	p.amount = STREAK_AMOUNT
	p.lifetime = STREAK_LIFE
	p.local_coords = true
	p.emitting = false
	p.position = Vector3(0.0, 0.0, -4.5)
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = Vector3(2.6, 1.6, 1.0)
	p.direction = Vector3(0, 0, 1)
	p.spread = 0.0
	p.gravity = Vector3.ZERO
	p.initial_velocity_min = STREAK_SPEED * 0.8
	p.initial_velocity_max = STREAK_SPEED * 1.2
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var fade := Gradient.new()
	fade.set_color(0, Color(1, 1, 1, 0))
	fade.set_color(1, Color(1, 1, 1, 0))
	fade.add_point(0.25, Color(1, 1, 1, 1))
	fade.add_point(0.7, Color(1, 1, 1, 1))
	p.color_ramp = fade
	return p


## Soft dust puffs at the feet, left behind in the world while sliding.
func _make_dust() -> CPUParticles3D:
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.vertex_color_use_as_albedo = true
	mat.albedo_color = Color(0.78, 0.74, 0.68, 0.5)
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	var mesh := QuadMesh.new()
	mesh.size = Vector2(0.45, 0.45)
	mesh.material = mat

	var p := CPUParticles3D.new()
	p.mesh = mesh
	p.amount = DUST_AMOUNT
	p.lifetime = 0.55
	p.local_coords = false
	p.emitting = false
	p.position = Vector3(0.0, 0.1, 0.0)
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	p.emission_sphere_radius = 0.3
	p.direction = Vector3.UP
	p.spread = 50.0
	p.gravity = Vector3(0.0, 0.8, 0.0)
	p.initial_velocity_min = 0.4
	p.initial_velocity_max = 1.4
	p.scale_amount_min = 0.5
	p.scale_amount_max = 1.2
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var fade := Gradient.new()
	fade.set_color(0, Color(1, 1, 1, 0.55))
	fade.set_color(1, Color(1, 1, 1, 0))
	p.color_ramp = fade
	var grow := Curve.new()
	grow.add_point(Vector2(0, 0.4))
	grow.add_point(Vector2(1, 1.6))
	p.scale_amount_curve = grow
	return p
