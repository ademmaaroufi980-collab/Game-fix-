extends StaticBody3D
## Procedural terrain: flat arena in the middle, rolling hills around it,
## a few explicit hills (slopes to run up), and a steep rim as a natural border.

const HALF := 60            # terrain spans [-HALF, HALF] on x and z
const STEP := 1.0           # grid spacing (metres)
const ARENA_HALF := 26.0    # flat zone half-size (Chebyshev distance)
const HILL_HEIGHT := 10.0
const RIM_HEIGHT := 16.0

@export var terrain_material: Material

# Explicit hills: x, z, radius, height
const HILLS := [
	Vector4(-18.0, 14.0, 7.0, 3.5),
	Vector4(22.0, 10.0, 8.0, 4.5),
	Vector4(-6.0, -24.0, 6.0, 3.0),
]

var noise := FastNoiseLite.new()


func _ready() -> void:
	noise.seed = 7
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = 0.03
	noise.fractal_octaves = 3
	if terrain_material is ShaderMaterial:
		(terrain_material as ShaderMaterial).set_shader_parameter("arena_half", ARENA_HALF)   # keep the shader in sync
	_build_terrain()
	_build_invisible_walls()


func height_at(x: float, z: float) -> float:
	var cheb := maxf(absf(x), absf(z))
	var hills_mask := smoothstep(ARENA_HALF, ARENA_HALF + 20.0, cheb)
	var h := (noise.get_noise_2d(x, z) * 0.5 + 0.5) * HILL_HEIGHT * hills_mask
	h += smoothstep(HALF - 10.0, HALF - 4.0, cheb) * RIM_HEIGHT
	for hill: Vector4 in HILLS:
		var d: float = Vector2(x - hill.x, z - hill.y).length() / hill.z
		if d < 1.0:
			var t: float = 1.0 - d * d
			h += t * t * hill.w
	return h


func _build_terrain() -> void:
	var n := int(HALF * 2 / STEP) + 1
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	indices.resize((n - 1) * (n - 1) * 6)
	verts.resize(n * n)
	norms.resize(n * n)
	uvs.resize(n * n)

	for iz in n:
		for ix in n:
			var x := -HALF + ix * STEP
			var z := -HALF + iz * STEP
			var i := iz * n + ix
			verts[i] = Vector3(x, height_at(x, z), z)
			var e := 0.5
			var dx := height_at(x + e, z) - height_at(x - e, z)
			var dz := height_at(x, z + e) - height_at(x, z - e)
			norms[i] = Vector3(-dx, 2.0 * e, -dz).normalized()
			uvs[i] = Vector2(ix, iz) / float(n - 1)

	var k := 0
	for iz in n - 1:
		for ix in n - 1:
			var a := iz * n + ix
			var b := a + 1
			var c := a + n
			var d := c + 1
			# Counter-clockwise when seen from above (+Y)
			indices[k] = a
			indices[k + 1] = b
			indices[k + 2] = c
			indices[k + 3] = b
			indices[k + 4] = d
			indices[k + 5] = c
			k += 6

	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices

	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	if terrain_material:
		mesh.surface_set_material(0, terrain_material)

	var mi := MeshInstance3D.new()
	mi.name = "TerrainMesh"
	mi.mesh = mesh
	add_child(mi)

	# Exact collision from the same triangles
	var cs := CollisionShape3D.new()
	cs.name = "TerrainCollision"
	cs.shape = mesh.create_trimesh_shape()
	add_child(cs)


func _build_invisible_walls() -> void:
	# Safety net so nobody can leave the map by jumping over the rim.
	var h := 60.0
	var t := 1.0
	var s := HALF * 2.0 + 2.0
	var defs := [
		[Vector3(s, h, t), Vector3(0, h / 2, -HALF - t / 2)],
		[Vector3(s, h, t), Vector3(0, h / 2, HALF + t / 2)],
		[Vector3(t, h, s), Vector3(-HALF - t / 2, h / 2, 0)],
		[Vector3(t, h, s), Vector3(HALF + t / 2, h / 2, 0)],
	]
	var walls := StaticBody3D.new()
	walls.name = "InvisibleWalls"
	walls.collision_layer = Layers.WALLS   # only the player collides with these
	walls.collision_mask = 0
	add_child(walls)
	for def in defs:
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = def[0]
		cs.shape = bs
		cs.position = def[1]
		walls.add_child(cs)
