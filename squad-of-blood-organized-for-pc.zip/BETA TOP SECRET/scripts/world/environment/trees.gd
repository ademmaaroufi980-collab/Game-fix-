extends Node3D
## Pine trees scattered on the hills around the arena (never inside it).
## One MultiMesh = one draw call; each trunk gets a simple collider on the WORLD layer,
## so the player collides with trees and bullets hit them.

const ARENA_CLEAR := 31.0    # no trees inside this Chebyshev distance from the centre
const FOREST_EDGE := 50.0    # no trees on the steep rim
const MAX_TREES := 140
const MIN_SPACING := 5.0     # metres between trunks
const MAX_GROUND_Y := 6.5    # keep trees off the snowy peaks
const MAX_SLOPE := 0.4       # keep trees off cliffs
const TRUNK_RADIUS := 0.4
const COLLIDER_HEIGHT := 6.0

var tree_spots: Array[Vector3] = []   # read by enemies when they pick a respawn point


func _ready() -> void:
	add_to_group("trees")
	_build.call_deferred()   # wait one frame so the Terrain node has built its noise


func _build() -> void:
	var terrain := get_parent().get_node_or_null("Terrain")
	if terrain == null or not terrain.has_method("height_at"):
		return

	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	var spots: Array[Vector3] = []
	var sizes: Array[float] = []
	var tries := 0
	while spots.size() < MAX_TREES and tries < 4000:
		tries += 1
		var x := rng.randf_range(-FOREST_EDGE, FOREST_EDGE)
		var z := rng.randf_range(-FOREST_EDGE, FOREST_EDGE)
		var cheb := maxf(absf(x), absf(z))
		if cheb < ARENA_CLEAR or cheb > FOREST_EDGE:
			continue
		var y: float = terrain.height_at(x, z)
		if y > MAX_GROUND_Y:
			continue
		var gx: float = terrain.height_at(x + 1.0, z) - terrain.height_at(x - 1.0, z)
		var gz: float = terrain.height_at(x, z + 1.0) - terrain.height_at(x, z - 1.0)
		if Vector2(gx, gz).length() * 0.5 > MAX_SLOPE:
			continue
		var p := Vector3(x, y, z)
		var too_close := false
		for q in spots:
			if Vector2(p.x - q.x, p.z - q.z).length() < MIN_SPACING:
				too_close = true
				break
		if too_close:
			continue
		spots.append(p)
		sizes.append(rng.randf_range(0.8, 1.5))

	tree_spots = spots
	_make_visuals(spots, sizes, rng)
	_make_colliders(spots, sizes)


func _make_visuals(spots: Array[Vector3], sizes: Array[float], rng: RandomNumberGenerator) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.mesh = _make_tree_mesh()
	mm.instance_count = spots.size()
	for i in spots.size():
		var basis := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3.ONE * sizes[i])
		mm.set_instance_transform(i, Transform3D(basis, spots[i]))
		var v := rng.randf_range(0.7, 1.0)
		mm.set_instance_color(i, Color(v, v, v))
	var mmi := MultiMeshInstance3D.new()
	mmi.name = "TreeMeshes"
	mmi.multimesh = mm
	add_child(mmi)


func _make_tree_mesh() -> ArrayMesh:
	var mesh := ArrayMesh.new()
	var st := SurfaceTool.new()

	# Surface 0: trunk
	var trunk := CylinderMesh.new()
	trunk.top_radius = 0.25
	trunk.bottom_radius = TRUNK_RADIUS
	trunk.height = 3.0
	trunk.radial_segments = 8
	trunk.rings = 1
	st.append_from(trunk, 0, Transform3D(Basis.IDENTITY, Vector3(0, 1.5, 0)))
	st.commit(mesh)
	st.clear()

	# Surface 1: three stacked cones (x = base radius, y = height, z = centre height)
	for layer in [Vector3(2.2, 3.0, 3.6), Vector3(1.7, 2.8, 5.3), Vector3(1.2, 2.4, 6.8)]:
		var cone := CylinderMesh.new()
		cone.top_radius = 0.0
		cone.bottom_radius = layer.x
		cone.height = layer.y
		cone.radial_segments = 8
		cone.rings = 1
		st.append_from(cone, 0, Transform3D(Basis.IDENTITY, Vector3(0, layer.z, 0)))
	st.commit(mesh)

	var bark := StandardMaterial3D.new()
	bark.albedo_color = Color(0.32, 0.2, 0.1)
	bark.vertex_color_use_as_albedo = true
	bark.roughness = 1.0
	var leaves := StandardMaterial3D.new()
	leaves.albedo_color = Color(0.08, 0.28, 0.1)
	leaves.vertex_color_use_as_albedo = true
	leaves.roughness = 1.0
	mesh.surface_set_material(0, bark)
	mesh.surface_set_material(1, leaves)
	return mesh


func _make_colliders(spots: Array[Vector3], sizes: Array[float]) -> void:
	var body := StaticBody3D.new()
	body.name = "TreeCollision"
	body.collision_layer = Layers.WORLD
	body.collision_mask = 0
	add_child(body)
	for i in spots.size():
		var shape := CylinderShape3D.new()
		shape.radius = TRUNK_RADIUS * sizes[i]
		shape.height = COLLIDER_HEIGHT * sizes[i]
		var cs := CollisionShape3D.new()
		cs.shape = shape
		cs.position = spots[i] + Vector3(0, shape.height * 0.5, 0)
		body.add_child(cs)
