extends WorldEnvironment
## Applies the graphics options from Settings to this scene's environment.


func _ready() -> void:
	Settings.changed.connect(_apply)
	_apply()


func _apply() -> void:
	environment.ssao_enabled = Settings.ssao
