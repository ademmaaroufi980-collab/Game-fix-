class_name AmmoPickup
extends Area3D
## Ammo crate: refills all weapons (only if needed), respawns after a delay.

@export var respawn_time := 12.0

var mesh: MeshInstance3D
var wm: WeaponManager
var active := true


func _ready() -> void:
	collision_layer = 0
	collision_mask = Layers.PLAYER
	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 1.2
	cs.shape = sh
	add_child(cs)

	mesh = MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.6, 0.4, 0.4)
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.25, 0.5, 0.2)
	m.emission_enabled = true
	m.emission = Color(0.3, 1.0, 0.3)
	m.emission_energy_multiplier = 0.6
	bm.material = m
	mesh.mesh = bm
	add_child(mesh)
	wm = get_tree().get_first_node_in_group("weapon_manager") as WeaponManager


func _process(delta: float) -> void:
	mesh.rotate_y(delta * 1.5)
	mesh.position.y = sin(Time.get_ticks_msec() / 400.0) * 0.1


# Polled so a player standing on a crate with full ammo can still grab it later.
func _physics_process(_delta: float) -> void:
	if not active or wm == null:
		return
	for body in get_overlapping_bodies():
		if body.is_in_group("player") and wm.refill():
			_collect()
			return


func _collect() -> void:
	active = false
	visible = false
	set_process(false)
	await get_tree().create_timer(respawn_time).timeout
	visible = true
	active = true
	set_process(true)
