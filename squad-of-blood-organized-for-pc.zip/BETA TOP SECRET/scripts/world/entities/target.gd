class_name Target
extends CharacterBody3D
## Enemy soldier. Wanders until it sees you, then chases, strafes and shoots back.
## Body and head hit zones, flashes on hit, falls when killed and comes back at a random spot.

signal died
## Emitted on every kill: the victim and who shot it (null = the player).
signal killed_by(victim: Target, killer: Node)
## Emitted when this soldier's shot kills the player.
signal player_killed(by: Target)

enum State { IDLE, CHASE, ATTACK }

## Set by the round manager: a managed target never respawns on its own.
var managed := false
## Difficulty multiplier (1.0 = normal). The round manager raises it every round.
var ai_level := 1.0
## Battle royale: soldiers also fight each other (they pick the nearest enemy they can see).
var br_fight := false
var display_name := "BOT"
var foe: Node3D = null
## Battle royale: when it has nobody to fight it walks round the map looking for loot.
var roam := false
var roam_goal := Vector3.ZERO
var roam_t := 0.0
var foe_timer := 0.0

@export var max_health := 100.0
@export var patrol_dir := Vector3.ZERO
@export var patrol_range := 4.0
@export var patrol_speed := 2.0
@export var respawn_time := 3.0
@export var head_height := 1.45

const GRAVITY := 22.0
const DETECT_RANGE := 38.0     # notices you from this far when it has a clear line of sight
const LOSE_RANGE := 70.0
const ATTACK_MIN := 9.0        # closer than this it backs off while shooting
const ATTACK_MAX := 24.0       # starts shooting from this far
const CHASE_SPEED := 4.2
const STRAFE_SPEED := 2.4
const AIM_TIME := 0.55         # the gun glows red this long before every shot: your cue to move
const FIRE_INTERVAL := 1.6
const BASE_DAMAGE := 6.0
const ALERT_TIME := 8.0        # keeps hunting this long after losing sight of you
const SPAWN_HALF := 46.0
const SPAWN_MIN_PLAYER := 22.0
const SPAWN_MAX_SLOPE := 0.45
const SPAWN_MAX_Y := 6.5
const MUZZLE_LOCAL := Vector3(0.28, 1.1, -0.8)

static var _shot_stream: AudioStreamWAV

var health := 100.0
var dead := false
var state := State.IDLE
var player: Player
var alert_timer := 0.0
var los := false
var los_timer := 0.0
var aim_timer := 0.0
var cooldown := 1.0
var strafe_dir := 1.0
var strafe_timer := 0.0
var stuck_timer := 0.0
var side_timer := 0.0
var side_dir := 1.0
var patrol_t := 0.0
var pivot: Node3D
var body_mat: StandardMaterial3D
var head_mat: StandardMaterial3D
var gun_mat: StandardMaterial3D
var flash_mats: Array[StandardMaterial3D] = []   # every material that lights up when the soldier is hit
var shapes: Array[CollisionShape3D] = []
var flash_tween: Tween


func _ready() -> void:
	add_to_group("targets")
	collision_layer = Layers.TARGETS
	collision_mask = Layers.WORLD | Layers.WALLS   # walk on terrain, bump into trees and cover
	floor_snap_length = 0.6
	floor_max_angle = deg_to_rad(50.0)
	health = max_health
	patrol_t = randf() * TAU
	cooldown = randf_range(0.6, 1.6)

	pivot = Node3D.new()
	add_child(pivot)

	_build_soldier()

	var cs_body := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.32
	cap.height = 1.5
	cs_body.shape = cap
	cs_body.position.y = 0.75
	add_child(cs_body)

	var cs_head := CollisionShape3D.new()
	var sph := SphereShape3D.new()
	sph.radius = 0.2
	cs_head.shape = sph
	cs_head.position.y = 1.68
	add_child(cs_head)
	shapes = [cs_body, cs_head]

	_initial_spawn.call_deferred()


const UNIFORMS: Array[Color] = [
	Color(0.30, 0.36, 0.20),   # olive
	Color(0.52, 0.45, 0.30),   # desert tan
	Color(0.22, 0.25, 0.30),   # dark grey
	Color(0.20, 0.27, 0.40),   # navy
	Color(0.40, 0.30, 0.22),   # brown camo
]


## A soldier built from simple shapes: boots, legs, torso with vest and backpack, head with helmet
## and goggles, two arms holding a rifle. Looks along -Z. The hit shapes are separate (see _ready).
func _build_soldier() -> void:
	var cloth_col: Color = UNIFORMS[randi() % UNIFORMS.size()]
	var cloth := _make_mat(cloth_col)
	var pants := _make_mat(cloth_col.darkened(0.2))
	var vest := _make_mat(Color(0.14, 0.15, 0.13))
	var boots := _make_mat(Color(0.07, 0.06, 0.06))
	var skin := _make_mat(Color(0.86, 0.68, 0.55))
	var helmet := _make_mat(cloth_col.darkened(0.35))
	var goggles := _make_mat(Color(0.05, 0.07, 0.09))
	head_mat = skin
	body_mat = cloth

	# Legs and boots
	for side in [-1.0, 1.0]:
		_part(BoxMesh.new(), Vector3(0.17, 0.78, 0.2), Vector3(0.12 * side, 0.5, 0.0), pants)
		_part(BoxMesh.new(), Vector3(0.18, 0.14, 0.32), Vector3(0.12 * side, 0.07, -0.04), boots)

	# Torso, vest, backpack, belt
	_part(BoxMesh.new(), Vector3(0.5, 0.58, 0.28), Vector3(0.0, 1.14, 0.0), cloth)
	_part(BoxMesh.new(), Vector3(0.54, 0.4, 0.33), Vector3(0.0, 1.2, 0.0), vest)
	_part(BoxMesh.new(), Vector3(0.52, 0.08, 0.3), Vector3(0.0, 0.83, 0.0), boots)
	_part(BoxMesh.new(), Vector3(0.36, 0.42, 0.18), Vector3(0.0, 1.16, 0.24), vest)

	# Neck, head, helmet, goggles
	_part(BoxMesh.new(), Vector3(0.12, 0.1, 0.12), Vector3(0.0, 1.5, 0.0), skin)
	var head := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.2
	sm.height = 0.4
	sm.material = skin
	head.mesh = sm
	head.position.y = 1.68
	pivot.add_child(head)
	var hm := SphereMesh.new()
	hm.radius = 0.235
	hm.height = 0.235
	hm.is_hemisphere = true
	hm.material = helmet
	var hat := MeshInstance3D.new()
	hat.mesh = hm
	hat.position = Vector3(0.0, 1.71, 0.01)
	pivot.add_child(hat)
	_part(BoxMesh.new(), Vector3(0.4, 0.04, 0.4), Vector3(0.0, 1.71, 0.0), helmet)   # helmet brim
	_part(BoxMesh.new(), Vector3(0.3, 0.07, 0.05), Vector3(0.0, 1.68, -0.19), goggles)

	# Gun: points forward (-Z) and glows red while the enemy is aiming.
	gun_mat = StandardMaterial3D.new()
	gun_mat.albedo_color = Color(0.1, 0.1, 0.12)
	gun_mat.roughness = 0.5
	gun_mat.emission_enabled = true
	gun_mat.emission = Color(1.0, 0.1, 0.05)
	gun_mat.emission_energy_multiplier = 0.0
	_part(BoxMesh.new(), Vector3(0.1, 0.12, 0.7), Vector3(0.28, 1.1, -0.45), gun_mat)
	_part(BoxMesh.new(), Vector3(0.07, 0.2, 0.1), Vector3(0.28, 0.95, -0.4), boots)   # magazine
	_part(BoxMesh.new(), Vector3(0.09, 0.16, 0.22), Vector3(0.28, 1.08, -0.02), boots)   # stock

	# Arms: shoulder to hand, right hand on the grip, left hand under the barrel
	_limb(Vector3(0.32, 1.38, 0.0), Vector3(0.28, 1.08, -0.3), 0.13, cloth)
	_limb(Vector3(-0.32, 1.38, 0.0), Vector3(0.28, 1.04, -0.6), 0.13, cloth)
	_part(BoxMesh.new(), Vector3(0.1, 0.1, 0.1), Vector3(0.28, 1.06, -0.3), skin)
	_part(BoxMesh.new(), Vector3(0.1, 0.1, 0.1), Vector3(0.28, 1.02, -0.6), skin)


## A box mesh of the given size at `pos` inside the pivot.
func _part(mesh: BoxMesh, size: Vector3, pos: Vector3, mat: StandardMaterial3D) -> void:
	mesh.size = size
	mesh.material = mat
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = pos
	pivot.add_child(mi)


## A box stretched from point `a` to point `b` (an arm).
func _limb(a: Vector3, b: Vector3, thick: float, mat: StandardMaterial3D) -> void:
	var bm := BoxMesh.new()
	bm.size = Vector3(thick, thick, a.distance_to(b))
	bm.material = mat
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.transform = Transform3D(Basis.looking_at(b - a, Vector3.UP), (a + b) * 0.5)
	pivot.add_child(mi)



func _make_mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.6
	m.emission_enabled = true
	m.emission = Color.WHITE
	m.emission_energy_multiplier = 0.0
	flash_mats.append(m)
	return m


func _lvl() -> float:
	return clampf(ai_level, 1.0, 2.0)


# ---------------------------------------------------------------- AI

func _physics_process(delta: float) -> void:
	if not visible:
		return
	if dead:
		_apply_gravity(delta)
		velocity.x = 0.0
		velocity.z = 0.0
		move_and_slide()
		return

	if player == null:
		player = get_tree().get_first_node_in_group("player") as Player
	if br_fight:
		foe_timer -= delta
		if foe_timer <= 0.0:
			foe_timer = randf_range(0.3, 0.5)
			foe = _pick_foe()
		elif foe != null and (not is_instance_valid(foe) or bool(foe.get("dead"))):
			foe = null
	else:
		foe = player if (player != null and not player.dead) else null
	var has_player := foe != null
	var dir := Vector3.ZERO
	var dist := INF
	if has_player:
		var d := foe.global_position - global_position
		d.y = 0.0
		dist = d.length()
		dir = d / maxf(dist, 0.01)

	# Line of sight is checked 5 times a second, not every frame.
	los_timer -= delta
	if los_timer <= 0.0:
		los_timer = 0.2
		los = has_player and dist < LOSE_RANGE and _can_see(foe)
	if los and dist < DETECT_RANGE:
		alert_timer = ALERT_TIME
	alert_timer = maxf(0.0, alert_timer - delta)

	var lvl := _lvl()
	var want := Vector3.ZERO   # desired horizontal velocity
	if not has_player or alert_timer <= 0.0:
		state = State.IDLE
		want = _idle_velocity(delta)
		_aim_reset()
	else:
		_face(dir, delta)
		if los and dist <= ATTACK_MAX:
			state = State.ATTACK
			strafe_timer -= delta
			if strafe_timer <= 0.0:
				strafe_timer = randf_range(1.0, 2.5)
				strafe_dir = 1.0 if randf() < 0.5 else -1.0
			want = dir.rotated(Vector3.UP, PI * 0.5) * strafe_dir * STRAFE_SPEED * (0.9 + 0.1 * lvl)
			if dist < ATTACK_MIN:
				want -= dir * STRAFE_SPEED * 1.2   # too close: back away while shooting
			_update_attack(delta, lvl)
		else:
			state = State.CHASE
			want = dir * CHASE_SPEED * (0.9 + 0.1 * lvl)
			_aim_reset()

	# Blocked by a tree or cover: sidestep for a moment.
	if side_timer > 0.0:
		side_timer -= delta
		want = want.rotated(Vector3.UP, side_dir * PI * 0.5)

	velocity.x = move_toward(velocity.x, want.x, 30.0 * delta)
	velocity.z = move_toward(velocity.z, want.z, 30.0 * delta)
	_apply_gravity(delta)
	move_and_slide()

	if side_timer <= 0.0 and want.length() > 1.0:
		var real := get_real_velocity()
		if Vector2(real.x, real.z).length() < want.length() * 0.3:
			stuck_timer += delta
			if stuck_timer > 0.35:
				stuck_timer = 0.0
				side_timer = 0.8
				side_dir = 1.0 if randf() < 0.5 else -1.0
		else:
			stuck_timer = 0.0

	if global_position.y < -20.0:
		_respawn_random()


func _apply_gravity(delta: float) -> void:
	if is_on_floor():
		velocity.y = -0.5
	else:
		velocity.y -= GRAVITY * delta


func _face(dir: Vector3, delta: float) -> void:
	if dir.length() < 0.01:
		return
	pivot.rotation.y = lerp_angle(pivot.rotation.y, atan2(-dir.x, -dir.z), minf(1.0, 10.0 * delta))


func _idle_velocity(delta: float) -> Vector3:
	if roam:
		return _roam_velocity(delta)
	if patrol_dir == Vector3.ZERO:
		return Vector3.ZERO
	patrol_t += delta * patrol_speed / maxf(patrol_range, 0.1)
	var v := patrol_dir.normalized() * cos(patrol_t) * patrol_speed
	_face(v.normalized(), delta)
	return v


## Walks towards the nearest loot (or a random spot) and takes the loot when it gets there.
func _roam_velocity(delta: float) -> Vector3:
	roam_t -= delta
	var to := roam_goal - global_position
	to.y = 0.0
	var zone := get_tree().get_first_node_in_group("br_zone") as BrZone
	var safe := true
	if zone != null and zone.is_active():
		safe = zone.inside_next(Vector2(global_position.x, global_position.z), 4.0)
		var goal_ok := zone.inside_next(Vector2(roam_goal.x, roam_goal.z), 2.0)
		if not goal_ok:
			roam_t = 0.0   # the goal is outside the coming circle: choose another one now
	if roam_t <= 0.0 or to.length() < 2.0:
		roam_t = randf_range(8.0, 16.0)
		roam_goal = _pick_roam_goal()
		to = roam_goal - global_position
		to.y = 0.0
	for n in get_tree().get_nodes_in_group("loot"):
		if n is Loot and (n as Loot).global_position.distance_to(global_position) < 1.6:
			(n as Loot).take_by_bot(self)
			roam_t = 0.0   # pick a new goal
	if to.length() < 0.1:
		return Vector3.ZERO
	_face(to.normalized(), delta)
	return to.normalized() * patrol_speed * (1.7 if safe else 2.4)   # run when outside the coming circle


func _pick_roam_goal() -> Vector3:
	var zone := get_tree().get_first_node_in_group("br_zone") as BrZone
	var zone_on := zone != null and zone.is_active()
	if zone_on and not zone.inside_next(Vector2(global_position.x, global_position.z), 4.0):
		# Outside the coming circle: head for a spot inside it
		var a := randf() * TAU
		var r := sqrt(randf()) * zone.next_radius * 0.6
		return Vector3(zone.next_center.x + cos(a) * r, 0.0, zone.next_center.y + sin(a) * r)
	var best := Vector3.ZERO
	var best_d := 90.0
	if randf() < 0.7:
		for n in get_tree().get_nodes_in_group("loot"):
			var lp := (n as Node3D).global_position
			if zone_on and not zone.inside_next(Vector2(lp.x, lp.z), 2.0):
				continue   # not worth walking out of the safe area for
			var d := lp.distance_to(global_position)
			if d < best_d and randf() < 0.8:
				best_d = d
				best = (n as Node3D).global_position
		if best_d < 90.0:
			return best
	if zone_on:
		var a2 := randf() * TAU
		var r2 := sqrt(randf()) * zone.next_radius * 0.8
		return Vector3(zone.next_center.x + cos(a2) * r2, 0.0, zone.next_center.y + sin(a2) * r2)
	return Vector3(randf_range(-185.0, 185.0), 0.0, randf_range(-185.0, 185.0))


func _can_see(who: Node3D) -> bool:
	var from := global_position + Vector3(0, 1.55, 0)
	var q := PhysicsRayQueryParameters3D.create(from, _chest(who, 1.55), Layers.WORLD)
	return get_world_3d().direct_space_state.intersect_ray(q).is_empty()


## Where to aim at somebody: the player's eyes, or a soldier's upper body.
func _chest(who: Node3D, height: float) -> Vector3:
	if who is Player:
		return (who as Player).camera.global_position
	return who.global_position + Vector3(0, height, 0)


## Battle royale: the nearest awake enemy in view (the player or another soldier). Falls back to
## hunting the player when it has been shot recently.
func _pick_foe() -> Node3D:
	var cands: Array[Node3D] = []
	if player != null and not player.dead:
		cands.append(player)
	for n in get_tree().get_nodes_in_group("targets"):
		var o := n as Target
		if o != null and o != self and not o.dead and o.visible and o.is_physics_processing() and not o.has_meta("air"):
			cands.append(o)
	cands.sort_custom(func(a: Node3D, b: Node3D) -> bool:
		return a.global_position.distance_squared_to(global_position) < b.global_position.distance_squared_to(global_position))
	var checked := 0
	for c in cands:
		if c.global_position.distance_to(global_position) > DETECT_RANGE:
			break
		checked += 1
		if checked > 4:
			break
		if _can_see(c):
			return c
	if foe != null and is_instance_valid(foe) and not bool(foe.get("dead")) and alert_timer > 0.0:
		return foe   # keep chasing the one it was fighting
	if alert_timer > 0.0 and player != null and not player.dead:
		return player
	return null


func _aim_reset() -> void:
	aim_timer = 0.0
	gun_mat.emission_energy_multiplier = 0.0


func _update_attack(delta: float, lvl: float) -> void:
	cooldown -= delta
	if cooldown > 0.0:
		return
	aim_timer += delta
	var aim_time := AIM_TIME / lvl
	gun_mat.emission_energy_multiplier = clampf(aim_timer / aim_time, 0.0, 1.0) * 3.0
	if aim_timer >= aim_time:
		_aim_reset()
		cooldown = FIRE_INTERVAL / lvl * randf_range(0.8, 1.25)
		if los:
			_shoot(lvl)


func _shoot(lvl: float) -> void:
	if foe == null:
		return
	var origin := pivot.to_global(MUZZLE_LOCAL)
	var aim_pos := _chest(foe, 1.1)
	if foe is Player:
		aim_pos = player.camera.global_position + Vector3(0, -0.4, 0)   # roughly the chest
	var chance := clampf(0.8 - origin.distance_to(aim_pos) * 0.022, 0.22, 0.8) * (0.8 + 0.15 * lvl)
	if foe is Player:
		if player.prone:
			chance *= 0.55
		elif player.crouching:
			chance *= 0.75
		if player.sprinting:
			chance *= 0.8
	var end := aim_pos
	if randf() < clampf(chance, 0.15, 0.9):
		var dmg := BASE_DAMAGE * (0.9 + 0.2 * lvl)
		if foe is Player:
			player.take_damage(dmg, global_position)
			if player.dead:
				player_killed.emit(self)
		else:
			(foe as Target).take_damage(dmg, aim_pos, self)
	else:
		end += Vector3(randf_range(-1.2, 1.2), randf_range(-0.8, 0.8), randf_range(-1.2, 1.2))   # miss
	_tracer(origin, end)
	_play_shot()


func _tracer(a: Vector3, b: Vector3) -> void:
	var length := a.distance_to(b)
	if length < 0.1:
		return
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(1.0, 0.45, 0.15)
	var bm := BoxMesh.new()
	bm.size = Vector3(0.04, 0.04, length)
	bm.material = m
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	get_tree().current_scene.add_child(mi)
	mi.global_position = (a + b) * 0.5
	var up := Vector3.UP if absf((b - a).normalized().y) < 0.99 else Vector3.RIGHT
	mi.look_at(b, up)
	get_tree().create_timer(0.08).timeout.connect(mi.queue_free)


func _play_shot() -> void:
	if _shot_stream == null:
		_shot_stream = AudioSynth.noise_burst(0.22, 18.0, 0.35, 95.0, 0.6)
	var p := AudioStreamPlayer3D.new()
	p.stream = _shot_stream
	p.volume_db = -4.0
	p.unit_size = 12.0
	p.max_distance = 90.0
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()


# ---------------------------------------------------------------- damage / death / respawn

## Returns {} if already dead, else {head, kill, damage}.
func take_damage(amount: float, hit_pos: Vector3, attacker: Node = null) -> Dictionary:
	if dead:
		return {}
	var is_head := hit_pos.y - global_position.y > head_height
	var dmg := amount * (2.0 if is_head else 1.0)
	health -= dmg
	alert_timer = ALERT_TIME   # getting shot makes it hunt you
	los_timer = 0.0
	if br_fight and attacker is Target and not (attacker as Target).dead:
		foe = attacker as Node3D   # shoot back at whoever hit it
	for m in flash_mats:
		m.emission_energy_multiplier = 2.5
	if flash_tween:
		flash_tween.kill()
	flash_tween = create_tween()
	for m in flash_mats:
		flash_tween.parallel().tween_property(m, "emission_energy_multiplier", 0.0, 0.15)
	var killed := false
	if health <= 0.0:
		killed = true
		_die()
		killed_by.emit(self, attacker)
	return {"head": is_head, "kill": killed, "damage": dmg}


func _die() -> void:
	dead = true
	_aim_reset()
	for s in shapes:
		s.set_deferred("disabled", true)
	var tw := create_tween()
	tw.tween_property(pivot, "rotation:x", -PI / 2.0, 0.3).set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	if not managed:
		tw.tween_interval(respawn_time)
		tw.tween_callback(_revive)
	died.emit()


## Shows/hides the target and enables/disables its hit shapes (used between rounds).
## Turning it on puts it at a new random spot, already hunting the player.
func set_active(on: bool) -> void:
	visible = on
	dead = not on
	for s in shapes:
		s.set_deferred("disabled", not on)
	if on:
		health = max_health
		pivot.rotation.x = 0.0
		_aim_reset()
		cooldown = randf_range(0.8, 1.8)
		_respawn_random()
		alert_timer = ALERT_TIME


func _revive() -> void:
	health = max_health
	dead = false
	pivot.rotation.x = 0.0
	for s in shapes:
		s.disabled = false
	_respawn_random()
	cooldown = randf_range(0.8, 1.8)
	alert_timer = ALERT_TIME if randf() < 0.5 else 0.0   # half of them come straight for you


func _initial_spawn() -> void:
	if managed:
		return   # the round manager places targets when each round starts
	_respawn_random()


func _respawn_random() -> void:
	global_position = _pick_spawn()
	velocity = Vector3.ZERO


## A random spot on the map: flat enough, away from the player, trees, cover and other enemies.
func _pick_spawn() -> Vector3:
	var scene := get_tree().current_scene
	var terrain: Node = null
	if scene:
		terrain = scene.get_node_or_null("Terrain")
	if terrain == null or not terrain.has_method("height_at"):
		return global_position
	if player == null:
		player = get_tree().get_first_node_in_group("player") as Player

	var tree_spots: Array = []
	for n in get_tree().get_nodes_in_group("trees"):
		var list: Variant = n.get("tree_spots")
		if list is Array:
			tree_spots = list

	var probe := SphereShape3D.new()
	probe.radius = 0.6
	var params := PhysicsShapeQueryParameters3D.new()
	params.shape = probe
	params.collision_mask = Layers.WORLD
	var space := get_world_3d().direct_space_state

	for i in 60:
		var x := randf_range(-SPAWN_HALF, SPAWN_HALF)
		var z := randf_range(-SPAWN_HALF, SPAWN_HALF)
		var y: float = terrain.height_at(x, z)
		if y > SPAWN_MAX_Y:
			continue
		var gx: float = terrain.height_at(x + 1.0, z) - terrain.height_at(x - 1.0, z)
		var gz: float = terrain.height_at(x, z + 1.0) - terrain.height_at(x, z - 1.0)
		if Vector2(gx, gz).length() * 0.5 > SPAWN_MAX_SLOPE:
			continue
		if player and Vector2(x - player.global_position.x, z - player.global_position.z).length() < SPAWN_MIN_PLAYER:
			continue
		if _too_close(x, z, tree_spots):
			continue
		params.transform = Transform3D(Basis.IDENTITY, Vector3(x, y + 1.0, z))
		if not space.intersect_shape(params, 1).is_empty():
			continue   # inside a crate, platform or ramp
		return Vector3(x, y + 0.1, z)
	return global_position


func _too_close(x: float, z: float, tree_spots: Array) -> bool:
	for p: Vector3 in tree_spots:
		if Vector2(x - p.x, z - p.z).length() < 2.5:
			return true
	for n in get_tree().get_nodes_in_group("targets"):
		if n != self and n is Node3D and (n as Node3D).visible:
			var o := (n as Node3D).global_position
			if Vector2(x - o.x, z - o.z).length() < 2.5:
				return true
	return false
