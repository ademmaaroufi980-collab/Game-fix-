class_name AudioSynth
extends RefCounted
## Tiny procedural sound generators (16-bit mono WAV streams).

const RATE := 22050


static func wav(data: PackedByteArray) -> AudioStreamWAV:
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = RATE
	s.stereo = false
	s.data = data
	return s


## Low-passed noise with a decaying sine "thump" (gunshots, footsteps, landings).
static func noise_burst(duration: float, decay: float, lowpass: float, thump_hz: float, thump_amp := 0.8) -> AudioStreamWAV:
	var n := int(duration * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	var prev := 0.0
	for i in n:
		var t := float(i) / RATE
		prev = lerpf(prev, randf() * 2.0 - 1.0, lowpass)
		var v := prev * exp(-t * decay) + sin(TAU * thump_hz * t) * exp(-t * decay * 0.6) * thump_amp
		data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 30000.0))
	return wav(data)


static func tone(hz: float, duration: float, decay: float) -> AudioStreamWAV:
	var n := int(duration * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var t := float(i) / RATE
		data.encode_s16(i * 2, int(sin(TAU * hz * t) * exp(-t * decay) * 22000.0))
	return wav(data)


## Two metallic clicks (reload).
static func clicks() -> AudioStreamWAV:
	var n := int(0.6 * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var t := float(i) / RATE
		var v := 0.0
		for start in [0.05, 0.4]:
			var dt: float = t - start
			if dt >= 0.0 and dt < 0.04:
				v += (randf() * 2.0 - 1.0) * exp(-dt * 120.0)
		data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 26000.0))
	return wav(data)


## Rising air "whoosh" (dash).
static func whoosh(duration: float) -> AudioStreamWAV:
	var n := int(duration * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	var prev := 0.0
	for i in n:
		var f := float(i) / n
		prev = lerpf(prev, randf() * 2.0 - 1.0, lerpf(0.08, 0.55, f))
		var env := sin(PI * pow(f, 0.6))
		data.encode_s16(i * 2, int(clampf(prev * env * 1.6, -1.0, 1.0) * 24000.0))
	return wav(data)


## Looping rushing-air noise (slide). Plays until stopped.
static func wind_loop(duration: float) -> AudioStreamWAV:
	var n := int(duration * RATE)
	var data := PackedByteArray()
	data.resize(n * 2)
	var prev := 0.0
	var fade := int(0.01 * RATE)
	for i in n:
		var t := float(i) / RATE
		prev = lerpf(prev, randf() * 2.0 - 1.0, 0.12)
		var gust := 0.75 + 0.25 * sin(TAU * 3.0 * t / duration)
		var edge := minf(1.0, minf(float(i), float(n - i)) / fade)
		data.encode_s16(i * 2, int(clampf(prev * gust * edge * 1.8, -1.0, 1.0) * 22000.0))
	var s := wav(data)
	s.loop_mode = AudioStreamWAV.LOOP_FORWARD
	s.loop_begin = 0
	s.loop_end = n
	return s
