class_name PlayerAudio
extends Node
## Footsteps, landing, dash and wind sounds for the player (procedural, cached across scene reloads).

const STEP_VARIANTS := 3

static var _cache := {}

var step_streams: Array[AudioStreamWAV] = []
var step_players: Array[AudioStreamPlayer] = []
var step_idx := 0
var land_player: AudioStreamPlayer
var dash_player: AudioStreamPlayer
var wind_player: AudioStreamPlayer
var hurt_player: AudioStreamPlayer


func _ready() -> void:
	if not _cache.has("steps"):
		var list: Array[AudioStreamWAV] = []
		for i in STEP_VARIANTS:
			list.append(AudioSynth.noise_burst(0.12, 38.0, 0.25, 70.0 + i * 12.0, 0.5))
		_cache["steps"] = list
		_cache["land"] = AudioSynth.noise_burst(0.25, 16.0, 0.2, 55.0, 0.9)
		_cache["dash"] = AudioSynth.whoosh(0.3)
		_cache["wind"] = AudioSynth.wind_loop(0.9)
		_cache["hurt"] = AudioSynth.noise_burst(0.2, 20.0, 0.5, 120.0, 0.7)
	step_streams.assign(_cache["steps"])
	for i in 2:
		var p := AudioStreamPlayer.new()
		add_child(p)
		step_players.append(p)
	land_player = AudioStreamPlayer.new()
	land_player.stream = _cache["land"]
	add_child(land_player)
	dash_player = AudioStreamPlayer.new()
	dash_player.stream = _cache["dash"]
	dash_player.volume_db = -8.0
	add_child(dash_player)
	wind_player = AudioStreamPlayer.new()
	wind_player.stream = _cache["wind"]
	wind_player.volume_db = -40.0
	add_child(wind_player)
	hurt_player = AudioStreamPlayer.new()
	hurt_player.stream = _cache["hurt"]
	hurt_player.volume_db = -4.0
	add_child(hurt_player)


## volume_db: relative loudness (crouching is quieter, sprinting louder).
func step(volume_db: float) -> void:
	var p := step_players[step_idx % step_players.size()]
	step_idx += 1
	p.stream = step_streams[randi() % step_streams.size()]
	p.volume_db = -14.0 + volume_db
	p.pitch_scale = randf_range(0.9, 1.1)
	p.play()


## strength 0..1 from the fall speed.
func land(strength: float) -> void:
	land_player.volume_db = lerpf(-18.0, -4.0, strength)
	land_player.pitch_scale = randf_range(0.9, 1.05)
	land_player.play()


func dash() -> void:
	dash_player.play()


## Air rushing past while sliding. amount 0..1 sets loudness and pitch; 0 stops it.
func set_wind(amount: float) -> void:
	if amount < 0.02:
		if wind_player.playing:
			wind_player.stop()
		return
	if not wind_player.playing:
		wind_player.play()
	wind_player.volume_db = lerpf(-30.0, -8.0, amount)
	wind_player.pitch_scale = lerpf(0.8, 1.25, amount)


func hurt() -> void:
	hurt_player.pitch_scale = randf_range(0.9, 1.1)
	hurt_player.play()
