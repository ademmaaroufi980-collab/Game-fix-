class_name WeaponAudio
extends Node
## Procedural weapon sounds. Streams are synthesised once and cached across scene reloads.

# Generated sounds are expensive to synthesise, so keep them for the whole run.
static var _cache := {}

var shot_players: Array[AudioStreamPlayer] = []
var shot_streams: Array[AudioStreamWAV] = []
var shot_idx := 0
var reload_player: AudioStreamPlayer
var hit_player: AudioStreamPlayer
var empty_player: AudioStreamPlayer


func setup(weapons: Array[WeaponData]) -> void:
	for i in 4:
		var p := AudioStreamPlayer.new()
		p.volume_db = -8.0
		add_child(p)
		shot_players.append(p)
	for w in weapons:
		var key := "shot_%s_%s_%s_%s" % [w.shot_duration, w.shot_decay, w.shot_lowpass, w.shot_thump]
		if not _cache.has(key):
			_cache[key] = AudioSynth.noise_burst(w.shot_duration, w.shot_decay, w.shot_lowpass, w.shot_thump)
		shot_streams.append(_cache[key])
	if not _cache.has("reload"):
		_cache["reload"] = AudioSynth.clicks()
	if not _cache.has("hit"):
		_cache["hit"] = AudioSynth.tone(1500.0, 0.07, 40.0)
	reload_player = AudioStreamPlayer.new()
	reload_player.stream = _cache["reload"]
	reload_player.volume_db = -10.0
	add_child(reload_player)
	if not _cache.has("empty"):
		_cache["empty"] = AudioSynth.tone(900.0, 0.05, 90.0)
	empty_player = AudioStreamPlayer.new()
	empty_player.stream = _cache["empty"]
	empty_player.volume_db = -12.0
	add_child(empty_player)
	hit_player = AudioStreamPlayer.new()
	hit_player.stream = _cache["hit"]
	hit_player.volume_db = -8.0
	add_child(hit_player)


func play_shot(weapon_index: int) -> void:
	var sp := shot_players[shot_idx]
	shot_idx = (shot_idx + 1) % shot_players.size()
	sp.stream = shot_streams[weapon_index]
	sp.pitch_scale = randf_range(0.95, 1.05)
	sp.play()


func play_reload() -> void:
	reload_player.play()


func stop_reload() -> void:
	reload_player.stop()


func play_hit(kill: bool) -> void:
	hit_player.pitch_scale = 0.7 if kill else 1.0
	hit_player.play()


## Dry-fire click (empty magazine and no reserve ammo).
func play_empty() -> void:
	empty_player.play()
