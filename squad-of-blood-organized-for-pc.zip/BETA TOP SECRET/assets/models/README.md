# 3D asset bridge

The supplied `assests3d.7z` archive is kept here as the original asset pack.

The project now auto-detects extracted `.glb`, `.gltf`, `.obj`, or `.fbx` files under this folder.
Weapon names are matched automatically (`pistol`, `rifle`, `shotgun`, `sniper`), with the built-in procedural weapon as a safe fallback when a model is not present.

For Godot imports, extract the archive into this folder so the models are available to the editor.
